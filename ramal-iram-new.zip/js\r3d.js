// نواة الرسم ثلاثي الأبعاد المشتركة: عارض واحد، يرسم كل مجسّم في جزء من لوحة واحدة ثم ينسخه إلى اللعبة
window.R3D = (() => {
  'use strict';
  const R = { ok: false };
  if (!window.THREE) return R;
  const T = THREE; R.T = T;
  const ATLAS = 1536;
  let renderer;
  try {
    const c = document.createElement('canvas');
    renderer = new T.WebGLRenderer({ canvas: c, alpha: true, antialias: true, premultipliedAlpha: true, powerPreference: 'default' });
    if (!renderer.getContext()) return R;
  } catch (e) { return R; }
  renderer.setPixelRatio(1); renderer.setSize(ATLAS, ATLAS, false);
  renderer.setClearColor(0x000000, 0); renderer.outputColorSpace = T.SRGBColorSpace; renderer.autoClear = false;
  R.renderer = renderer;

  const gradTex = (() => { const d = new Uint8Array([70, 70, 70, 255, 150, 150, 150, 255, 215, 215, 215, 255, 255, 255, 255, 255]); const t = new T.DataTexture(d, 4, 1, T.RGBAFormat); t.minFilter = t.magFilter = T.NearestFilter; t.needsUpdate = true; return t; })();
  R.mat = (hex, extra = {}) => new T.MeshToonMaterial({ color: hex, gradientMap: gradTex, ...extra });
  R.glowMat = (hex, op = 1) => new T.MeshBasicMaterial({ color: hex, transparent: op < 1, opacity: op });
  R.OUT = new T.MeshBasicMaterial({ color: 0x1a0e08, side: T.BackSide });
  const FLASH = new T.MeshBasicMaterial({ color: 0xffffff });
  R.add = (parent, geo, m, x = 0, y = 0, z = 0, outline = 1.07) => {
    const mesh = new T.Mesh(geo, m); mesh.position.set(x, y, z); parent.add(mesh);
    if (outline) { const o = new T.Mesh(geo, R.OUT); o.scale.setScalar(outline); mesh.add(o); }
    return mesh;
  };
  R.G = () => new T.Group();
  R.limb = (len, r0, r1, seg = 10) => { const g = new T.CylinderGeometry(r1, r0, len, seg); g.translate(0, -len / 2, 0); return g; };
  R.sph = (r, w = 14, h = 10) => new T.SphereGeometry(r, w, h);
  R.cone = (r, h, seg = 10) => { const g = new T.ConeGeometry(r, h, seg); g.translate(0, h / 2, 0); return g; };

  // مشهد بإضاءة موحّدة
  R.rig = (VW, VH, CY) => {
    const scene = new T.Scene();
    scene.add(new T.HemisphereLight(0xfff1d6, 0x5a3a22, 1.1));
    const key = new T.DirectionalLight(0xffe2b0, 2.3); key.position.set(120, 200, 220); scene.add(key);
    const rim = new T.DirectionalLight(0x7fd4ff, 1.5); rim.position.set(-200, 80, -160); scene.add(rim);
    const fill = new T.DirectionalLight(0xffb070, 0.5); fill.position.set(-80, -40, 200); scene.add(fill);
    const cam = new T.OrthographicCamera(-VW / 2, VW / 2, VH / 2, -VH / 2, 1, 2000);
    cam.position.set(0, CY, 800); cam.lookAt(0, CY, 0);
    const root = new T.Group(); scene.add(root);
    return { scene, cam, root, VW, VH, CY, key, rim };
  };

  // أطلس واحد لكل إطار: نرسم كل المجسّمات أولاً ثم ننسخها دفعةً واحدة (أسرع بكثير على الجوال)
  let quality = 1, shX = 0, shY = 0, shH = 0;
  const cache = new Map();
  R.key = null;
  R.setQuality = (q) => { quality = q; };
  R.begin = () => { shX = shY = shH = 0; cache.clear(); };
  function alloc(pw, ph) {
    if (shX + pw > ATLAS) { shY += shH + 2; shX = 0; shH = 0; }
    if (shY + ph > ATLAS || pw > ATLAS) return null;
    const r = { x: shX, y: shY }; shX += pw + 2; shH = Math.max(shH, ph); return r;
  }
  function renderSlot(rig, scale, o, immediate) {
    let res = Math.max(0.8, Math.min(2.2, scale)) * quality;
    const maxDim = Math.max(rig.VW, rig.VH);
    if (maxDim * res > 900) res = 900 / maxDim;
    const pw = Math.round(rig.VW * res), ph = Math.round(rig.VH * res);
    let r = alloc(pw, ph);
    if (!r) { if (!immediate) return null; cache.clear(); shX = shY = shH = 0; r = alloc(pw, ph); if (!r) return null; }
    rig.scene.overrideMaterial = o.flash ? FLASH : null;
    renderer.setViewport(r.x, r.y, pw, ph); renderer.setScissor(r.x, r.y, pw, ph); renderer.setScissorTest(true);
    renderer.clear(true, true, true);
    renderer.render(rig.scene, rig.cam);
    return { sx: r.x, sy: ATLAS - r.y - ph, pw, ph, VW: rig.VW, VH: rig.VH, CY: rig.CY };
  }
  function blit(ctx, sl, x, y, a) {
    if (a <= 0) return;
    const pa = ctx.globalAlpha; ctx.globalAlpha = pa * a;
    ctx.drawImage(renderer.domElement, sl.sx, sl.sy, sl.pw, sl.ph, x - sl.VW / 2, y - sl.CY - sl.VH / 2, sl.VW, sl.VH);
    ctx.globalAlpha = pa;
  }
  R.peek = (k) => cache.get(k);
  R.blit = blit;
  // ctx = null: مرحلة التحضير (رسم في الأطلس فقط)
  R.draw = (ctx, rig, x, y, scale, o = {}) => {
    const k = R.key, a = o.alpha === undefined ? 1 : o.alpha;
    if (!ctx) { const sl = renderSlot(rig, scale, o, false); if (sl && k) cache.set(k, sl); return; }
    if (k && cache.has(k)) { const sl = cache.get(k); cache.delete(k); blit(ctx, sl, x, y, a); return; }
    const sl = renderSlot(rig, scale, o, true); if (sl) blit(ctx, sl, x, y, a);
  };
  // للقوائم: ينسخ إلى لوحة مستقلة
  R.toCanvas = (rig, canvas) => {
    const pw = Math.min(ATLAS, canvas.width), ph = Math.min(ATLAS, canvas.height);
    rig.scene.overrideMaterial = null;
    renderer.setViewport(0, 0, pw, ph); renderer.setScissor(0, 0, pw, ph); renderer.setScissorTest(true);
    renderer.clear(true, true, true); renderer.render(rig.scene, rig.cam);
    const g = canvas.getContext('2d'); g.clearRect(0, 0, canvas.width, canvas.height);
    g.drawImage(renderer.domElement, 0, ATLAS - ph, pw, ph, 0, 0, canvas.width, canvas.height);
  };
  R.ok = true;
  return R;
})();

// رمال إرَم — المحرك الرئيسي (الإصدار الثاني: قتال بالجنبية، روح، زعماء، رسائل، سوق)
(() => {
'use strict';
const W = 960, H = 540;
const cv = document.getElementById('game');
const ctx = cv.getContext('2d');
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
let scale = 1, dpr = 1;
const view = { w: W, h: H };
let state = { mode: 'boot' };

function resize() {
  dpr = Math.min(2, window.devicePixelRatio || 1);
  applyLayout();
  const st = document.getElementById('stage');
  const vw = Math.max(100, st ? st.clientWidth : window.innerWidth), vh = Math.max(100, st ? st.clientHeight : window.innerHeight);
  cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
  scale = Math.min(vw / W, vh / H); view.w = vw / scale; view.h = vh / scale;
  if (view.h < H) { scale = vh / H; view.w = vw / scale; view.h = H; }
  if (vh > vw * 0.85) { const tw = $('#app').classList.contains('lay-split') ? 470 : 560; view.w = tw; scale = vw / tw; view.h = vh / scale; }
  darkCv.width = Math.ceil(view.w); darkCv.height = Math.ceil(view.h);
}
const darkCv = document.createElement('canvas'), dctx = darkCv.getContext('2d');

// ===== الأصول =====
const IMG = {};
const SPRITES = ['scorpion', 'bat', 'spirit', 'boss', 'gem', 'ghoul', 'wisp', 'spider', 'soldier', 'queen', 'serpent', 'grandpa', 'merchant', 'pilgrim'];
const PICS = ['title', 'bg1', 'bg2', 'bg3', 'bg4', 'intro1', 'intro2', 'intro3', 'ch2', 'ch3', 'well', 'memory', 'end1', 'end2', 'true_end', 'gameover', 'shop'];
function loadImages() {
  const all = SPRITES.map(k => [k, `assets/img/spr_${k}.png`]).concat(PICS.map(k => [k, `assets/img/${k}.jpg`]))
    .concat([1, 2, 3, 4].flatMap(i => [['fg' + i, `assets/img/fg${i}.webp`], ['fgb' + i, `assets/img/fgb${i}.webp`], ['fgt' + i, `assets/img/fgt${i}.webp`], ['tex' + i, `assets/img/tex${i}.jpg`]]));
  return Promise.all(all.map(([k, src]) => new Promise(res => { const im = new Image(); im.onload = () => { IMG[k] = im; res(); }; im.onerror = res; im.src = src; })));
}

// ===== الإعدادات والتقدّم =====
const opts = { shake: true, subs: true, touch: 'auto', diff: 'knight', pad: 'joy', btn: 1, q: 1, layout: 'split' };
const DIFF = { explorer: { masks: 7, ehp: 0.8, bhp: 0.7, bdmg: 1 }, knight: { masks: 5, ehp: 1, bhp: 1, bdmg: 1 }, legend: { masks: 4, ehp: 1.4, bhp: 1.25, bdmg: 2 } };
const D = () => DIFF[opts.diff];
const SAVE_VERSION = 1;
const SAVE_PREFIX = 'ramal-iram-save-v1-slot-';
let activeSlot = 0;
const ACHIEVEMENTS = {
  firstBlood: { name: 'أول قطرة دم', desc: 'اهزم عدوًا لأول مرة.' },
  explorer: { name: 'خطوات في الرمل', desc: 'اجتز أول مرحلة.' },
  bossHunter: { name: 'كاسر الحراس', desc: 'اهزم أول زعيم.' },
  archivist: { name: 'أمين رسائل الجدّ', desc: 'اجمع الرسائل الثماني.' },
  wealthy: { name: 'تاجر القوافل', desc: 'اجمع 500 دينار.' },
};
const save = { letters: new Set(), achievements: {}, up: { masks: 0, blade: 0, focus: false, soul: false }, dinars: 0, totalDrops: 0, totalTime: 0, totalDeaths: 0, met: {}, bought: {}, abil: { dash: false, spell: false }, checkpoint: { level: 0, x: 0, y: 0 } };

function saveData() {
  return {
    version: SAVE_VERSION,
    letters: [...save.letters],
    achievements: { ...save.achievements },
    up: { ...save.up },
    dinars: save.dinars,
    totalDrops: save.totalDrops,
    totalTime: save.totalTime,
    totalDeaths: save.totalDeaths,
    met: { ...save.met },
    bought: { ...save.bought },
    abil: { ...save.abil },
    checkpoint: { ...save.checkpoint },
  };
}

function saveGame() {
  try { localStorage.setItem(SAVE_PREFIX + activeSlot, JSON.stringify(saveData())); return true; } catch (_) { return false; }
}

function loadGame(slot = activeSlot) {
  try {
    activeSlot = Math.max(0, Math.min(2, slot | 0));
    const raw = localStorage.getItem(SAVE_PREFIX + activeSlot);
    if (!raw) return false;
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object') throw new Error('invalid');
    const source = data.version === SAVE_VERSION ? data : { ...data, version: SAVE_VERSION };
    save.letters = new Set(Array.isArray(source.letters) ? source.letters.filter(Number.isInteger) : []);
    save.achievements = source.achievements && typeof source.achievements === 'object' ? source.achievements : {};
    Object.assign(save.up, { masks: 0, blade: 0, focus: false, soul: false }, source.up || {});
    Object.assign(save.abil, { dash: false, spell: false }, source.abil || {});
    Object.assign(save, {
      dinars: Number.isFinite(source.dinars) ? Math.max(0, source.dinars) : 0,
      totalDrops: Number.isFinite(source.totalDrops) ? Math.max(0, source.totalDrops) : 0,
      totalTime: Number.isFinite(source.totalTime) ? Math.max(0, source.totalTime) : 0,
      totalDeaths: Number.isFinite(source.totalDeaths) ? Math.max(0, source.totalDeaths) : 0,
      met: source.met && typeof source.met === 'object' ? source.met : {},
      bought: source.bought && typeof source.bought === 'object' ? source.bought : {},
      checkpoint: source.checkpoint && typeof source.checkpoint === 'object' ? source.checkpoint : { level: 0, x: 0, y: 0 },
    });
    return true;
  } catch (_) {
    try { localStorage.removeItem(SAVE_PREFIX + activeSlot); } catch (_) {}
    const msg = document.getElementById('loadMsg');
    if (msg) msg.textContent = 'تعذّر تحميل الحفظ، بدأنا لعبةً جديدة بأمان';
    return false;
  }
}

function unlockAchievement(id) {
  if (!ACHIEVEMENTS[id] || save.achievements[id]) return;
  save.achievements[id] = true; saveGame(); Snd.sfx('gem');
  if (state.mode === 'play' && player) { floatText(player.x + player.w / 2, player.y - 30, `إنجاز: ${ACHIEVEMENTS[id].name}`, '#ffd27a'); flash(0.1, '#ffd27a'); }
}

function addDinars(amount) {
  save.dinars += amount; if (save.dinars >= 500) unlockAchievement('wealthy'); saveGame();
}

function switchSaveSlot(slot) {
  saveGame();
  return loadGame(slot);
}

function saveSlotSummary(slot) {
  try {
    const raw = localStorage.getItem(SAVE_PREFIX + slot);
    if (!raw) return { slot, empty: true };
    const data = JSON.parse(raw);
    return { slot, empty: false, level: data.checkpoint && data.checkpoint.level || 0, letters: Array.isArray(data.letters) ? data.letters.length : 0, dinars: data.dinars || 0 };
  } catch (_) { return { slot, empty: false, corrupt: true }; }
}

function saveCheckpoint() {
  if (!level || !player) return;
  save.checkpoint = { level: levelIdx, x: Math.round(respawn.x), y: Math.round(respawn.y) }; saveGame();
}

// ===== الإدخال =====
const keys = {}, latched = {};
const input = { left: 0, right: 0, up: 0, down: 0, jump: 0, attack: 0, heavy: 0, dash: 0, heal: 0, spell: 0, spellP: 0, jumpP: 0, attackP: 0, heavyP: 0, dashP: 0, pauseP: 0, upP: 0, confirmP: 0 };
const touchState = {};
const prev = {};
const KEYMAP = { ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right', ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down',
  Space: 'jump', KeyZ: 'jump', KeyK: 'jump', KeyX: 'attack', KeyJ: 'attack', KeyH: 'heavy', ShiftLeft: 'dash', ShiftRight: 'dash', KeyC: 'dash', KeyL: 'dash',
  KeyF: 'heal', KeyV: 'heal', KeyQ: 'heal', KeyE: 'spell', KeyI: 'spell', Escape: 'pause', KeyP: 'pause', Enter: 'confirm' };
window.addEventListener('keydown', e => {
  const a = KEYMAP[e.code];
  if (a) { if (!e.repeat) latched[a] = true; keys[a] = true; if (state.mode === 'play' || e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault(); }
  if (state.mode === 'story' && (e.code === 'Enter' || e.code === 'Space')) { e.preventDefault(); Story.next(); }
  if (e.code === 'Escape' && state.mode === 'story') Story.skip();
});
window.addEventListener('keyup', e => { const a = KEYMAP[e.code]; if (a) keys[a] = false; });
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; if (state.mode === 'play') pause(); });
cv.addEventListener('pointerdown', e => { if (state.mode === 'play' && e.pointerType === 'mouse') { if (e.button === 0) latched.attack = true; if (e.button === 2) latched.dash = true; } });
cv.addEventListener('contextmenu', e => e.preventDefault());

function pollInput() {
  const g = { left: 0, right: 0, up: 0, down: 0, jump: 0, attack: 0, heavy: 0, dash: 0, heal: 0, spell: 0, pause: 0 };
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const p of pads) {
    if (!p) continue;
    const ax = p.axes[0] || 0, ay = p.axes[1] || 0, b = i => p.buttons[i] && p.buttons[i].pressed;
    if (ax < -0.35 || b(14)) g.left = 1; if (ax > 0.35 || b(15)) g.right = 1;
    if (ay < -0.5 || b(12)) g.up = 1; if (ay > 0.5 || b(13)) g.down = 1;
    if (b(0)) g.jump = 1; if (b(2)) g.attack = 1; if (b(10)) g.heavy = 1; if (b(1) || b(5)) g.dash = 1; if (b(7)) g.spell = 1; if (b(3) || b(4) || b(6)) g.heal = 1; if (b(9)) g.pause = 1;
  }
  for (const k of ['left', 'right', 'up', 'down', 'jump', 'attack', 'heavy', 'dash', 'heal', 'spell']) input[k] = !!(keys[k] || touchState[k] || g[k]);
  const edge = (k, cur) => { const r = (cur && !prev[k]) || !!latched[k]; prev[k] = cur; latched[k] = false; return r; };
  input.jumpP = edge('jump', input.jump); input.attackP = edge('attack', input.attack); input.heavyP = edge('heavy', input.heavy); input.dashP = edge('dash', input.dash); input.spellP = edge('spell', input.spell);
  input.upP = edge('up', input.up); input.pauseP = edge('pause', !!(keys.pause || g.pause)); input.confirmP = edge('confirm', !!keys.confirm);
}
$$('#touch button').forEach(b => {
  const k = b.dataset.k;
  const on = (e) => { e.preventDefault(); touchState[k] = true; b.classList.add('on'); if (k === 'up' || k === 'jump' || k === 'attack' || k === 'dash' || k === 'spell') latched[k] = true; };
  const off = (e) => { e.preventDefault(); touchState[k] = false; b.classList.remove('on'); };
  b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('pointerleave', off);
});
// عصا التحكّم: ثابتة في الوضع المقسوم، عائمة فوق اللعبة
(() => {
  const zone = $('#joyZone'), base = $('#joyBase'), knob = $('#joyKnob');
  let id = null, ox = 0, oy = 0;
  const R = 50;
  const set = (dx, dy) => {
    const d = Math.hypot(dx, dy), k = d > R ? R / d : 1; dx *= k; dy *= k;
    knob.style.transform = `translate(${dx}px, ${dy}px)`;
    const nx = dx / R, ny = dy / R;
    const wasUp = touchState.up;
    touchState.left = nx < -0.32; touchState.right = nx > 0.32;
    touchState.up = ny < -0.6; touchState.down = ny > 0.6;
    if (touchState.up && !wasUp) latched.up = true;
    base.querySelector('.jd.l').style.opacity = touchState.left ? 1 : ''; base.querySelector('.jd.r').style.opacity = touchState.right ? 1 : '';
    base.querySelector('.jd.u').style.opacity = touchState.up ? 1 : ''; base.querySelector('.jd.d').style.opacity = touchState.down ? 1 : '';
  };
  const end = (e) => { if (e.pointerId !== id) return; id = null; set(0, 0); base.classList.remove('active'); };
  zone.addEventListener('pointerdown', e => {
    e.preventDefault(); if (id !== null) return; id = e.pointerId; try { zone.setPointerCapture(id); } catch (_) {}
    const bs = base.getBoundingClientRect(); ox = bs.left + bs.width / 2; oy = bs.top + bs.height / 2;
    base.classList.add('active'); set(e.clientX - ox, e.clientY - oy); if (navigator.vibrate) try { navigator.vibrate(6); } catch (_) {}
  });
  zone.addEventListener('pointermove', e => { if (e.pointerId === id) { e.preventDefault(); set(e.clientX - ox, e.clientY - oy); } });
  zone.addEventListener('pointerup', end); zone.addEventListener('pointercancel', end);
})();
function applyLayout() {
  const app = $('#app'); if (!app) return;
  const tv = !$('#touch').classList.contains('hidden');
  const split = tv && opts.layout === 'split';
  const port = window.innerHeight > window.innerWidth;
  app.classList.toggle('lay-split', split); app.classList.toggle('lay-over', tv && !split);
  app.classList.toggle('port', port); app.classList.toggle('land', !port);
  // حجم الأزرار بحيث لا تتداخل أبداً
  let bs = opts.btn;
  if (split && port) { const h = Math.min(400, Math.max(250, window.innerHeight * 0.41)) - 40, w = window.innerWidth * 0.58 - 10; bs = Math.min(bs, h / 228, w / 228); }
  else if (split) { const w = Math.min(270, Math.max(170, window.innerWidth * 0.23)) - 14; bs = Math.min(bs, w / 228, (window.innerHeight - 20) / 300); }
  else bs = Math.min(bs, (window.innerHeight * 0.55) / 228);
  $('#touch').style.setProperty('--bs', bs.toFixed(3));
}
function applyPadOpts() {
  $('#touch').classList.toggle('pad-dpad', opts.pad === 'dpad');
  resize(); if (level) render();
  if (window.R3D && R3D.ok) R3D.setQuality(opts.q);
}
let touchSeen = matchMedia('(pointer: coarse)').matches;
window.addEventListener('touchstart', () => { if (!touchSeen) { touchSeen = true; updateTouchVis(); } }, { passive: true });
function updateTouchVis() {
  const show = state.mode === 'play' && (opts.touch === 'on' || (opts.touch === 'auto' && touchSeen));
  const was = !$('#touch').classList.contains('hidden');
  $('#touch').classList.toggle('hidden', !show);
  if (was !== show) { resize(); if (level) render(); }
  $('#tDash').classList.toggle('locked', !(level && hasDash())); $('#tSpell').classList.toggle('locked', !(level && hasSpell()));
  $('#rotateTip').classList.toggle('hidden', !(window.innerHeight > window.innerWidth && state.mode === 'play' && !(opts.layout === 'split' && !$('#touch').classList.contains('hidden'))));
}

// ===== الشاشات =====
function show(id) { $$('.screen').forEach(s => s.classList.remove('active')); if (id) $('#' + id).classList.add('active'); state.screen = id; }
document.addEventListener('click', e => { if (e.target.closest('button')) Snd.sfx('click'); });
document.addEventListener('pointerover', e => { if (e.target.closest && e.target.closest('.btn')) Snd.sfx('hover'); });

// ===== القصة =====
const STORIES = {
  intro: { chapter: 'المقدّمة', scenes: [
    { img: 'intro1', voice: 'n_intro1', text: 'في قلبِ الرُّبعِ الخالي… كانت «واحةُ النخيل» تنبضُ بالحياة. ماؤها عذب، ونخيلُها شامخ، وأهلُها يعيشونَ في أمان… بفضلِ جوهرةٍ زرقاءَ قديمة، تحرسُ ينبوعَها منذُ ألفِ عام.' },
    { img: 'intro2', voice: 'n_intro2', text: 'وفي ليلةٍ بلا قمر… هبّت عاصفةٌ لم يرَ أحدٌ مثلَها. خرجَ منها سلطانُ الرمال، فاختطفَ الجوهرة، وعادَ بها إلى مدينتِه المنسيّة… إرَمَ ذاتِ العِماد. ومنذُ تلكَ الليلة… بدأتِ الواحةُ تجِفّ.' },
    { img: 'intro3', voice: 'n_intro3', text: 'اقتربتِ الجدّةُ نورةُ من حفيدِها عبسي، وناولتْهُ خريطةَ جدِّه القديمة، ووشاحَه الأحمر:<br><span class="quote">«يا عبسي… الطريقُ إلى إرمَ طويل. يمرُّ بالكثبانِ والوادي والأطلال. أعِدِ الجوهرةَ يا بُنيّ… قبلَ أن تجفَّ آخرُ قطرة.»</span>' },
  ] },
  ch2: { chapter: 'الفصل الثاني', scenes: [
    { img: 'ch2', voice: 'n_ch2', text: 'عبرَ عبسي بحرَ الكثبان، ووصلَ معَ الغروبِ إلى «وادي الصدى»… حيثُ تختبئُ الخفافيشُ في أطلالٍ منحوتةٍ في الصخر. كانت ريحُ السَّمومِ التي نالها في الكثبان تسري في وشاحِه… <span class="quote">وكلُّ خطوةٍ تقرّبُه من الحقيقة.</span>' },
  ] },
  ch3: { chapter: 'الفصل الثالث', scenes: [
    { img: 'well', voice: 'n_well', text: 'غاصَ الوادي خلفَ عبسي، وقادتْهُ الخريطةُ إلى «بئرِ برهوت»… البئرِ التي يقولُ الناسُ إنّ قاعَها لا يُدرَك. وعلى حافّتِها… ظهرَ له طيفٌ يعرفُه جيداً.' },
    { img: 'well', voice: 'n_grandpa', text: '<span class="quote">«عبسي… يا ولدي. أنا جدُّك. قبلَ أربعينَ عاماً سلكتُ هذا الطريق… ولم أعُد. خُذْ مخالبَ الصقر، بها تتسلّقُ الجدران. وتذكّر يا بُنيّ… السلطانُ ليسَ كما يبدو.»</span>' },
  ] },
  ch4: { chapter: 'الفصل الرابع', scenes: [
    { img: 'ch3', voice: 'n_ch3', text: 'خرجَ عبسي من البئرِ تحتَ ضوءِ القمر… فرأى أعمدةً عملاقةً تشقُّ السماء. إنها إرَم… المدينةُ التي لا تُرى إلا لمن يستحق. وفي أعماقِها… ينتظرُهُ سلطانُ الرمال.' },
    { img: 'memory', voice: 'n_memory', text: 'قبلَ آلافِ السنين… كانت إرمُ جنّةَ الصحراء. بناها الملكُ <span class="quote">شدّاد</span>، وجعلَ في قلبِها جوهرةَ الينبوع. لكنّ الكِبرَ أعماه… فحلّت اللعنة، وصارَ رمالاً تحرسُ مدينةً ميتة. واليوم… يريدُ جوهرتَه من جديد.' },
  ] },
  ending: { chapter: 'الخاتمة', scenes: [
    { img: 'end1', voice: 'n_end1', text: 'وحينَ تحطّمَ تاجُ السلطان… تناثرتْ رمالُه معَ الريح. وسقطتِ الجوهرةُ الزرقاءُ بينَ يدَي عبسي… دافئةً، كأنّها قلبٌ ينبض.' },
    { img: 'end2', voice: 'n_end2', text: 'عادَ عبسي إلى الواحة، وأعادَ الجوهرةَ إلى الينبوع. فتفجّرَ الماءُ من جديد، وعادتِ الخُضرةُ إلى النخيل. ومنذُ ذلكَ اليوم… صارَ أهلُ الواحةِ يروونَ حكايةَ الفتى ذي الوشاحِ الأحمر… <span class="quote">حارسِ الرمال.</span>' },
  ] },
  trueEnding: { chapter: 'النهاية الحقيقية', scenes: [
    { img: 'end1', voice: 'n_end1', text: 'وحينَ تحطّمَ تاجُ السلطان… تناثرتْ رمالُه معَ الريح. وسقطتِ الجوهرةُ الزرقاءُ بينَ يدَي عبسي… دافئةً، كأنّها قلبٌ ينبض.' },
    { img: 'true_end', voice: 'n_true', text: 'لكنَّ عبسي كانَ قد قرأَ رسائلَ جدِّه كلَّها… فعرفَ السرَّ الأخير: <span class="quote">الجوهرةُ قلبان.</span> رفعَها نحوَ السماء، فانشقّتْ نوراً… نصفٌ عادَ إلى الواحة، ونصفٌ أحيا ينابيعَ إرم. وابتسمَ طيفُ الجدّ… ثمّ رحلَ بسلام.' },
    { img: 'end2', voice: 'n_end2', text: 'عادَ عبسي إلى الواحة، فتفجّرَ الماءُ من جديد، وعادتِ الخُضرةُ إلى النخيل. ومنذُ ذلكَ اليوم… صارَ أهلُ الواحةِ يروونَ حكايةَ الفتى ذي الوشاحِ الأحمر… <span class="quote">حارسِ الرمال.</span>' },
  ] },
};
const Story = (() => {
  let cur = null, idx = 0, onDone = null, typeTimer = null, autoTimer = null, full = '', typing = false, flip = false;
  function play(key, done) {
    cur = STORIES[key]; idx = 0; onDone = done; state.mode = 'story';
    show('scrStory'); Snd.playMusic('story'); Snd.wind(true, 0.03);
    $('#storyChapter').textContent = cur.chapter;
    $('#storyDots').innerHTML = cur.scenes.map(() => '<i></i>').join('');
    scene();
  }
  function layoutStory(k) {
    const im = IMG[k]; const portrait = im && im.height > im.width * 1.05;
    $('#scrStory').classList.toggle('book', !!portrait && window.innerWidth > window.innerHeight * 1.1);
  }
  window.addEventListener('resize', () => { if (cur) layoutStory(cur.scenes[idx].img); });
  function scene() {
    clearTimeout(autoTimer); clearInterval(typeTimer);
    const s = cur.scenes[idx];
    const art = $('#storyArt'), wrap = $('#storyImgWrap'), img = $('#storyImg');
    const same = idx > 0 && cur.scenes[idx - 1].img === s.img;
    if (!same) { art.style.opacity = 0; wrap.style.opacity = 0; }
    setTimeout(() => {
      art.style.backgroundImage = `url(assets/img/${s.img}.jpg)`;
      if (!same) { img.src = `assets/img/${s.img}.jpg`; layoutStory(s.img); img.className = (flip = !flip) ? 'kb-a' : 'kb-b'; }
      void img.offsetWidth; art.style.opacity = 1; wrap.style.opacity = 1;
    }, idx === 0 || same ? 0 : 450);
    [...$('#storyDots').children].forEach((d, i) => d.classList.toggle('on', i === idx));
    $('#btnNext').textContent = idx === cur.scenes.length - 1 ? 'متابعة' : 'التالي';
    typeText(s.text);
    const el = Snd.voice(`assets/audio/${s.voice}.mp3`, () => { autoTimer = setTimeout(next, 1600); });
    if (!el) autoTimer = setTimeout(next, 9000);
  }
  function typeText(html) {
    const box = $('#storyText'); full = html; typing = true;
    if (!opts.subs) { box.innerHTML = ''; typing = false; return; }
    const tokens = html.split(/(<[^>]+>)/).filter(Boolean);
    let out = '', ti = 0, ci = 0; box.innerHTML = '';
    typeTimer = setInterval(() => {
      for (let n = 0; n < 2; n++) {
        if (ti >= tokens.length) { clearInterval(typeTimer); typing = false; return; }
        const tk = tokens[ti];
        if (tk.startsWith('<')) { out += tk; ti++; ci = 0; continue; }
        out += tk[ci++]; if (ci >= tk.length) { ti++; ci = 0; }
      }
      box.innerHTML = out + (out.split('<span').length > out.split('</span>').length ? '</span>' : '');
    }, 38);
  }
  function next() {
    if (!cur) return;
    if (typing) { clearInterval(typeTimer); typing = false; $('#storyText').innerHTML = full; return; }
    idx++; if (idx >= cur.scenes.length) return finish(); scene();
  }
  function skip() { finish(); }
  function finish() { clearTimeout(autoTimer); clearInterval(typeTimer); Snd.stopVoice(); const d = onDone; cur = null; onDone = null; d && d(); }
  $('#btnNext').addEventListener('click', next);
  $('#btnSkip').addEventListener('click', skip);
  $('#scrStory').addEventListener('click', e => { if (!e.target.closest('button')) next(); });
  return { play, next, skip };
})();

// ===== الحوار داخل اللعب =====
const Dialog = (() => {
  let d = null, timer = null, typing = false;
  function open(name, lines, img, onEnd) {
    d = { name, lines, i: 0, onEnd }; state.dialog = true;
    $('#dlgName').textContent = name;
    const pic = $('#dlgPic');
    if (img && IMG[img]) { pic.src = IMG[img].src; pic.classList.remove('hidden'); } else pic.classList.add('hidden');
    $('#dialog').classList.remove('hidden'); line();
  }
  function line() {
    const box = $('#dlgText'), html = d.lines[d.i]; clearInterval(timer); typing = true;
    const tokens = html.split(/(<[^>]+>)/).filter(Boolean); let out = '', ti = 0, ci = 0;
    timer = setInterval(() => {
      for (let n = 0; n < 2; n++) {
        if (ti >= tokens.length) { clearInterval(timer); typing = false; return; }
        const tk = tokens[ti]; if (tk.startsWith('<')) { out += tk; ti++; ci = 0; continue; }
        out += tk[ci++]; if (ci >= tk.length) { ti++; ci = 0; }
      }
      box.innerHTML = out; if (Math.random() < 0.3) Snd.sfx('hover');
    }, 28);
    $('#dlgMore').textContent = d.i < d.lines.length - 1 ? 'التالي ◂' : 'إغلاق ◂';
  }
  function advance() {
    if (!d) return;
    if (typing) { clearInterval(timer); typing = false; $('#dlgText').innerHTML = d.lines[d.i]; return; }
    d.i++; if (d.i >= d.lines.length) return close(); line();
  }
  function close() { clearInterval(timer); $('#dialog').classList.add('hidden'); const cb = d && d.onEnd; d = null; state.dialog = false; cb && cb(); }
  $('#dialog').addEventListener('click', advance);
  return { open, advance, close, get active() { return !!d; } };
})();

// ===== أدوات =====
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const irand = (a, b) => Math.floor(rand(a, b + 1));
const overlap = (a, b) => a && b && a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
function srand(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

// ===== الجسيمات =====
const parts = [];
function emit(x, y, n, o = {}) {
  for (let i = 0; i < n; i++) {
    if (parts.length > 700) parts.shift();
    const a = o.angle !== undefined ? o.angle + rand(-(o.spread || 0.5), o.spread || 0.5) : rand(0, Math.PI * 2);
    const sp = rand(o.min || 40, o.max || 160);
    parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: rand(o.lmin || 0.3, o.lmax || 0.7), t: 0, size: rand(o.smin || 2, o.smax || 5), color: o.color || '#f0d09a', g: o.g !== undefined ? o.g : 400, glow: o.glow || false, drag: o.drag || 0.98 });
  }
}
function updateParts(dt) {
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i]; p.t += dt;
    if (p.t >= p.life) { parts.splice(i, 1); continue; }
    p.vx *= p.drag; p.vy = p.vy * p.drag + p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt;
  }
}
function drawParts() {
  for (const p of parts) {
    const k = 1 - p.t / p.life; ctx.globalAlpha = k;
    if (p.glow) ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.5 + k * 0.5), 0, 7); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.globalAlpha = 1;
}
const floaters = [];
function floatText(x, y, t, c = '#fff') { floaters.push({ x, y, t, c, life: 0.9, a: 0 }); }

// ===== المرحلة =====
let level = null, levelIdx = 0, tileCanvas = null, farCanvas = null, ROWS = 13;
const cam = { x: 0, y: 0, shake: 0, lock: null };
let ents = [], player = null, boss = null, projectiles = [], hazards = [], arena = null, cutscene = null;
const stats = { drops: 0, total: 0, time: 0, deaths: 0, kills: 0 };
let respawn = { x: 0, y: 0 }, hitStop = 0, bannerTimer = null;

const isSolidCh = c => c === '#' || c === '=' || c === 'D';
function tileAt(tx, ty) {
  if (tx < 0 || tx >= level.w) return '#';
  if (ty < 0 || ty >= ROWS) return ' ';
  return level.g[ty][tx];
}

const EN = {
  scorpion: { hp: 3, w: 60, h: 38, coins: [3, 6] },
  minion: { hp: 2, w: 44, h: 28, coins: [1, 3] },
  bat: { hp: 2, w: 50, h: 32, coins: [2, 4] },
  spirit: { hp: 3, w: 44, h: 56, coins: [3, 5] },
  ghoul: { hp: 8, w: 62, h: 84, coins: [8, 14] },
  wisp: { hp: 3, w: 40, h: 44, coins: [4, 7] },
  spider: { hp: 2, w: 50, h: 34, coins: [3, 5] },
  soldier: { hp: 6, w: 44, h: 80, coins: [6, 10] },
};
function makeEnemy(type, x, y, extra = {}) {
  const d = EN[type];
  const hp = Math.max(1, Math.round(d.hp * D().ehp));
  return { enemy: true, type, x, y, w: d.w, h: d.h, hp, maxHp: hp, alive: true, t: Math.random() * 6, vx: 0, vy: 0, kb: 0, flash: 0, dir: -1, st: 'idle', stT: 0, ...extra };
}

function loadLevel(i) {
  levelIdx = i; level = LEVELS[i](); ROWS = level.rows;
  ents = []; projectiles = []; pshots = []; hazards = []; parts.length = 0; floaters.length = 0; boss = null; arena = null; cutscene = null; cam.lock = null;
  Object.assign(stats, { drops: 0, total: 0, time: 0, deaths: 0, kills: 0 });
  for (const e of level.ents) {
    const px = e.x * TILE, py = e.y * TILE;
    switch (e.type) {
      case 'drop': ents.push({ type: 'drop', x: px + 12, y: py + 10, w: 24, h: 28, ph: Math.random() * 6 }); stats.total++; break;
      case 'heart': ents.push({ type: 'heart', x: px + 8, y: py + 8, w: 32, h: 30 }); break;
      case 'scorpion': ents.push(makeEnemy('scorpion', px, py + TILE - 38, { min: e.min * TILE, max: (e.max + 1) * TILE, vx: -70 })); break;
      case 'ghoul': ents.push(makeEnemy('ghoul', px, py + TILE - 84, { min: e.min * TILE, max: (e.max + 1) * TILE, vx: -50 })); break;
      case 'soldier': ents.push(makeEnemy('soldier', px, py + TILE - 80, { min: e.min * TILE, max: (e.max + 1) * TILE })); break;
      case 'bat': ents.push(makeEnemy('bat', px, py, { bx: px, by: py, range: (e.range || 2) * TILE, dive: 0 })); break;
      case 'spirit': ents.push(makeEnemy('spirit', px, py)); break;
      case 'wisp': ents.push(makeEnemy('wisp', px, py, { hx: px, hy: py, shotT: rand(1, 2) })); break;
      case 'spider': ents.push(makeEnemy('spider', px, py, { hy: py, st: 'hang' })); break;
      case 'mplat': ents.push({ type: 'mplat', ox: px, oy: py, x: px, y: py, w: TILE * 3, h: 22, dx: (e.dx || 0) * TILE, dy: (e.dy || 0) * TILE, speed: e.speed || 1, t: 0, mx: 0, my: 0 }); break;
      case 'crumble': ents.push({ type: 'crumble', ox: px, oy: py, x: px, y: py, w: TILE * 2, h: 26, st: 'idle', t: 0, vy: 0, mx: 0, my: 0 }); break;
      case 'spring': ents.push({ type: 'spring', x: px + 4, y: py + TILE - 22, w: 40, h: 22, t: 0 }); break;
      case 'rest': ents.push({ type: 'rest', x: px - 16, y: py - 30, w: 80, h: 78, on: false, t: 0 }); break;
      case 'gate': ents.push({ type: 'gate', x: px, y: py - 104, w: 112, h: 152, t: 0 }); break;
      case 'shrine': if (!save.abil[e.abil]) ents.push(makeShrine(e.abil, px + 24, py + TILE)); break;
      case 'ambush': ents.push({ type: 'ambush', x: e.x0 * TILE, x0: e.x0, x1: e.x1, gy: py + TILE, waves: e.waves, reward: e.reward, st: 'wait', wave: -1, t: 0, saved: [] }); break;
      case 'seal': ents.push({ type: 'seal', x: px + 24 - 28, y: py + 24 - 30, w: 56, h: 60, lit: false, t: 0 }); break;
      case 'sdoor': { const d = { type: 'sdoor', tx: e.x, ty0: e.y0, ty1: e.y1, x: e.x * TILE, y: e.y0 * TILE, w: TILE * 2, h: (e.y1 - e.y0 + 1) * TILE, open: false, t: 0 }; for (let y = e.y0; y <= e.y1; y++) for (let x = e.x; x < e.x + 2; x++) level.g[y][x] = 'D'; ents.push(d); break; }
      case 'tablet': ents.push({ type: 'tablet', x: px + 6, y: py + 8, w: 36, h: 40, text: e.text, seen: false }); break;
      case 'npc': ents.push({ type: 'npc', id: e.id, x: px, y: py + TILE - 90, w: 60, h: 90, t: 0 }); break;
      case 'letter': if (!save.letters.has(e.id)) ents.push({ type: 'letter', id: e.id, x: px + 8, y: py + 10, w: 32, h: 30, t: Math.random() * 6 }); break;
      case 'jar': ents.push({ type: 'jar', x: px + 8, y: py + TILE - 40, w: 32, h: 40, hp: 1 }); break;
      case 'crystal': ents.push({ type: 'crystal', x: px + 24, y: py + 24, t: Math.random() * 6 }); break;
      case 'arena': arena = { x0: e.x0 * TILE, x1: (e.x1 + 1) * TILE, tx0: e.x0, tx1: e.x1, gy: py + TILE, boss: e.boss, started: false, done: false, saved: [] }; break;
    }
  }
  const s = level.start;
  respawn = { x: s.x * TILE, y: s.y * TILE - 20 };
  player = makePlayer(respawn.x, respawn.y);
  tileCanvas = prerenderTiles(); farCanvas = prerenderFar();
  cam.x = clamp(player.x - view.w * 0.4, 0, level.w * TILE - view.w); cam.y = clamp(player.y - view.h * 0.55, 0, Math.max(0, ROWS * TILE - view.h)); cam.look = 0; cam.fall = 0;
  setTimeout(() => iris(0, 1, 0.8, playerScreen()), 30);
  $('#dropTotal').textContent = stats.total; $('#dropCount').textContent = 0;
  $('#levelTag').textContent = `${level.sub} · ${level.name}`;
  $('#bossBar').classList.add('hidden');
  renderHud(); Snd.playMusic(level.music); Snd.wind(true, level.wind);
  showBanner(level.sub, level.name);
}

function makePlayer(x, y) {
  const hp = D().masks + save.up.masks;
  const scarf = []; for (let i = 0; i < 10; i++) scarf.push({ x: x + 14, y: y + 16, px: x + 14, py: y + 16 });
  return { x, y, w: 26, h: 54, vx: 0, vy: 0, face: 1, ground: false, coyote: 0, buffer: 0, jumps: 0, jumpT: 0, jumpHeld: false,
    dashT: 0, dashCd: 0, canDash: true, perfectT: 0, counterT: 0, inv: 0, hp, maxHp: hp, soul: 0, atkCd: 0, atkT: 0, atkDir: 's', atkHits: null, slashFx: 0, combo: 0, comboT: 0, atkKind: 'light', atkPower: 1, dashAttack: false,
    wall: 0, wallT: 0, lockT: 0, healT: 0, victoryT: 0, dead: false, deadT: 0, scarf, run: 0, sq: 1, stepT: 0, onPlat: null, wasGround: false };
}

// ===== الرسم المسبق للبلاط =====
function prerenderTiles() {
  const c = document.createElement('canvas');
  c.width = level.w * TILE; c.height = ROWS * TILE;
  const g = c.getContext('2d'), P = level.pal, r = srand(level.id * 97);
  const solidAt = (x, y) => x < 0 || x >= level.w || y < 0 || y >= ROWS ? true : level.g[y][x] === '#';
  for (let ty = 0; ty < ROWS; ty++) for (let tx = 0; tx < level.w; tx++) {
    const ch = level.g[ty][tx], x = tx * TILE, y = ty * TILE;
    if (ch === '#') {
      g.fillStyle = P.body; g.fillRect(x, y, TILE, TILE);
      g.strokeStyle = P.line; g.lineWidth = 1.5;
      for (let k = 0; k < 2; k++) { const yy = y + 12 + k * 20 + r() * 6; g.beginPath(); g.moveTo(x, yy); g.bezierCurveTo(x + 16, yy + r() * 6 - 3, x + 32, yy + r() * 6 - 3, x + TILE, yy); g.stroke(); }
      for (let k = 0; k < 5; k++) { g.fillStyle = r() < 0.5 ? 'rgba(255,240,210,0.07)' : 'rgba(0,0,0,0.12)'; g.beginPath(); g.arc(x + r() * TILE, y + r() * TILE, 1 + r() * 3, 0, 7); g.fill(); }
    } else if (ch === '=') {
      g.fillStyle = P.stone2; g.fillRect(x, y, TILE, TILE);
      g.fillStyle = P.stone; g.fillRect(x + 2, y + 2, TILE - 4, TILE - 8);
      g.fillStyle = 'rgba(255,255,255,0.14)'; g.fillRect(x + 2, y + 2, TILE - 4, 4);
      g.strokeStyle = P.line; g.lineWidth = 2; g.strokeRect(x + 1, y + 1, TILE - 2, TILE - 2);
      g.strokeStyle = 'rgba(0,0,0,0.18)'; g.lineWidth = 1.5; const cx = x + 24, cy = y + 21;
      g.beginPath(); for (let a = 0; a < 8; a++) { const ang = a * Math.PI / 4, rr = a % 2 ? 6 : 11; g.lineTo(cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr); } g.closePath(); g.stroke();
    } else if (ch === '-') {
      g.fillStyle = '#6b4424'; g.fillRect(x, y + 4, TILE, 12);
      g.fillStyle = '#8c5d33'; g.fillRect(x, y + 4, TILE, 5);
      g.strokeStyle = '#3d2412'; g.lineWidth = 1; for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(x + k * 16 + 8, y + 5); g.lineTo(x + k * 16 + 8, y + 15); g.stroke(); }
    } else if (ch === '^') {
      for (let k = 0; k < 3; k++) {
        const sx = x + k * 16;
        const gr = g.createLinearGradient(0, y + 16, 0, y + TILE); gr.addColorStop(0, '#e9dcc4'); gr.addColorStop(1, P.stone2);
        g.fillStyle = gr; g.beginPath(); g.moveTo(sx, y + TILE); g.lineTo(sx + 8, y + 14 + r() * 6); g.lineTo(sx + 16, y + TILE); g.fill();
        g.strokeStyle = 'rgba(0,0,0,0.3)'; g.stroke();
      }
    }
  }
  // خامة مرسومة فوق الصخر
  const tex = IMG['tex' + level.id];
  if (tex) {
    const pat = g.createPattern(tex, 'repeat');
    g.save(); g.globalCompositeOperation = 'overlay'; g.fillStyle = pat;
    for (let ty = 0; ty < ROWS; ty++) for (let tx = 0; tx < level.w; tx++) {
      const ch = level.g[ty][tx];
      if (ch === '#') { g.globalAlpha = 0.85; g.fillRect(tx * TILE, ty * TILE, TILE, TILE); }
      else if (ch === '=') { g.globalAlpha = 0.45; g.fillRect(tx * TILE + 2, ty * TILE + 2, TILE - 4, TILE - 4); }
    }
    g.restore();
  }
  // تظليل عمقي
  g.globalCompositeOperation = 'source-atop';
  if (level.dark) {
    // في الكهف: نظلّل كل خلية حسب بعدها عن الفراغ
    for (let ty = 0; ty < ROWS; ty++) for (let tx = 0; tx < level.w; tx++) {
      if (level.g[ty][tx] !== '#') continue;
      let d = 9; for (let k = 1; k < 5; k++) { if (!solidAt(tx + k, ty) || !solidAt(tx - k, ty) || !solidAt(tx, ty + k) || !solidAt(tx, ty - k)) { d = k; break; } }
      if (d > 1) { g.fillStyle = `rgba(5,8,14,${Math.min(0.92, (d - 1) * 0.3)})`; g.fillRect(tx * TILE, ty * TILE, TILE, TILE); }
    }
  } else {
    const dg = g.createLinearGradient(0, (ROWS - 6) * TILE, 0, ROWS * TILE);
    dg.addColorStop(0, 'rgba(0,0,0,0)'); dg.addColorStop(0.45, P.body2 + '99'); dg.addColorStop(1, P.dark);
    g.fillStyle = dg; g.fillRect(0, (ROWS - 6) * TILE, c.width, 6 * TILE);
  }
  g.globalCompositeOperation = 'source-over';
  // حواف: قشرة علوية، حواف سفلية (هوابط)، وجوانب
  for (let ty = 0; ty < ROWS; ty++) for (let tx = 0; tx < level.w; tx++) {
    if (level.g[ty][tx] !== '#') continue;
    const x = tx * TILE, y = ty * TILE;
    if (!solidAt(tx, ty - 1) && ty > 0) {
      g.fillStyle = P.top2; g.beginPath(); g.moveTo(x - 2, y + 14);
      for (let k = 0; k <= 6; k++) g.lineTo(x + k * 8, y + 13 + Math.sin((tx * 6 + k) * 1.3) * 3 + 3);
      g.lineTo(x + TILE + 2, y - 2); g.lineTo(x - 2, y - 2); g.fill();
      g.fillStyle = P.top; g.beginPath(); g.moveTo(x - 2, y + 8);
      for (let k = 0; k <= 6; k++) g.lineTo(x + k * 8, y + 7 + Math.sin((tx * 6 + k) * 0.9) * 2.5);
      g.lineTo(x + TILE + 2, y - 3); g.quadraticCurveTo(x + TILE / 2, y - 6, x - 2, y - 3); g.fill();
      g.fillStyle = 'rgba(255,255,255,0.16)'; g.fillRect(x, y - 3, TILE, 2);
    }
    if (!solidAt(tx, ty + 1)) {
      g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(x, y + TILE - 6, TILE, 6);
      if (r() < 0.45) { g.fillStyle = P.body2; const sx = x + 8 + r() * 30, len = 8 + r() * 18; g.beginPath(); g.moveTo(sx - 6, y + TILE - 2); g.lineTo(sx, y + TILE + len); g.lineTo(sx + 6, y + TILE - 2); g.fill(); }
    }
    if (!solidAt(tx - 1, ty)) { g.fillStyle = 'rgba(255,255,255,0.06)'; g.fillRect(x, y, 4, TILE); g.fillStyle = 'rgba(0,0,0,0.15)'; g.fillRect(x + 4, y, 2, TILE); }
    if (!solidAt(tx + 1, ty)) { g.fillStyle = 'rgba(0,0,0,0.28)'; g.fillRect(x + TILE - 5, y, 5, TILE); }
  }
  // عشب حيّ يتمايل ويُقصّ (يُرسم كل إطار)
  if (!level.grass) {
    level.grass = []; const rg = srand(level.id * 331);
    for (let tx = 0; tx < level.w; tx++) for (let ty = 1; ty < ROWS; ty++) {
      if (level.g[ty][tx] === '#' && level.g[ty - 1][tx] === ' ' && rg() < 0.42) {
        const n = 1 + (rg() < 0.4 ? 1 : 0);
        for (let q = 0; q < n; q++) level.grass.push({ x: tx * TILE + 6 + rg() * 36, y: ty * TILE + 1, h: 10 + rg() * 12, n: 4 + (rg() * 4 | 0), ph: rg() * 7, b: 0, cut: false, hue: rg() });
      }
    }
  }
  return c;
}
function prerenderFar() {
  if (level.far !== 'dunes') return null;
  const w = 2400, h = 360, c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'), r = srand(5);
  for (let layer = 0; layer < 2; layer++) {
    g.fillStyle = layer ? 'rgba(196,128,62,0.95)' : 'rgba(224,164,92,0.75)';
    g.beginPath(); g.moveTo(0, h);
    for (let x = 0; x <= w; x += 20) g.lineTo(x, h - 110 + layer * 60 - Math.sin(x / (230 - layer * 60) + layer) * 45 - Math.sin(x / 90) * 8);
    g.lineTo(w, h); g.fill();
  }
  for (let i = 0; i < 9; i++) drawPalm(g, r() * w, h - 70 - r() * 30, 0.6 + r() * 0.4, 'rgba(90,60,30,0.8)');
  return c;
}
function drawPalm(g, x, y, s, col) {
  g.save(); g.translate(x, y); g.scale(s, s); g.strokeStyle = col; g.lineWidth = 6;
  g.beginPath(); g.moveTo(0, 70); g.quadraticCurveTo(8, 30, 2, 0); g.stroke();
  for (let a = 0; a < 7; a++) { const ang = -Math.PI / 2 + (a - 3) * 0.45; g.beginPath(); g.moveTo(2, 0); g.quadraticCurveTo(2 + Math.cos(ang) * 30, Math.sin(ang) * 30 - 6, 2 + Math.cos(ang) * 52, Math.sin(ang) * 30 + 18); g.lineWidth = 4; g.stroke(); }
  g.restore();
}

// ===== الفيزياء =====
const PH = { run: 330, acc: 7000, air: 5200, dec: 9000, grav: 2600, gravFall: 3100, fall: 1050, jump: 560, jumpHold: 0.2, djump: 520, djumpHold: 0.14, dash: 800, dashT: 0.19, slide: 170, wjx: 380 };
function surfaces() { return ents.filter(e => e.type === 'mplat' || (e.type === 'crumble' && e.st !== 'gone' && e.st !== 'fall')); }
function moveX(o, dx) {
  o.x += dx;
  const t0 = Math.floor(o.y / TILE), t1 = Math.floor((o.y + o.h - 1) / TILE);
  if (dx > 0) { const tx = Math.floor((o.x + o.w) / TILE); for (let ty = t0; ty <= t1; ty++) if (isSolidCh(tileAt(tx, ty))) { o.x = tx * TILE - o.w; o.vx = 0; return 1; } }
  else if (dx < 0) { const tx = Math.floor(o.x / TILE); for (let ty = t0; ty <= t1; ty++) if (isSolidCh(tileAt(tx, ty))) { o.x = (tx + 1) * TILE; o.vx = 0; return -1; } }
  return 0;
}
function moveY(o, dy, oneway = true) {
  const prevBottom = o.y + o.h; o.y += dy;
  const l = Math.floor(o.x / TILE), rr = Math.floor((o.x + o.w - 1) / TILE);
  if (dy > 0) {
    const ty = Math.floor((o.y + o.h) / TILE);
    for (let tx = l; tx <= rr; tx++) { const c = tileAt(tx, ty); if (isSolidCh(c) || (oneway && c === '-' && prevBottom <= ty * TILE + 1)) { o.y = ty * TILE - o.h; o.vy = 0; return 'down'; } }
  } else if (dy < 0) {
    const ty = Math.floor(o.y / TILE);
    for (let tx = l; tx <= rr; tx++) if (isSolidCh(tileAt(tx, ty))) { o.y = (ty + 1) * TILE; o.vy = 0; return 'up'; }
  }
  return null;
}
function physBody(o, dt, grav = 2400) {
  o.vy = Math.min(1000, o.vy + grav * dt);
  const hit = moveX(o, (o.vx + (o.kb || 0)) * dt);
  o.ground = false;
  const r = moveY(o, o.vy * dt); if (r === 'down') o.ground = true;
  if (o.kb) { o.kb *= Math.pow(0.001, dt); if (Math.abs(o.kb) < 5) o.kb = 0; }
  return hit;
}
function touchingWall(p, dir) {
  const tx = dir > 0 ? Math.floor((p.x + p.w + 1) / TILE) : Math.floor((p.x - 1) / TILE);
  const t0 = Math.floor((p.y + 6) / TILE), t1 = Math.floor((p.y + p.h - 8) / TILE);
  for (let ty = t0; ty <= t1; ty++) if (isSolidCh(tileAt(tx, ty))) return true;
  return false;
}

// ===== اللاعب =====
function attackBox(p) {
  const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
  const reach = 84 + save.up.blade * 6 + (p.atkKind === 'heavy' ? 16 : p.combo * 4);
  if (p.atkDir === 'u') return { x: cx - 34, y: p.y - 70, w: 68, h: 82 };
  if (p.atkDir === 'd') return { x: cx - 34, y: p.y + p.h - 12, w: 68, h: 82 };
  return p.face > 0 ? { x: cx, y: cy - 30, w: reach, h: 56 } : { x: cx - reach, y: cy - 30, w: reach, h: 56 };
}
function updatePlayer(dt) {
  const p = player;
  if (p.dead) { p.deadT += dt; return; }
  const locked = (cutscene && cutscene.lock) || state.dialog;
  const L = input.left && !locked, R = input.right && !locked;
  p.inv = Math.max(0, p.inv - dt); p.dashCd = Math.max(0, p.dashCd - dt); p.perfectT = Math.max(0, p.perfectT - dt); p.counterT = Math.max(0, p.counterT - dt); p.victoryT = Math.max(0, p.victoryT - dt); p.atkCd = Math.max(0, p.atkCd - dt); p.lockT = Math.max(0, p.lockT - dt);
  p.coyote -= dt; p.buffer -= dt; p.slashFx = Math.max(0, p.slashFx - dt); p.comboT = Math.max(0, p.comboT - dt);
  if (input.jumpP && !locked) p.buffer = 0.13;
  p.abuf = Math.max(0, (p.abuf || 0) - dt); p.dbuf = Math.max(0, (p.dbuf || 0) - dt); p.castT = Math.max(0, (p.castT || 0) - dt);
  if (input.attackP) p.abuf = 0.14; if (input.dashP) p.dbuf = 0.12;
  if (input.heavyP) p.hbuf = 0.14;
  if (input.spellP && !locked) castSpell(p);

  // الشفاء (التركيز)
  const cost = 33;
  if (input.heal && !locked && p.ground && p.soul >= cost && p.hp < p.maxHp && p.dashT <= 0) {
    if (p.healT === 0) Snd.sfx('healc');
    p.healT += dt; p.vx = 0;
    if (Math.random() < 0.6) { const a = rand(0, 7); parts.push({ x: p.x + p.w / 2 + Math.cos(a) * 50, y: p.y + p.h / 2 + Math.sin(a) * 50, vx: -Math.cos(a) * 110, vy: -Math.sin(a) * 110, life: 0.42, t: 0, size: 3, color: '#dff6ff', g: 0, drag: 1, glow: true }); }
    const need = save.up.focus ? 0.6 : 0.95;
    if (p.healT >= need) { p.healT = 0; p.soul -= cost; p.hp++; Snd.sfx('heal'); emit(p.x + p.w / 2, p.y + p.h / 2, 24, { color: '#ffffff', glow: true, g: -60, min: 40, max: 160 }); renderHud(true); flash(0.12); }
    updateScarf(dt); renderSoul(); return;
  } else p.healT = 0;

  // الاندفاع
  if (p.dbuf > 0 && hasDash() && p.canDash && p.dashCd <= 0 && !locked) {
    p.dbuf = 0; p.abuf = 0; p.hbuf = 0; p.atkT = 0; p.dashT = PH.dashT; p.perfectT = 0.14; p.dashAttack = input.attackP; p.canDash = false; p.dashCd = 0.42; p.vy = 0;
    let dir = L ? -1 : R ? 1 : p.face; if (p.wall) dir = -p.wall;
    p.face = dir; p.vx = dir * PH.dash; p.wall = 0; Snd.sfx('dash'); shake(2); sparks.push({ x: p.x + p.w / 2 - dir * 10, y: p.y + p.h / 2, t: 0, ring: true, life: 0.2, r: 0.45 }); emit(p.x + p.w / 2, p.y + p.h - 6, 8, { color: '#fff0d0', angle: dir > 0 ? Math.PI : 0, spread: 0.5, min: 80, max: 220, g: -40, lmax: 0.35, smin: 2, smax: 4 });
    emit(p.x + p.w / 2, p.y + p.h / 2, 12, { color: '#f6e2b0', g: 0, min: 20, max: 90, lmax: 0.4 });
  }
  // الهجوم
  if ((p.abuf > 0 || p.hbuf > 0) && p.atkCd <= 0 && !locked && p.dashT <= 0) {
    const heavy = p.hbuf > 0;
    p.abuf = 0; p.hbuf = 0; p.atkKind = heavy ? 'heavy' : 'light';
    p.atkDir = input.up ? 'u' : (input.down && !p.ground) ? 'd' : 's';
    if (p.wall && p.atkDir === 's') p.face = -p.wall;
    if (heavy) { p.combo = 0; p.comboT = 0; p.atkT = 0.2; p.atkCd = 0.58; p.atkPower = 3 + save.up.blade; p.slashFx = 0.22; Snd.sfx('bosshit'); }
    else { p.combo = p.comboT > 0 ? (p.combo % 4) + 1 : 1; p.comboT = 0.42; p.atkT = 0.08 + p.combo * 0.018; p.atkCd = 0.24; p.atkPower = 1 + save.up.blade + (p.combo === 4 ? 1 : 0) + (p.counterT > 0 ? 1 : 0); p.counterT = 0; p.slashFx = 0.14; Snd.sfx('slash'); }
    p.atkHits = new Set(); p.slashAlt = !p.slashAlt;
  }
  if (p.dashT > 0) {
    p.dashT -= dt; p.vy = 0;
    if (p.dashAttack && p.atkT <= 0) { p.dashAttack = false; p.atkKind = 'dash'; p.atkPower = 2 + save.up.blade; p.atkT = 0.14; p.atkCd = 0.3; p.atkHits = new Set(); p.slashFx = 0.16; Snd.sfx('slash'); }
    if (Math.random() < 0.8) parts.push({ x: p.x + p.w / 2, y: p.y + p.h * 0.4 + rand(-10, 10), vx: -p.face * 40, vy: 0, life: 0.3, t: 0, size: 4, color: '#c7372f', g: 0, drag: 0.9 });
    if (p.dashT <= 0) p.vx = p.face * PH.run * 0.8;
  } else {
    if (p.lockT <= 0) {
      const acc = p.ground ? PH.acc : PH.air;
      if (L && !R) { p.vx = Math.max(-PH.run, p.vx - acc * dt); if (p.atkT <= 0) p.face = -1; }
      else if (R && !L) { p.vx = Math.min(PH.run, p.vx + acc * dt); if (p.atkT <= 0) p.face = 1; }
      else { const f = PH.dec * dt; p.vx = Math.abs(p.vx) <= f ? 0 : p.vx - Math.sign(p.vx) * f; }
    }
    // الجاذبية مع الارتفاع المتحكَّم
    p.jumpMin = Math.max(0, (p.jumpMin || 0) - dt);
    if (p.jumpHeld && (input.jump || p.jumpMin > 0) && p.jumpT > 0) { p.jumpT -= dt; p.vy = Math.min(p.vy, -p.jumpV); }
    else { if (p.jumpHeld && !input.jump && p.vy < 0) p.vy *= 0.42; p.jumpHeld = false; const apex = input.jump && Math.abs(p.vy) < 120 ? 0.55 : 1; p.vy += (p.vy < 0 ? PH.grav : PH.gravFall) * apex * dt; }
    // الانزلاق على الجدار
    p.wall = 0;
    if (level.wall && !p.ground && p.vy > 0) {
      if (L && touchingWall(p, -1)) p.wall = -1; else if (R && touchingWall(p, 1)) p.wall = 1;
      if (p.wall) { p.vy = Math.min(p.vy, PH.slide); p.face = -p.wall; p.jumps = 1; p.canDash = true; if (Math.random() < 0.3) emit(p.wall > 0 ? p.x + p.w : p.x, p.y + p.h - 10, 1, { color: level.pal.top, g: 200, min: 10, max: 40, lmax: 0.3 }); }
    }
    p.vy = Math.min(p.vy, PH.fall);
  }
  // القفز
  const doJump = (v, hold) => { p.vy = -v; p.jumpV = v; p.jumpT = hold; p.jumpMin = 0.075; p.jumpHeld = true; p.sq = 1.25; };
  if (p.buffer > 0 && !locked) {
    if (p.ground || p.coyote > 0) {
      doJump(PH.jump, PH.jumpHold); p.ground = false; p.coyote = 0; p.buffer = 0; p.jumps = 1; p.onPlat = null; Snd.sfx('jump'); emit(p.x + p.w / 2, p.y + p.h, 7, { color: level.pal.top, angle: -Math.PI / 2, spread: 2.2, min: 40, max: 130, g: 300, lmax: 0.4, smin: 2, smax: 4 });
      emit(p.x + p.w / 2, p.y + p.h, 8, { color: level.pal.top, angle: -Math.PI / 2, spread: 1.2, min: 40, max: 120, g: 500 });
    } else if (p.wall || (level.wall && (touchingWall(p, -1) || touchingWall(p, 1)) && !p.ground)) {
      const w = p.wall || (touchingWall(p, 1) ? 1 : -1);
      doJump(PH.jump, 0.16); p.vx = -w * PH.wjx; p.face = -w; p.lockT = 0.14; p.buffer = 0; p.wall = 0; p.jumps = 1; p.canDash = true; Snd.sfx('wjump');
      emit(w > 0 ? p.x + p.w : p.x, p.y + p.h / 2, 8, { color: '#ffffff', angle: w > 0 ? Math.PI : 0, spread: 0.8, min: 40, max: 120, lmax: 0.3 });
    } else if (p.jumps < 2 && p.dashT <= 0) {
      doJump(PH.djump, PH.djumpHold); p.jumps = 2; p.buffer = 0; Snd.sfx('djump'); sparks.push({ x: p.x + p.w / 2, y: p.y + p.h, t: 0, ring: true, life: 0.22, r: 0.4 });
      emit(p.x + p.w / 2, p.y + p.h, 12, { color: '#ffffff', g: 0, min: 50, max: 120, lmax: 0.35, smax: 3 });
    }
  }
  // الحركة والتصادم
  p.wasGround = p.ground; p.ground = false;
  if (p.onPlat) { moveX(p, p.onPlat.mx); if (p.onPlat.my > 0) moveY(p, p.onPlat.my); }
  const steps = Math.ceil(Math.abs(p.vx * dt) / 12) || 1;
  for (let i = 0; i < steps; i++) moveX(p, p.vx * dt / steps);
  const vsteps = Math.ceil(Math.abs(p.vy * dt) / 12) || 1, prevBottom = p.y + p.h;
  const vy0 = p.vy;
  for (let i = 0; i < vsteps; i++) { const r = moveY(p, p.vy * dt / vsteps); if (r === 'down') { p.ground = true; break; } if (r === 'up') { if (cornerNudge(p)) { p.vy = vy0; continue; } p.jumpT = 0; break; } }
  p.onPlat = null;
  if (p.vy >= 0) for (const s of surfaces()) {
    if (p.x + p.w > s.x + 2 && p.x < s.x + s.w - 2 && prevBottom <= s.y + 6 + Math.max(0, s.my || 0) && p.y + p.h >= s.y) {
      p.y = s.y - p.h; p.vy = 0; p.ground = true; p.onPlat = s;
      if (s.type === 'crumble' && s.st === 'idle') { s.st = 'shake'; s.t = 0; Snd.sfx('crumble'); }
    }
  }
  if (p.ground) {
    p.coyote = 0.1; p.jumps = 0; p.canDash = true;
    if (!p.wasGround) { p.sq = 0.75; Snd.sfx('land'); emit(p.x + p.w / 2, p.y + p.h, 6, { color: level.pal.top, angle: -Math.PI / 2, spread: 1.4, min: 30, max: 90, g: 400, lmax: 0.4 }); }
  }
  p.sq = lerp(p.sq, 1, 0.15);
  if (p.ground && Math.abs(p.vx) > 40) {
    p.run += dt * Math.abs(p.vx) / 30; p.stepT -= dt;
    if (p.stepT <= 0) { p.stepT = 0.26; Snd.sfx('step'); emit(p.x + p.w / 2 - p.face * 8, p.y + p.h - 2, 2, { color: level.pal.top, angle: -Math.PI / 2 - p.face * 0.6, spread: 0.8, min: 20, max: 70, g: -10, lmax: 0.45, smin: 2, smax: 4.5, drag: 0.94 }); }
  } else if (p.ground) p.run = 0;

  // حدود
  if (p.x < 0) p.x = 0;
  if (arena && arena.started && !arena.done) p.x = clamp(p.x, arena.x0, arena.x1 - p.w);
  if (p.y > ROWS * TILE + 60) { hurt(1, null, true); return; }

  // ضربة الجنبية
  if (p.atkT > 0) { p.atkT -= dt; resolveAttack(p); }

  // الأشواك
  const l = Math.floor((p.x + 4) / TILE), rr = Math.floor((p.x + p.w - 4) / TILE), ty = Math.floor((p.y + p.h - 4) / TILE);
  for (let tx = l; tx <= rr; tx++) if (tileAt(tx, ty) === '^' && (p.y + p.h) - ty * TILE > 18 && p.dashT <= 0) { hurt(1, null, false, true); break; }
  updateScarf(dt);
}

function resolveAttack(p) {
  const box = attackBox(p); cutGrass(box);
  let pogo = false, recoil = false;
  for (const e of ents) {
    if (p.atkHits.has(e)) continue;
    if (e.enemy && e.alive && overlap(box, e)) { p.atkHits.add(e); damageEnemy(e, p.atkPower || 1); if (p.atkDir === 'd') pogo = true; else recoil = true; }
    else if (e.type === 'jar' && !e.broken && overlap(box, e)) { p.atkHits.add(e); breakJar(e); }
  }
  if (boss && !boss.dead && !p.atkHits.has(boss)) {
    for (const hb of boss.hurt()) if (overlap(box, hb)) { p.atkHits.add(boss); boss.damage(p.atkPower || 1, box); if (p.atkDir === 'd') pogo = true; else recoil = true; break; }
  }
  for (const pr of projectiles) if (!pr.wave && !p.atkHits.has(pr) && pr.r && Math.abs(pr.x - (box.x + box.w / 2)) < box.w / 2 + pr.r && Math.abs(pr.y - (box.y + box.h / 2)) < box.h / 2 + pr.r && pr.parry !== false) {
    p.atkHits.add(pr); pr.dead = true; Snd.sfx('clink'); emit(pr.x, pr.y, 10, { color: '#fff3c0', glow: true }); if (p.atkDir === 'd') pogo = true;
  }
  if (p.atkDir === 'd' && !pogo) {
    const l = Math.floor(box.x / TILE), r = Math.floor((box.x + box.w) / TILE), t = Math.floor((box.y + box.h - 30) / TILE), b2 = Math.floor((box.y + box.h) / TILE);
    for (let ty = t; ty <= b2 && !pogo; ty++) for (let tx = l; tx <= r; tx++) if (tileAt(tx, ty) === '^') { pogo = true; Snd.sfx('clink'); emit(tx * TILE + 24, ty * TILE + 20, 8, { color: '#fff' }); break; }
  }
  if (p.atkDir === 's' && !recoil) {
    const tx = p.face > 0 ? Math.floor((box.x + box.w - 20) / TILE) : Math.floor((box.x + 20) / TILE), tyy = Math.floor((box.y + box.h / 2) / TILE);
    if (isSolidCh(tileAt(tx, tyy)) && !p.atkHits.has('wall')) { p.atkHits.add('wall'); Snd.sfx('clink'); emit(p.face > 0 ? tx * TILE : tx * TILE + TILE, box.y + box.h / 2, 6, { color: '#fff4d8', min: 60, max: 180, lmax: 0.25, smax: 3 }); }
  }
  if (pogo) { p.vy = -760; p.jumpHeld = false; p.jumps = 1; p.canDash = true; p.atkT = 0; Snd.sfx('pogo'); }
  if (recoil) { p.vx = -p.face * ((p.atkKind === 'heavy' || p.atkKind === 'dash') ? 120 : 220); p.lockT = p.atkKind === 'heavy' ? 0.12 : 0.06; }
}

function updateScarf(dt) {
  const p = player, s = p.scarf;
  const td = window.Zayd3D && Zayd3D.ok; s[0].x = p.x + p.w / 2 - p.face * (td ? 5 : 3); s[0].y = td ? p.y + p.h - (p.healT > 0 ? 54 : 64) * p.sq : p.y + 16 + (1 - p.sq) * 10;
  const t = performance.now() / 1000, d2 = dt * dt;
  const wind = -p.face * (700 + Math.min(600, Math.abs(p.vx) * 2)) - 250;
  for (let i = 1; i < s.length; i++) {
    const q = s[i]; const vx = (q.x - q.px) * 0.95, vy = (q.y - q.py) * 0.95;
    q.px = q.x; q.py = q.y;
    q.x += vx + (wind + Math.sin(t * 5 + i * 0.7) * 300) * d2;
    q.y += vy + (320 + Math.sin(t * 8 + i * 0.9) * 900) * d2;
  }
  for (let k = 0; k < 4; k++) for (let i = 1; i < s.length; i++) {
    const a = s[i - 1], b = s[i]; const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1;
    const diff = (d - 6) / d; b.x -= dx * diff; b.y -= dy * diff;
  }
}

function gainSoul(n) { const p = player; const was = p.soul; p.soul = Math.min(99, p.soul + n * (save.up.soul ? 1.5 : 1)); if (was < 33 && p.soul >= 33) Snd.sfx('heart'); renderSoul(); }
function damageEnemy(e, dmg, noSoul) {
  const p = player; hitSpark(e.x + e.w / 2, e.y + e.h / 2); e.hp -= dmg; e.flash = 0.12; hitStop = Math.max(hitStop, 0.045);
  const dir = Math.sign(e.x + e.w / 2 - (p.x + p.w / 2)) || p.face;
  if (e.type === 'bat' || e.type === 'spirit' || e.type === 'wisp') { e.vx = dir * 260; e.vy = p.atkDir === 'd' ? 200 : p.atkDir === 'u' ? -200 : -60; e.kbT = 0.18; }
  else if (e.type !== 'ghoul' || e.st !== 'charge') e.kb = dir * ((p.atkKind === 'heavy' ? 520 : p.atkKind === 'dash' ? 420 : e.type === 'ghoul' ? 180 : 320));
  Snd.sfx('hit'); shake(3); if (!noSoul) gainSoul(11);
  emit(e.x + e.w / 2, e.y + e.h / 2, 10, { color: '#ffffff', min: 80, max: 260, lmax: 0.25, smax: 3, g: 0 });
  if (e.hp <= 0) killEnemy(e);
}
function killEnemy(e) {
  e.alive = false; e.deadT = 0; stats.kills++; unlockAchievement('firstBlood'); shake(6); Snd.sfx('stomp'); hitStop = Math.max(hitStop, 0.085);
  { const p = player, ang = Math.atan2(e.y + e.h / 2 - (p.y + p.h / 2), e.x + e.w / 2 - (p.x + p.w / 2));
    sparks.push({ x: e.x + e.w / 2, y: e.y + e.h / 2, t: 0, a: ang, big: true, life: 0.26 }, { x: e.x + e.w / 2, y: e.y + e.h / 2, t: 0, ring: true, life: 0.35 }); }
  const col = { bat: '#9a7ab8', spirit: '#f0c060', wisp: '#ff8a4a', spider: '#6a4a8a', ghoul: '#8a9a7a', soldier: '#a09070' }[e.type] || '#c07a3a';
  emit(e.x + e.w / 2, e.y + e.h / 2, 24, { color: col, min: 60, max: 280, glow: e.type === 'spirit' || e.type === 'wisp' });
  const c = EN[e.type].coins; dropCoins(e.x + e.w / 2, e.y + e.h / 2, irand(c[0], c[1]));
}
function dropCoins(x, y, n) {
  const big = Math.floor(n / 5), small = n - big * 5;
  for (let i = 0; i < big + small; i++) ents.push({ type: 'coin', x: x - 6, y: y - 6, w: 12, h: 12, vx: rand(-160, 160), vy: rand(-520, -260), val: i < big ? 5 : 1, t: 0, ground: false });
}
function breakJar(e) {
  e.broken = true; Snd.sfx('crumble'); Snd.sfx('clink');
  emit(e.x + 16, e.y + 20, 16, { color: '#b87a4a', min: 60, max: 240, smax: 5 });
  dropCoins(e.x + 16, e.y + 16, irand(5, 12));
}

function hurt(dmg, src, fall = false, spike = false) {
  const p = player;
  if (p.dead || state.mode !== 'play') return;
  if (!fall && !spike && p.dashT > 0) { if (p.perfectT > 0) perfectDodge(p); return; }
  if (!fall && !spike && p.inv > 0) return;
  if (spike && p.inv > 0) { safeSpot(); return; }
  p.hp -= dmg; p.inv = 1.3; p.healT = 0; Snd.sfx('hurt'); shake(10); renderHud(false, p.hp);
  hitStop = Math.max(hitStop, 0.22); flash(0.18, '#000');
  emit(p.x + p.w / 2, p.y + p.h / 2, 16, { color: '#1a1a1a', min: 60, max: 240 });
  if (p.hp <= 0) { die(); return; }
  if (fall || spike) { safeSpot(); return; }
  const dir = src ? Math.sign(p.x + p.w / 2 - src) || -p.face : -p.face;
  p.vx = dir * 380; p.vy = -420; p.lockT = 0.2; p.jumpHeld = false; p.dashT = 0;
}
function perfectDodge(p) {
  p.perfectT = 0; p.counterT = 0.65; p.inv = Math.max(p.inv, 0.32); hitStop = Math.max(hitStop, 0.1);
  Snd.sfx('clink'); flash(0.08, '#9fe6ff'); shake(2);
  sparks.push({ x: p.x + p.w / 2, y: p.y + p.h / 2, t: 0, ring: true, life: 0.3, r: 0.65 });
  floatText(p.x + p.w / 2, p.y - 12, 'مراوغة مثالية', '#9fe6ff');
}
// عند السقوط أو الشوك: يعود إلى آخر أرض آمنة
function safeSpot() { const p = player; const s = p.safe || respawn; p.x = s.x; p.y = s.y; p.vx = p.vy = 0; p.inv = Math.max(p.inv, 1.0); resetScarf(); }
function resetScarf() { const p = player; p.scarf.forEach(q => { q.x = q.px = p.x + 13; q.y = q.py = p.y + 16; }); }
function die() {
  const p = player; p.dead = true; p.deadT = 0; stats.deaths++; save.totalDeaths++;
  saveGame();
  Snd.sfx('death'); Snd.stopVoice(); subtitle(null);
  emit(p.x + p.w / 2, p.y + p.h / 2, 40, { color: '#c7372f', min: 60, max: 300 });
  // حقيبة الدنانير تبقى مكان السقوط
  ents = ents.filter(e => e.type !== 'bag');
  if (save.dinars > 0) {
    const s = p.safe || respawn;
    ents.push({ type: 'bag', x: (p.y > ROWS * TILE ? s.x : p.x), y: (p.y > ROWS * TILE ? s.y : p.y) + 20, w: 34, h: 34, val: save.dinars, t: 0 });
    save.dinars = 0; renderHud();
  }
  setTimeout(() => iris(1, 0, 0.55, playerScreen(), () => { respawnAtRest(); updateCam(1); iris(0, 1, 0.6, playerScreen()); }), 700);
}
// انتقال دائري حول عبسي
let irisAnim = 0;
function playerScreen() {
  if (!player) return [50, 50];
  const st = $('#stage'), w = st.clientWidth || 1, h = st.clientHeight || 1;
  return [((player.x + player.w / 2 - cam.x) * scale) / w * 100, ((player.y + player.h / 2 - cam.y) * scale) / h * 100];
}
function iris(from, to, dur, at, done) {
  const el = $('#iris'), id = ++irisAnim, t0 = performance.now();
  el.style.setProperty('--ix', at[0].toFixed(1) + '%'); el.style.setProperty('--iy', at[1].toFixed(1) + '%'); el.style.opacity = 1;
  const step = (now) => {
    if (id !== irisAnim) return;
    const k = Math.min(1, (now - t0) / (dur * 1000)), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    const v = from + (to - from) * e;
    el.style.setProperty('--r', (v * 150).toFixed(2) + '%');
    if (k < 1) requestAnimationFrame(step);
    else { if (to >= 1) el.style.opacity = 0; if (done) done(); }
  };
  requestAnimationFrame(step);
}
function respawnAtRest() {
  const p = player;
  if (arena && arena.started && !arena.done) resetArena();
  ents.forEach(e => { if (e.type === 'ambush' && e.st === 'fight') resetAmbush(e); });
  p.dead = false; p.hp = p.maxHp; p.x = respawn.x; p.y = respawn.y; p.vx = p.vy = 0; p.inv = 1.5; p.soul = 0; p.safe = null;
  resetScarf(); renderHud(); renderSoul(); cutscene = null;
  if (!arena || !arena.started) Snd.playMusic(level.music);
}

// ===== الكيانات =====
function enemyContact(e, box) {
  const p = player, b = box || e;
  const pb = { x: p.x + 4, y: p.y + 6, w: p.w - 8, h: p.h - 10 }, eb = box ? b : { x: e.x + e.w * 0.12, y: e.y + e.h * 0.15, w: e.w * 0.76, h: e.h * 0.8 };
  if (!overlap(pb, eb)) return;
  hurt(1, e.x + e.w / 2);
}
function updateEnts(dt) {
  const p = player;
  for (const e of ents) {
    e.t = (e.t || 0) + dt;
    if (XU[e.type]) { XU[e.type](e, dt, p); continue; }
    if (e.enemy) {
      if (!e.alive) { e.deadT += dt; continue; }
      e.flash = Math.max(0, e.flash - dt);
      if (Math.abs(e.x - p.x) > 1400 && e.type !== 'spirit') continue;
      AI[e.type](e, dt, p);
      continue;
    }
    switch (e.type) {
      case 'drop':
        if (!e.got && overlap(p, e)) { e.got = true; stats.drops++; save.totalDrops++; $('#dropCount').textContent = stats.drops; Snd.sfx('drop'); gainSoul(4); emit(e.x + 12, e.y + 14, 10, { color: '#7fdcf5', glow: true, g: -60, min: 30, max: 100 }); }
        break;
      case 'heart':
        if (!e.got && overlap(p, e)) { e.got = true; p.hp = Math.min(p.maxHp, p.hp + 1); renderHud(true); Snd.sfx('heart'); }
        break;
      case 'coin': {
        const dx = p.x + p.w / 2 - e.x, dy = p.y + p.h / 2 - e.y, d = Math.hypot(dx, dy);
        if (e.t > 0.35 && d < 110) { e.x += dx / d * 520 * dt; e.y += dy / d * 520 * dt; e.vy = 0; }
        else { e.vx *= e.ground ? 0.8 : 0.99; physBody(e, dt, 1600); if (e.ground && Math.abs(e.vy) < 1) e.vx *= 0.9; }
        if (e.t > 0.25 && overlap(p, e)) { e.got = true; addDinars(e.val); renderHud(); Snd.sfx('coin'); }
        if (e.t > 25) e.got = true;
        break; }
      case 'bag':
        if (overlap(p, e) && !p.dead) { e.got = true; addDinars(e.val); renderHud(); Snd.sfx('bag'); floatText(e.x + 17, e.y - 6, `+${e.val} دينار`, '#ffd27a'); emit(e.x + 17, e.y + 17, 20, { color: '#ffd27a', glow: true, g: -50 }); }
        break;
      case 'mplat': {
        const ox = e.x, oy = e.y, k = (1 - Math.cos(e.t * e.speed)) / 2;
        e.x = e.ox + e.dx * k; e.y = e.oy + e.dy * k; e.mx = e.x - ox; e.my = e.y - oy; break; }
      case 'crumble':
        if (e.st === 'shake' && e.t > 0.5) { e.st = 'fall'; e.t = 0; e.vy = 0; emit(e.x + e.w / 2, e.y + 10, 14, { color: level.pal.stone }); }
        else if (e.st === 'fall') { e.vy += 1800 * dt; e.y += e.vy * dt; if (e.t > 1.2) { e.st = 'gone'; e.t = 0; } }
        else if (e.st === 'gone' && e.t > 2.6) { e.st = 'idle'; e.y = e.oy; e.t = 0; }
        e.mx = e.my = 0; break;
      case 'spring':
        if (p.vy > 0 && overlap(p, e) && p.y + p.h < e.y + e.h + 4) { p.vy = -1250; p.jumpHeld = false; p.jumps = 1; p.canDash = true; e.boing = 0.3; p.sq = 1.4; Snd.sfx('spring'); }
        if (e.boing) e.boing = Math.max(0, e.boing - dt);
        break;
      case 'rest':
        if (!e.on && overlap(p, e)) {
          ents.forEach(o => { if (o.type === 'rest') o.on = false; });
          e.on = true; respawn = { x: e.x + 26, y: e.y + e.h - player.h - 2 }; Snd.sfx('checkpoint');
          p.hp = p.maxHp; renderHud(true);
          emit(e.x + 40, e.y + 40, 24, { color: '#ffd27a', glow: true, g: -40, min: 40, max: 140 });
          floatText(e.x + 40, e.y - 10, 'استراحة — حُفِظ التقدّم', '#ffd27a');
        }
        break;
      case 'tablet':
        e.near = Math.abs(p.x + p.w / 2 - (e.x + e.w / 2)) < 70 && Math.abs(p.y - e.y) < 110;
        if (e.near && !e.seen) { e.seen = true; Snd.sfx('tablet'); }
        break;
      case 'npc':
        e.near = Math.abs(p.x + p.w / 2 - (e.x + e.w / 2)) < 90 && Math.abs(p.y + p.h - (e.y + e.h)) < 60;
        if (e.near && input.upP && !state.dialog && p.ground) talk(e);
        break;
      case 'letter':
        if (!e.got && overlap(p, e)) {
          e.got = true; save.letters.add(e.id); if (save.letters.size >= 8) unlockAchievement('archivist'); saveGame(); Snd.sfx('page'); renderHud();
          emit(e.x + 16, e.y + 15, 20, { color: '#ffe7b0', glow: true, g: -40 });
          Dialog.open(`رسالةٌ من الجدّ عامر (${save.letters.size}/8)`, [`<span class="letter-text">${LETTERS[e.id]}</span>`], null);
        }
        break;
      case 'gate':
        if (overlap(p, { x: e.x + 40, y: e.y + 40, w: 30, h: e.h - 40 }) && !cutscene) levelComplete();
        break;
      case 'gem':
        e.vy = Math.min((e.vy || 0) + 600 * dt, 400); e.y = Math.min(e.y + e.vy * dt, arena.gy - 80);
        if (overlap(p, e) && !e.got) { e.got = true; Snd.sfx('gem'); flash(1); finalVictory(); }
        break;
    }
  }
  if (ents.some(e => e.got || (e.broken && e.type === 'jar' && (e.bt = (e.bt || 0) + dt) > 0.01) || (e.enemy && !e.alive && e.deadT > 1))) ents = ents.filter(e => !e.got && !(e.enemy && !e.alive && e.deadT > 1) && !(e.type === 'jar' && e.broken));
  // آخر أرض آمنة
  if (p.ground && !p.onPlat && p.inv <= 0) {
    const tx = Math.floor((p.x + p.w / 2) / TILE), ty = Math.floor((p.y + p.h + 2) / TILE);
    if (isSolidCh(tileAt(tx, ty)) && isSolidCh(tileAt(Math.floor(p.x / TILE), ty)) && isSolidCh(tileAt(Math.floor((p.x + p.w) / TILE), ty))) p.safe = { x: p.x, y: p.y };
  }
  // تلميحات
  const t = ents.find(e => e.type === 'tablet' && e.near);
  const n = ents.find(e => e.type === 'npc' && e.near);
  const hint = t ? t.text : n && !state.dialog ? `اضغط <b>↑</b> للتحدّث مع ${NPCS[n.id].name}` : '';
  if (hint) { if ($('#hint').dataset.cur !== hint) { $('#hintText').innerHTML = hint; $('#hint').dataset.cur = hint; $('#hint').classList.remove('hidden'); } }
  else if ($('#hint').dataset.cur) { $('#hint').dataset.cur = ''; $('#hint').classList.add('hidden'); }
}
function talk(e) {
  const n = NPCS[e.id]; save.met[e.id] = true;
  Dialog.open(n.name, n.lines, n.img);
}

// ===== ذكاء الأعداء =====
function patrol(e, dt, speed) {
  if (e.vx === 0) e.vx = -speed;
  e.vx = Math.sign(e.vx) * speed;
  const hit = physBody(e, dt);
  if (hit || (e.min !== undefined && (e.x < e.min || e.x + e.w > e.max))) { e.vx = -e.vx; if (e.min !== undefined) e.x = clamp(e.x, e.min, e.max - e.w); }
  const front = e.vx > 0 ? e.x + e.w + 2 : e.x - 2, below = Math.floor((e.y + e.h + 4) / TILE);
  if (e.ground && (!isSolidCh(tileAt(Math.floor(front / TILE), below)) || tileAt(Math.floor(front / TILE), below - 1) === '^')) e.vx = -e.vx;
  e.dir = Math.sign(e.vx) || e.dir;
}
function fireball(x, y, tx, ty, sp = 260, parry = true) {
  const d = Math.hypot(tx - x, ty - y) || 1;
  projectiles.push({ x, y, vx: (tx - x) / d * sp, vy: (ty - y) / d * sp, g: 0, r: 12, life: 4, fire: true, parry });
}
const AI = {
  scorpion(e, dt, p) {
    e.stT = (e.stT || 0) + dt;
    const dx = p.x + p.w / 2 - (e.x + e.w / 2), near = Math.abs(dx) < 260 && Math.abs(p.y - e.y) < 80;
    if (e.st === 'attack_w') {
      e.vx = 0; if (e.stT > 0.38) { e.st = 'attack'; e.stT = 0; Snd.sfx('charge'); }
    } else if (e.st === 'attack') {
      e.vx = 0; if (e.stT < 0.16) enemyContact(e); else { e.st = 'recover'; e.stT = 0; }
    } else if (e.st === 'recover') {
      e.vx = 0; if (e.stT > 0.42) { e.st = 'idle'; e.stT = 0; }
    } else {
      patrol(e, dt, near ? 140 : 70);
      if (near && Math.abs(dx) < 92 && e.ground && e.stT > 0.8) { e.st = 'attack_w'; e.stT = 0; e.dir = Math.sign(dx) || e.dir; e.vx = 0; Snd.sfx('charge'); }
    }
    enemyContact(e);
  },
  minion(e, dt, p) { if (Math.sign(p.x - e.x) !== Math.sign(e.vx) && Math.random() < 0.03) e.vx = -e.vx; patrol(e, dt, 150); enemyContact(e); },
  bat(e, dt, p) {
    if (e.kbT > 0) { e.kbT -= dt; e.x += e.vx * dt; e.y += e.vy * dt; e.vx *= 0.9; e.vy *= 0.9; enemyContact(e); return; }
    if (e.st === 'dive_w') {
      e.stT += dt; e.x = lerp(e.x, e.sx, dt * 4); e.y = lerp(e.y, e.sy, dt * 4); e.dir = Math.sign(e.tx - e.sx) || e.dir;
      if (e.stT > 0.32) { e.st = 'swoop'; e.stT = 0; Snd.sfx('throw'); }
    } else if (e.st === 'swoop') {
      e.stT += dt; const k = e.stT / 1.1;
      e.x = lerp(e.sx, e.tx, k); e.y = e.sy + Math.sin(k * Math.PI) * (e.ty - e.sy); e.dir = Math.sign(e.tx - e.sx);
      if (k >= 1) { e.st = 'idle'; e.stT = 0; e.bx = e.x - Math.sin(e.t * 1.4) * e.range; e.by = e.sy; }
    } else {
      const tx = e.bx + Math.sin(e.t * 1.4) * e.range, ty = e.by + Math.sin(e.t * 3.2) * 16;
      e.x = lerp(e.x, tx, dt * 4); e.y = lerp(e.y, ty, dt * 4); e.dir = Math.cos(e.t * 1.4) > 0 ? 1 : -1;
      e.stT += dt;
      if (e.stT > 1.6 && Math.abs(p.x - e.x) < 300 && p.y > e.y - 20 && p.y - e.y < 320) { e.st = 'dive_w'; e.stT = 0; e.sx = e.x; e.sy = e.y; e.tx = e.x + (p.x - e.x) * 2; e.ty = p.y + 10; Snd.sfx('charge'); }
    }
    enemyContact(e);
  },
  spirit(e, dt, p) {
    const dx = p.x - e.x, dy = p.y - e.y - 10, d = Math.hypot(dx, dy) || 1;
    if (e.kbT > 0) { e.kbT -= dt; } else if (d < 560) { e.vx = lerp(e.vx, dx / d * 95, dt * 1.6); e.vy = lerp(e.vy, dy / d * 75, dt * 1.6); } else { e.vx *= 0.95; e.vy *= 0.95; }
    e.x += e.vx * dt; e.y += e.vy * dt + Math.sin(e.t * 2.5) * 0.4; e.dir = e.vx > 0 ? 1 : -1;
    if (Math.random() < 0.4) parts.push({ x: e.x + e.w / 2 + rand(-10, 10), y: e.y + e.h - 8, vx: rand(-20, 20), vy: rand(10, 40), life: 0.6, t: 0, size: 2.5, color: '#e8b75a', g: 0, drag: 0.98 });
    enemyContact(e);
  },
  ghoul(e, dt, p) {
    e.stT += dt;
    const sameLevel = Math.abs(p.y + p.h - (e.y + e.h)) < 110, dist = Math.abs(p.x - e.x);
    if (e.st === 'idle') {
      patrol(e, dt, 50);
      if (sameLevel && dist < 360 && e.stT > 1) { e.st = 'wind'; e.stT = 0; e.dir = Math.sign(p.x - e.x); e.vx = 0; Snd.sfx('roar'); }
    } else if (e.st === 'wind') {
      e.vx = 0; physBody(e, dt);
      if (e.stT > 0.55) { e.st = 'charge'; e.stT = 0; Snd.sfx('charge'); }
    } else if (e.st === 'charge') {
      e.vx = e.dir * 460; const hit = physBody(e, dt);
      const front = e.dir > 0 ? e.x + e.w + 2 : e.x - 2, below = Math.floor((e.y + e.h + 4) / TILE);
      if (Math.random() < 0.6) emit(e.x + e.w / 2, e.y + e.h, 1, { color: level.pal.top, angle: -Math.PI / 2, spread: 0.6, min: 30, max: 90, lmax: 0.35 });
      if (hit || e.stT > 1.0 || !isSolidCh(tileAt(Math.floor(front / TILE), below))) { e.st = 'stun'; e.stT = 0; e.vx = 0; if (hit) { shake(5); Snd.sfx('stomp'); } }
    } else if (e.st === 'stun') { e.vx = 0; physBody(e, dt); if (e.stT > 0.9) { e.st = 'idle'; e.stT = 0; e.vx = -e.dir * 50; } }
    enemyContact(e);
  },
  wisp(e, dt, p) {
    if (e.kbT > 0) { e.kbT -= dt; e.x += e.vx * dt; e.y += e.vy * dt; e.vx *= 0.9; e.vy *= 0.9; e.hx = e.x; e.hy = e.y; }
    const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    const want = d < 220 ? -1 : d > 360 ? 1 : 0;
    e.hx += (dx / d) * want * 60 * dt; e.hy += (dy / d) * want * 40 * dt;
    e.x = lerp(e.x, e.hx + Math.sin(e.t * 1.7) * 30, dt * 3); e.y = lerp(e.y, e.hy + Math.sin(e.t * 2.3) * 20, dt * 3);
    e.dir = dx > 0 ? 1 : -1;
    if (d < 520) {
      e.shotT -= dt;
      if (e.shotT < 0.45 && !e.charging) { e.charging = true; }
      if (e.shotT <= 0) { e.charging = false; e.shotT = rand(1.8, 2.6); Snd.sfx('fire'); fireball(e.x + e.w / 2, e.y + e.h / 2, p.x + p.w / 2, p.y + p.h / 2, 250); }
    }
    if (Math.random() < 0.5) parts.push({ x: e.x + e.w / 2 + rand(-8, 8), y: e.y + e.h - 6, vx: rand(-15, 15), vy: rand(-60, -20), life: 0.5, t: 0, size: 3, color: Math.random() < 0.5 ? '#ff9a3a' : '#ff4fa0', g: -40, drag: 0.97, glow: true });
    enemyContact(e);
  },
  spider(e, dt, p) {
    if (e.st === 'hang') {
      e.y = e.hy + 6 + Math.sin(e.t * 2) * 6;
      if (Math.abs(p.x + p.w / 2 - (e.x + e.w / 2)) < 90 && p.y > e.y) { e.st = 'drop'; e.vy = 0; Snd.sfx('throw'); }
    } else if (e.st === 'drop') { physBody(e, dt, 2600); if (e.ground) { e.st = 'walk'; e.vx = Math.sign(p.x - e.x) * 120; shake(2); } }
    else { if (Math.sign(p.x - e.x) !== Math.sign(e.vx) && Math.random() < 0.03) e.vx = -e.vx; patrol(e, dt, 125); }
    enemyContact(e);
  },
  soldier(e, dt, p) {
    e.stT += dt;
    const dist = p.x + p.w / 2 - (e.x + e.w / 2), sameLevel = Math.abs(p.y + p.h - (e.y + e.h)) < 90;
    if (e.st === 'idle') {
      if (sameLevel && Math.abs(dist) < 420) { e.dir = Math.sign(dist); e.vx = e.dir * 95; } else e.vx = 0;
      physBody(e, dt);
      const front = e.dir > 0 ? e.x + e.w + 2 : e.x - 2, below = Math.floor((e.y + e.h + 4) / TILE);
      if (!isSolidCh(tileAt(Math.floor(front / TILE), below))) { e.x -= e.vx * dt; e.vx = 0; }
      if (sameLevel && Math.abs(dist) < 80 && e.stT > 0.6) { e.st = 'wind'; e.stT = 0; e.vx = 0; }
    } else if (e.st === 'wind') { e.vx = 0; physBody(e, dt); if (e.stT > 0.42) { e.st = 'slash'; e.stT = 0; Snd.sfx('slash'); } }
    else if (e.st === 'slash') {
      physBody(e, dt);
      const box = e.dir > 0 ? { x: e.x + e.w - 6, y: e.y + 10, w: 72, h: 60 } : { x: e.x - 66, y: e.y + 10, w: 72, h: 60 };
      e.box = box; if (overlap(player, box)) hurt(1, e.x + e.w / 2);
      if (e.stT > 0.18) { e.st = 'rec'; e.stT = 0; e.box = null; }
    } else if (e.st === 'rec') { physBody(e, dt); if (e.stT > 0.75) { e.st = 'idle'; e.stT = 0; } }
    enemyContact(e);
  },
};

// ===== الزعماء =====
const BOSS_INFO = {
  queen: { name: 'ملكةُ العقارب', sub: 'حارسةُ الوادي', music: 'queen' },
  serpent: { name: 'ثعبانةُ برهوت', sub: 'حارسةُ البئر', music: 'serpent' },
  sultan: { name: 'سلطانُ الرمال', sub: 'شدّادُ، ملكُ إرم', music: 'boss' },
};
function startArena() {
  arena.started = true;
  const colL = arena.tx0 - 1, colR = arena.tx1 + 1, top = Math.max(0, Math.floor((arena.gy - 14 * TILE) / TILE));
  arena.saved = [];
  for (let y = top; y < Math.floor(arena.gy / TILE); y++) for (const x of [colL, colR]) { arena.saved.push([x, y, level.g[y][x]]); level.g[y][x] = '#'; }
  tileCanvas = prerenderTiles();
  cam.lock = true;
  const info = BOSS_INFO[arena.boss];
  boss = BOSSES[arena.boss]();
  Snd.playMusic(info.music); Snd.sfx('bosstitle'); shake(10);
  bossTitle(info.name, info.sub);
  $('#bossName').textContent = info.name;
  $('#bossBar').classList.remove('hidden'); $('#bossFill').style.width = '100%';
}
function resetArena() {
  for (const [x, y, c] of arena.saved) level.g[y][x] = c;
  arena.started = false; arena.saved = []; boss = null; projectiles = []; hazards = [];
  ents = ents.filter(e => !e.minion);
  tileCanvas = prerenderTiles(); cam.lock = null; $('#bossBar').classList.add('hidden'); subtitle(null); Snd.stopVoice();
}
function bossHpBar() { if (boss) $('#bossFill').style.width = Math.max(0, boss.hp / boss.maxHp * 100) + '%'; }
function bossHit(b, dmg) {
  { const pb = attackBox(player); hitSpark(pb.x + pb.w / 2, pb.y + pb.h / 2); }
  b.hp -= dmg; b.flash = 0.12; hitStop = Math.max(hitStop, 0.05); Snd.sfx('hit'); shake(3); gainSoul(11); bossHpBar();
}
function bossDefeat(b, after) {
  b.dead = true; b.deadAt = performance.now(); player.victoryT = 2.4; unlockAchievement('bossHunter'); Snd.sfx('bossdie'); Snd.stopMusic(); shake(14); flash(0.6); hitStop = 0.5;
  projectiles = []; hazards = []; ents.forEach(e => { if (e.minion && e.alive) killEnemy(e); });
  $('#bossBar').classList.add('hidden');
  setTimeout(after, 1600);
}
function bossContact(boxes, dmg = 1) { for (const b of boxes) if (overlap(player, b)) { hurt(dmg, b.x + b.w / 2); return; } }
function openArena() {
  for (const [x, y, c] of arena.saved) level.g[y][x] = c;
  arena.done = true; tileCanvas = prerenderTiles(); cam.lock = null;
}

const BOSSES = {
  // --- ملكة العقارب ---
  queen() {
    const A = arena, hp = Math.round(24 * D().bhp);
    const b = { hp, maxHp: hp, x: A.x1 - 280, y: A.gy - 110, w: 210, h: 110, vx: 0, vy: 0, dir: -1, st: 'intro', t: 0, flash: 0, last: '', n: 0, air: false,
      hurt() { return [{ x: b.x + 10, y: b.y + 10, w: b.w - 20, h: b.h - 10 }]; },
      damage(d) { if (b.dead || b.st === 'intro') return; bossHit(b, d); if (b.hp <= 0) bossDefeat(b, () => { dropCoins(b.x + b.w / 2, b.y, 60); ents.push({ type: 'gate', x: A.x1 - 190, y: A.gy - 152, w: 112, h: 152, t: 0 }); openArena(); if (!save.bought.queenMask) { save.bought.queenMask = true; ents.push(makeShrine('mask', b.x + b.w / 2, A.gy)); } Snd.playMusic('victory'); floatText(b.x + b.w / 2, b.y - 20, 'انتصار!', '#ffd27a'); }); },
      update(dt) {
        if (b.dead) return;
        b.t += dt; b.flash = Math.max(0, b.flash - dt);
        const p = player, cx = b.x + b.w / 2, sp = b.hp < b.maxHp / 2 ? 1.35 : 1;
        const pick = () => { const opts = ['charge', 'sting', 'leap', b.hp < b.maxHp * 0.75 ? 'summon' : 'charge'].filter(o => o !== b.last); b.last = opts[irand(0, opts.length - 1)]; b.st = b.last + '_w'; b.t = 0; b.n = 0; };
        if (!b.air) b.dir = p.x + p.w / 2 < cx ? -1 : 1;
        switch (b.st) {
          case 'intro': if (b.t > 1.6) { b.st = 'idle'; b.t = 0; } break;
          case 'idle': if (b.t > 0.75 / sp) pick(); break;
          case 'charge_w': if (b.t > 0.6 / sp) { b.st = 'charge'; b.t = 0; b.vx = b.dir * 600 * sp; Snd.sfx('charge'); } break;
          case 'charge':
            b.x += b.vx * dt; b.dir = Math.sign(b.vx);
            if (Math.random() < 0.8) emit(b.x + (b.vx > 0 ? 0 : b.w), A.gy, 1, { color: level.pal.top, angle: -Math.PI / 2, spread: 0.7, min: 40, max: 140, lmax: 0.4 });
            if (b.x < A.x0 + 4 || b.x + b.w > A.x1 - 4) { b.x = clamp(b.x, A.x0 + 4, A.x1 - 4 - b.w); b.st = 'stun'; b.t = 0; shake(12); Snd.sfx('stomp'); for (let i = 0; i < 4; i++) projectiles.push({ x: rand(A.x0 + 60, A.x1 - 60), y: A.gy - 560, vx: 0, vy: 0, g: 1400, r: 14, life: 3, rock: true, parry: true }); }
            break;
          case 'stun': if (b.t > 0.9 / sp) { b.st = 'idle'; b.t = 0; } break;
          case 'sting_w': if (b.t > 0.35) { b.st = 'sting'; b.t = 0; b.n = 0; } break;
          case 'sting':
            if (b.t > 0.45 / sp * b.n && b.n < (sp > 1 ? 5 : 3)) { b.n++; hazards.push({ kind: 'sting', x: p.x + p.w / 2 - 32 + p.vx * 0.2, w: 64, t: 0, warn: 0.6 / sp, up: 0.28, top: A.gy - 600 }); Snd.sfx('throw'); }
            if (b.t > 0.45 / sp * 5 + 1.2) { b.st = 'idle'; b.t = 0; }
            break;
          case 'leap_w': if (b.t > 0.4 / sp) { b.st = 'leap'; b.t = 0; b.air = true; const T = 0.85; const tx = clamp(p.x + p.w / 2 - b.w / 2, A.x0 + 10, A.x1 - b.w - 10); b.vx = (tx - b.x) / T; b.vy = -0.5 * 2600 * T; Snd.sfx('jump'); } break;
          case 'leap':
            b.vy += 2600 * dt; b.x += b.vx * dt; b.y += b.vy * dt;
            if (b.y >= A.gy - b.h && b.vy > 0) {
              b.y = A.gy - b.h; b.air = false; b.st = 'stun'; b.t = 0.3; shake(14); Snd.sfx('erupt');
              for (const d of [-1, 1]) projectiles.push({ wave: true, x: cx + d * 60, y: A.gy - 40, w: 40, h: 40, vx: d * 400 * sp, life: 4 });
            }
            break;
          case 'summon_w': if (b.t > 0.7) { b.st = 'idle'; b.t = -0.4; Snd.sfx('roar'); const alive = ents.filter(e => e.minion && e.alive).length; for (let i = 0; i < Math.min(2, 3 - alive); i++) { const m = makeEnemy('minion', i ? A.x0 + 30 : A.x1 - 80, A.gy - 28, { minion: true, vx: i ? 150 : -150 }); ents.push(m); emit(m.x + 20, m.y, 14, { color: level.pal.top }); } } break;
        }
        b.x = clamp(b.x, A.x0, A.x1 - b.w);
        if (b.st !== 'intro') bossContact(b.hurt());
      },
      draw() {
        const t = performance.now() / 1000, img = IMG.queen, dw = 290, dh = img ? dw * img.height / img.width : 190;
        const bob = b.st === 'charge' ? Math.sin(t * 40) * 3 : Math.sin(t * 3) * 2;
        const rear = b.st === 'charge_w' || b.st === 'leap_w' ? -0.12 : b.st === 'stun' ? 0.05 : 0;
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(b.x + b.w / 2, A.gy, 130, 12, 0, 0, 7); ctx.fill();
        if (window.M3D && M3D.ok && opts.hq !== false) { ctx.save(); if (b.st === 'charge_w' || b.st === 'leap_w') ctx.translate(rand(-2, 2), 0); M3D.drawQueen(ctx, b, A.gy, scale * dpr); ctx.restore(); return; }
        ctx.save(); if (b.flash > 0) ctx.filter = 'brightness(2.3) saturate(0.3)';
        if (b.st === 'charge_w' || b.st === 'leap_w') ctx.translate(rand(-2, 2), 0);
        drawSprite(img, b.x + b.w / 2 - dw / 2, b.y + b.h - dh + 8 + bob, dw, dh, b.dir > 0, 1, rear * (b.dir > 0 ? -1 : 1));
        ctx.restore();
      },
    };
    return b;
  },

  // --- ثعبانة برهوت ---
  serpent() {
    const A = arena, hp = Math.round(28 * D().bhp);
    const b = { hp, maxHp: hp, x: (A.x0 + A.x1) / 2, top: A.gy, st: 'intro', t: 0, flash: 0, seq: 0, dir: -1, lx: 0, ly: 0,
      hurt() {
        if (b.st === 'lunge') return [{ x: b.lx - 80, y: b.ly - 40, w: 160, h: 80 }];
        if (b.top < A.gy - 40) return [{ x: b.x - 48, y: b.top, w: 96, h: A.gy - b.top }];
        return [];
      },
      damage(d) { if (b.dead || b.st === 'intro' || b.st === 'hidden' || b.st === 'warn') return; bossHit(b, d); if (b.hp <= 0) bossDefeat(b, () => { b.gone = true; dropCoins(b.x, A.gy - 100, 70); ents.push({ type: 'gate', x: A.x1 - 200, y: A.gy - 152, w: 112, h: 152, t: 0 }); openArena(); if (!save.abil.spell) ents.push(makeShrine('spell', (A.x0 + A.x1) / 2, A.gy)); Snd.playMusic('victory'); }); },
      update(dt) {
        if (b.dead) { b.top = Math.min(A.gy + 40, b.top + 200 * dt); return; }
        b.t += dt; b.flash = Math.max(0, b.flash - dt);
        const p = player, sp = b.hp < b.maxHp / 2 ? 1.3 : 1, pat = ['dive', 'dive', 'lunge', 'dive', 'volley'];
        const next = () => { const k = pat[b.seq++ % pat.length]; b.mode = k; b.st = 'hidden'; b.t = 0; b.fired = 0;
          if (k === 'dive') b.tx = clamp(p.x + p.w / 2, A.x0 + 60, A.x1 - 60);
          else if (k === 'lunge') { b.dir = p.x > (A.x0 + A.x1) / 2 ? 1 : -1; b.tx = b.dir > 0 ? A.x0 + 40 : A.x1 - 40; }
          else b.tx = (A.x0 + A.x1) / 2 + rand(-200, 200); };
        switch (b.st) {
          case 'intro': b.top = lerp(b.top, A.gy - 320, dt * 2); if (b.t > 2) { b.st = 'sink'; b.t = 0; } break;
          case 'hidden': b.top = A.gy + 20; b.x = lerp(b.x, b.tx, dt * 6); if (b.t > 0.35) { b.st = 'warn'; b.t = 0; b.x = b.tx; Snd.sfx('rumble'); } break;
          case 'warn':
            if (Math.random() < 0.8) emit(b.x + rand(-50, 50), A.gy, 1, { color: level.pal.top, angle: -Math.PI / 2, spread: 0.4, min: 60, max: 180, lmax: 0.4 });
            if (b.mode === 'dive' && b.t < 0.4) b.x = lerp(b.x, clamp(p.x + p.w / 2, A.x0 + 60, A.x1 - 60), dt * 3);
            if (b.t > 0.8 / sp) { if (b.mode === 'lunge') { b.st = 'lunge'; b.t = 0; b.lx = b.x; b.ly = A.gy - 48; Snd.sfx('roar'); } else { b.st = 'rise'; b.t = 0; Snd.sfx('erupt'); shake(8); } }
            break;
          case 'rise': b.top = lerp(b.top, A.gy - 330, dt * 14); if (b.t > 0.3) { b.st = 'up'; b.t = 0; } break;
          case 'up': {
            b.top = A.gy - 330 + Math.sin(b.t * 3) * 8;
            const shots = b.mode === 'volley' ? 5 : sp > 1 ? 2 : 0;
            if (b.fired < shots && b.t > 0.35 + b.fired * 0.28) { b.fired++; Snd.sfx('throw');
              const T = 1.0, g = 1100, tx = b.mode === 'volley' ? rand(A.x0 + 40, A.x1 - 40) : p.x + p.w / 2;
              projectiles.push({ x: b.x, y: b.top + 40, vx: (tx - b.x) / T, vy: (A.gy - 10 - b.top - 40 - 0.5 * g * T * T) / T, g, r: 13, life: 3, acid: true, parry: true }); }
            if (b.t > (b.mode === 'volley' ? 2.2 : 1.5) / sp) { b.st = 'sink'; b.t = 0; }
            break; }
          case 'sink': b.top = lerp(b.top, A.gy + 30, dt * 7); if (b.t > 0.5) next(); break;
          case 'lunge':
            break;
        }
        if (b.st === 'lunge') {
          const v = (b.dir > 0 ? 1 : -1) * 660 * sp; b.lx = (b.lx0 === undefined ? (b.lx0 = b.lx) : b.lx) + v * dt; b.ly = A.gy - 50 + Math.sin(b.t * 10) * 10;
          if (Math.random() < 0.9) emit(b.lx, A.gy, 2, { color: level.pal.top, angle: -Math.PI / 2, spread: 0.6, min: 60, max: 200, lmax: 0.5 });
          if (b.lx < A.x0 - 100 || b.lx > A.x1 + 100) { b.lx0 = undefined; next(); }
        }
        if (b.st !== 'intro') bossContact(b.hurt());
      },
      draw() {
        if (b.gone) return;
        const img = IMG.serpent, t = performance.now() / 1000;
        if (window.M3D && M3D.ok && opts.hq !== false) { if (b.st === 'lunge' || b.top < A.gy + 10) M3D.drawSerpent(ctx, b, A.gy, player, scale * dpr); return; }
        ctx.save(); if (b.flash > 0) ctx.filter = 'brightness(2.3) saturate(0.3)';
        if (b.dead) ctx.globalAlpha = 0.6;
        if (b.st === 'lunge' && img) {
          const w = 380, h = w * img.height / img.width;
          ctx.translate(b.lx, b.ly); ctx.rotate(b.dir > 0 ? Math.PI / 2 : -Math.PI / 2); if (b.dir > 0) ctx.scale(-1, 1);
          ctx.drawImage(img, -w / 2, -h * 0.15, w, h);
        } else if (img && b.top < A.gy + 10) {
          const h = 420, w = h * img.width / img.height;
          drawSprite(img, b.x - w / 2, b.top - 20, w, h, player.x > b.x, ctx.globalAlpha, Math.sin(t * 2) * 0.04);
        }
        ctx.restore();
      },
    };
    return b;
  },

  // --- سلطان الرمال (شدّاد) ---
  sultan() {
    const A = arena, hp = Math.round(40 * D().bhp);
    const b = { hp, maxHp: hp, x: A.x1 - 300, y: A.gy - 420, w: 170, h: 250, st: 'intro', t: 0, flash: 0, pat: 0, sink: 0, dir: -1, phase: 1, baseY: A.gy - 300,
      hurt() { if (b.st === 'phase' || b.st === 'intro' || b.st === 'die') return []; const cx = b.x + b.w / 2, top = b.y + 20; return [{ x: cx - 50, y: top, w: 100, h: 60, head: true }, { x: cx - 60, y: top + 55, w: 120, h: Math.max(20, Math.min(b.h - 70, A.gy - top - 55)) }]; },
      damage(d, box) {
        if (b.st === 'phase' || b.st === 'intro' || b.st === 'die') return;
        bossHit(b, b.st === 'tired' ? d * 2 : d);
        if (b.hp <= 0) { b.st = 'die'; b.t = 0; Snd.sfx('bossdie'); Snd.stopMusic(); projectiles = []; hazards = []; $('#bossBar').classList.add('hidden'); ents.forEach(e => { if (e.minion && e.alive) killEnemy(e); }); }
        else if (b.phase === 1 && b.hp <= b.maxHp / 2) { b.phase = 2; b.st = 'phase'; b.t = 0; projectiles = []; hazards = []; phaseTwo(); }
      },
      update(dt) {
        b.t += dt; b.flash = Math.max(0, b.flash - dt);
        const p = player, cx = b.x + b.w / 2, sp = (b.phase === 2 ? 1.35 : 1) + (b.maxHp - b.hp) / b.maxHp * 0.25;
        if (Math.random() < 0.7) parts.push({ x: cx + rand(-60, 60), y: b.y + b.h - rand(0, 60), vx: rand(-60, 60), vy: rand(-30, 30), life: 0.8, t: 0, size: rand(2, 4), color: '#d9b36a', g: -20, drag: 0.97 });
        b.dir = p.x < cx ? -1 : 1;
        const atks = b.phase === 2 ? ['volley', 'hands', 'spikes', 'wave', 'summon'] : ['volley', 'spikes', 'wave'];
        switch (b.st) {
          case 'intro':
            b.y = lerp(b.y, b.baseY, dt * 1.5);
            if (!b.spoke && b.t > 0.8) { b.spoke = true; cutscene = { lock: true }; subtitle('سلطانُ الرمال:', 'مَن يجرؤُ على دخولِ مدينتي؟! الرمالُ لا تُعيدُ ما تأخذُه… أيُّها الصغير! ستُدفَنُ هنا… كما دُفِنَ كلُّ مَن جاءَ قبلَك!');
              Snd.voice('assets/audio/n_boss.mp3', () => { if (b.st === 'intro') { b.st = 'float'; b.t = 0; subtitle(null); cutscene = null; } }); }
            if (b.t > 17) { b.st = 'float'; b.t = 0; subtitle(null); cutscene = null; }
            break;
          case 'phase':
            b.x = lerp(b.x, (A.x0 + A.x1) / 2 - b.w / 2, dt * 2); b.y = lerp(b.y, b.baseY - 40, dt * 2); b.sink = lerp(b.sink, 0, dt * 3); shake(2);
            if (b.t > 14 || b.ready) { b.st = 'float'; b.t = 0; subtitle(null); cutscene = null; Snd.playMusic('boss2'); }
            break;
          case 'float': {
            const tx = (b.pat % 2 === 0) ? A.x1 - 260 : A.x0 + 90;
            b.x = lerp(b.x, tx, dt * 1.6); b.y = b.baseY + Math.sin(b.t * 2) * 20;
            if (b.t > 1.2 / sp) { b.st = atks[b.pat % atks.length]; b.t = 0; b.shots = 0; b.spk = false; b.wv = false; Snd.sfx('roar'); }
            break; }
          case 'volley':
            b.y = b.baseY + Math.sin(b.t * 2) * 20;
            if (b.t > 0.42 / sp * (b.shots + 1) && b.shots < 3 + b.phase * 2) {
              b.shots++; Snd.sfx('throw');
              const sx = cx, sy = b.y + 80, T = 0.95, g = 900, txp = p.x + p.w / 2 + p.vx * 0.35 + rand(-40, 40);
              projectiles.push({ x: sx, y: sy, vx: (txp - sx) / T, vy: (A.gy - 20 - sy - 0.5 * g * T * T) / T, g, r: 16, life: 3, parry: true });
            }
            if (b.shots >= 3 + b.phase * 2 && b.t > 0.42 / sp * (4 + b.phase * 2) + 0.4) toTired(b);
            break;
          case 'spikes':
            b.y = b.baseY - 40 + Math.sin(b.t * 3) * 10;
            if (!b.spk) { b.spk = true; Snd.sfx('rumble'); shake(5); const n = 3 + b.phase * 2;
              for (let i = 0; i < n; i++) { const x = i === 0 ? p.x + p.w / 2 : rand(A.x0 + 40, A.x1 - 40); hazards.push({ kind: 'pillar', x: x - 30, w: 60, t: -i * 0.25, warn: 0.8 / sp + 0.1, up: 0.9 }); } }
            if (b.t > 2.8) toTired(b);
            break;
          case 'hands':
            b.y = b.baseY - 60;
            if (!b.spk) { b.spk = true; Snd.sfx('rumble'); const dir = p.x < (A.x0 + A.x1) / 2 ? 1 : -1;
              for (let i = 0; i < 9; i++) { const x = dir > 0 ? A.x0 + 20 + i * 110 : A.x1 - 80 - i * 110; hazards.push({ kind: 'pillar', x, w: 64, t: -i * 0.16, warn: 0.55, up: 0.45 }); } }
            if (b.t > 2.6) toTired(b);
            break;
          case 'wave':
            b.y = lerp(b.y, A.gy - b.h + 30, dt * 3);
            if (b.t > 0.7 && !b.wv) { b.wv = true; Snd.sfx('erupt'); shake(6); const dir = cx > (A.x0 + A.x1) / 2 ? -1 : 1;
              projectiles.push({ wave: true, x: dir < 0 ? b.x : b.x + b.w, y: A.gy - 46, w: 46, h: 46, vx: dir * 400 * sp, life: 5 });
              if (b.phase === 2) setTimeout(() => boss === b && projectiles.push({ wave: true, x: dir < 0 ? b.x : b.x + b.w, y: A.gy - 70, w: 46, h: 70, vx: dir * 420 * sp, life: 5 }), 800); }
            if (b.t > 2.4) toTired(b);
            break;
          case 'summon':
            if (b.t > 0.5 && !b.wv) { b.wv = true; Snd.sfx('roar'); for (let i = 0; i < 2; i++) { const m = makeEnemy('spirit', i ? A.x0 + 60 : A.x1 - 100, A.gy - 260, { minion: true }); ents.push(m); } }
            if (b.t > 1.4) { b.st = 'float'; b.t = 0; b.pat++; }
            break;
          case 'tired':
            b.sink = lerp(b.sink, 1, dt * 3); b.y = lerp(b.y, A.gy - 130, dt * 3);
            if (Math.random() < 0.5) emit(cx + rand(-70, 70), A.gy, 1, { color: '#e2bf7c', angle: -Math.PI / 2, spread: 0.6, min: 40, max: 120, lmax: 0.5 });
            if (b.t > 2.4 / Math.sqrt(sp)) { b.st = 'rise'; b.t = 0; }
            break;
          case 'rise': b.sink = lerp(b.sink, 0, dt * 3); b.y = lerp(b.y, b.baseY, dt * 2.5); if (b.t > 0.8) { b.st = 'float'; b.t = 0; b.pat++; } break;
          case 'die':
            if (b.t < 2.4) { shake(5); emit(cx + rand(-80, 80), b.y + rand(0, b.h), 5, { color: Math.random() < 0.5 ? '#e8c27a' : '#8a6a3a', min: 80, max: 300, g: 200 }); }
            else if (!b.freed) {
              b.freed = true; b.dead = true; b.deadAt = performance.now(); unlockAchievement('bossHunter'); saveGame(); flash(0.8); cutscene = { lock: true };
              subtitle('شدّاد:', 'أخيراً… الرمالُ تهدأ. سامحني أيُّها الصغير… لقد نسيتُ أنّ الماءَ لا يُحبَس. خُذِ الجوهرة… وأصلِحْ ما أفسدتُ.');
              const done = () => { if (b.gemDone) return; b.gemDone = true; subtitle(null); cutscene = null; ents.push({ type: 'gem', x: cx - 24, y: A.gy - 300, w: 48, h: 60, vy: 0, t: 0 }); Snd.sfx('gem'); Snd.playMusic('victory'); arena.done = true; };
              Snd.voice('assets/audio/n_freed.mp3', done); setTimeout(done, 13000);
            }
            b.y = lerp(b.y, b.baseY - 30, dt);
            break;
        }
        if (!['intro', 'phase', 'die'].includes(b.st)) {
          const hb = b.hurt(); // الرأس لا يؤذي أثناء التعب (يمكن الارتداد عليه)
          bossContact(b.st === 'tired' ? hb.filter(h => !h.head) : hb, D().bdmg);
        }
      },
      draw() {
        const t = performance.now() / 1000, cx = b.x + b.w / 2, bob = Math.sin(t * 2.2) * 4;
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        const g = ctx.createRadialGradient(cx, b.y + 110, 10, cx, b.y + 110, 230);
        g.addColorStop(0, b.freed ? 'rgba(120,200,255,0.4)' : b.st === 'tired' ? 'rgba(90,200,255,0.35)' : b.phase === 2 ? 'rgba(255,80,40,0.35)' : 'rgba(255,140,60,0.28)'); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g; ctx.fillRect(cx - 240, b.y - 120, 480, 480); ctx.restore();
        if (window.M3D && M3D.ok && opts.hq !== false) { ctx.save(); if (b.st === 'die' && !b.freed) ctx.translate(rand(-4, 4), rand(-4, 4)); M3D.drawSultan(ctx, b, scale * dpr); ctx.restore(); }
        else {
        ctx.save();
        if (b.flash > 0) ctx.filter = 'brightness(2.2) saturate(0.4)';
        else if (b.freed) ctx.filter = 'hue-rotate(160deg) saturate(0.6) brightness(1.3)';
        else if (b.phase === 2) ctx.filter = 'saturate(1.4) hue-rotate(-12deg)';
        let a = 1; if (b.freed) a = Math.max(0, 1 - b.t / 12);
        if (b.st === 'die' && !b.freed) ctx.translate(rand(-4, 4), rand(-4, 4));
        drawSprite(IMG.boss, cx - 120, b.y - 20 + bob, 240, 360, b.dir > 0, a, Math.sin(t * 1.3) * 0.03);
        ctx.restore(); }
        if (b.st === 'tired') { const a2 = 0.6 + Math.sin(t * 8) * 0.4; ctx.strokeStyle = `rgba(127,220,245,${a2})`; ctx.lineWidth = 3; const y = b.y - 16 + Math.sin(t * 6) * 4; ctx.beginPath(); ctx.moveTo(cx - 12, y); ctx.lineTo(cx, y + 14); ctx.lineTo(cx + 12, y); ctx.stroke(); }
      },
    };
    function phaseTwo() {
      cutscene = { lock: true }; Snd.stopMusic(); Snd.sfx('roar'); shake(16); flash(0.5, '#ff6a3a');
      bossTitle('شدّاد', 'ملكُ إرم الملعون');
      subtitle('شدّاد:', 'أتظنُّ أنكَ تعرفُ الحكاية؟! أنا شدّاد… ملكُ إرم! تلكَ الجوهرةُ قلبُ مدينتي… وسأستعيدُها ولو دفنتُ الصحراءَ كلَّها!');
      Snd.voice('assets/audio/n_sultan2.mp3', () => { b.ready = true; });
      $('#bossName').textContent = 'شدّاد، ملكُ إرم';
    }
    function toTired(bb) { bb.st = 'tired'; bb.t = 0; Snd.sfx('rumble'); }
    return b;
  },
};

function updateProjectiles(dt) {
  const p = player;
  for (let i = projectiles.length - 1; i >= 0; i--) {
    const o = projectiles[i]; o.life -= dt;
    if (o.dead) { projectiles.splice(i, 1); continue; }
    if (o.wave) {
      o.x += o.vx * dt;
      if (Math.random() < 0.9) emit(o.x + o.w / 2, o.y + o.h, 2, { color: '#e2bf7c', angle: -Math.PI / 2, spread: 0.7, min: 60, max: 200, lmax: 0.5 });
      if (overlap(p, o)) hurt(1, o.x);
      if ((arena && (o.x < arena.x0 - 60 || o.x > arena.x1 + 60)) || o.life <= 0) projectiles.splice(i, 1);
      continue;
    }
    o.vy += o.g * dt; o.x += o.vx * dt; o.y += o.vy * dt;
    if (Math.random() < 0.6) parts.push({ x: o.x, y: o.y, vx: 0, vy: 0, life: 0.4, t: 0, size: 5, color: o.fire ? '#ff7a3a' : o.acid ? '#8fe07a' : '#d8a55a', g: 0, drag: 1, glow: !!o.fire });
    const hit = Math.hypot(p.x + p.w / 2 - o.x, p.y + p.h / 2 - o.y) < o.r + 16;
    if (hit) hurt(1, o.x);
    const tx = Math.floor(o.x / TILE), ty = Math.floor(o.y / TILE);
    if (hit || isSolidCh(tileAt(tx, ty)) || (arena && arena.started && o.y > arena.gy - 6) || o.life <= 0) { emit(o.x, o.y, 12, { color: o.fire ? '#ff9a4a' : o.acid ? '#9fe08a' : '#e2bf7c', min: 40, max: 180, glow: !!o.fire }); projectiles.splice(i, 1); }
  }
  for (let i = hazards.length - 1; i >= 0; i--) {
    const h = hazards[i]; h.t += dt;
    if (h.t > h.warn && h.t < h.warn + h.up) {
      if (!h.sfx) { h.sfx = true; Snd.sfx('erupt'); shake(3); }
      if (h.kind === 'sting') { const k = Math.min(1, (h.t - h.warn) / 0.08); const bot = lerp(h.top, arena.gy, k); if (overlap(p, { x: h.x + 16, y: bot - 140, w: h.w - 32, h: 140 })) hurt(1, h.x + h.w / 2); }
      else { const hh = Math.min(1, (h.t - h.warn) * 8) * 120; if (overlap(p, { x: h.x + 8, y: arena.gy - hh, w: h.w - 16, h: hh })) hurt(1, h.x + h.w / 2); }
    }
    if (h.t > h.warn + h.up + 0.3) hazards.splice(i, 1);
  }
}

// ===== الكاميرا والتأثيرات =====
function shake(n) { if (opts.shake) cam.shake = Math.max(cam.shake, n); }
function flash(a, color = '#fff') { const f = $('#flash'); f.style.background = color; f.style.transition = 'none'; f.style.opacity = a; requestAnimationFrame(() => { f.style.transition = 'opacity .6s'; f.style.opacity = 0; }); }
function updateCam(dt) {
  const p = player, maxX = Math.max(0, level.w * TILE - view.w), maxY = Math.max(0, ROWS * TILE - view.h);
  let tx, ty;
  const extra = view.h > H * 1.3 ? 170 : 0;
  if (cam.lock && arena) { tx = arena.x0 + (arena.x1 - arena.x0 - view.w) / 2; ty = arena.gy + 110 - view.h; }
  else {
    cam.look = lerp(cam.look || 0, p.face * 80 + clamp(p.vx * 0.12, -40, 40), Math.min(1, dt * 2.2));
    cam.fall = lerp(cam.fall || 0, !p.ground && p.vy > 500 ? clamp((p.vy - 500) * 0.35, 0, 170) : 0, Math.min(1, dt * 3));
    tx = p.x + p.w / 2 - view.w * 0.5 + cam.look;
    ty = p.y + p.h / 2 - view.h * 0.55 + cam.fall + (input.down && p.ground && Math.abs(p.vx) < 5 ? 140 : input.up && p.ground && Math.abs(p.vx) < 5 ? -120 : 0);
  }
  // تتبّع ناعم: أسرع كلما ابتعد اللاعب عن المركز
  const kx = Math.min(1, dt * (4 + Math.min(8, Math.abs(tx - cam.x) / 60)));
  cam.x = lerp(cam.x, clamp(tx, 0, maxX), kx);
  cam.y = lerp(cam.y, clamp(ty, Math.min(0, maxY + extra), maxY + extra), Math.min(1, dt * (level.dark ? 6 : 4)));
  cam.shake = Math.max(0, cam.shake - dt * 30);
}

// ===== الرسم =====
function drawGrass(dt) {
  const G = level.grass; if (!G) return;
  const t = performance.now() / 1000, p = player, x0 = cam.x - 30, x1 = cam.x + view.w + 30;
  const col = level.dark ? ['#3f8a7c', '#6fc2b0'] : level.id === 4 ? ['#4f5d4a', '#7d8c6a'] : level.id === 2 ? ['#6f6a2e', '#a39a45'] : ['#7c7a3a', '#b3a650'];
  ctx.lineCap = 'round';
  for (const gr of G) {
    if (gr.cut || gr.x < x0 || gr.x > x1) continue;
    // يميل بعيداً عن عبسي عند المرور
    let target = 0;
    if (p && !p.dead) { const dx = gr.x - (p.x + p.w / 2), dy = gr.y - (p.y + p.h); if (Math.abs(dx) < 34 && Math.abs(dy) < 30) target = Math.sign(dx || 1) * (1 - Math.abs(dx) / 34) * 1.0; }
    gr.b += (target - gr.b) * Math.min(1, dt * 9);
    const sw = Math.sin(t * 1.8 + gr.ph + gr.x * 0.02) * 0.16 + gr.b;
    ctx.strokeStyle = gr.hue > 0.5 ? col[1] : col[0]; ctx.lineWidth = 2;
    ctx.beginPath();
    for (let k = 0; k < gr.n; k++) {
      const off = (k - (gr.n - 1) / 2) * 2.6, hh = gr.h * (0.7 + ((k * 37 + gr.ph * 10) % 10) / 30), bend = sw + off * 0.06;
      ctx.moveTo(gr.x + off, gr.y); ctx.quadraticCurveTo(gr.x + off + bend * hh * 0.4, gr.y - hh * 0.6, gr.x + off + bend * hh, gr.y - hh * Math.cos(bend * 0.6));
    }
    ctx.stroke();
  }
}
function cutGrass(box) {
  const G = level && level.grass; if (!G) return;
  for (const gr of G) if (!gr.cut && gr.x > box.x && gr.x < box.x + box.w && gr.y > box.y && gr.y - gr.h < box.y + box.h) {
    gr.cut = true;
    emit(gr.x, gr.y - gr.h * 0.5, 5, { color: level.dark ? '#6fc2b0' : '#a39a45', angle: -Math.PI / 2, spread: 1.6, min: 80, max: 240, g: 700, lmax: 0.8, smin: 1.5, smax: 3.5 });
  }
}
function drawNearFG() {
  if (opts.q < 0.7) return;
  const vw = view.w, vh = view.h, PX = 1.3, lift = Math.max(-30, Math.min(50, (Math.max(0, ROWS * TILE - vh) - cam.y) * 0.35));
  const bot = IMG['fgb' + level.id], top = IMG['fgt' + level.id];
  if (bot) {
    const w = vw * 1.05, h = w * bot.height / bot.width; let ox = -(cam.x * PX) % w; if (ox > 0) ox -= w;
    ctx.globalAlpha = 0.9; for (let x = ox; x < vw; x += w - 1) ctx.drawImage(bot, x, vh - h * 0.5 + lift * 0.6, w, h); ctx.globalAlpha = 1;
  }
  if (top && level.id !== 1) {
    const w = vw * 1.3, h = w * top.height / top.width; let ox = -(cam.x * PX * 1.1) % w; if (ox > 0) ox -= w;
    ctx.globalAlpha = 0.9; for (let x = ox; x < vw; x += w - 1) ctx.drawImage(top, x, -h * 0.25 - Math.max(0, cam.y * 0.1), w, h); ctx.globalAlpha = 1;
  }
}
function drawBg() {
  const bg = IMG[level.bg], vw = view.w, vh = view.h;
  if (bg) {
    const PAR = 0.07, needW = vw + Math.max(0, level.w * TILE - vw) * PAR;
    let w = needW, h = w * bg.height / bg.width;
    const needH = vh + Math.max(0, ROWS * TILE - vh) * PAR * 1.5;
    if (h < needH * 1.04) { h = needH * 1.04; w = h * bg.width / bg.height; }
    const maxCamY = Math.max(0, ROWS * TILE - vh);
    const y = level.dark ? -cam.y * PAR * 1.5 : -(h - vh) * 0.55 - (cam.y - maxCamY) * 0.04;
    ctx.drawImage(bg, -cam.x * PAR, y, w, h);
  } else { ctx.fillStyle = '#c98a45'; ctx.fillRect(0, 0, vw, vh); }
  if (farCanvas) {
    const fw = farCanvas.width, fy = vh - farCanvas.height + 60 - (cam.y - (ROWS * TILE - vh)) * 0.3, off = -(cam.x * 0.35) % fw;
    ctx.globalAlpha = 0.7; for (let x = off; x < vw; x += fw) ctx.drawImage(farCanvas, x, fy); ctx.globalAlpha = 1;
  }
  // طبقة وسطى مرسومة (عمق)
  const mid = IMG['fg' + level.id];
  if (mid) {
    const mh = vh * 1.28, mw = mh * mid.width / mid.height, PX = 0.42;
    const my = vh - mh + 40 - Math.min(0, (cam.y - Math.max(0, ROWS * TILE - vh)) * 0.15);
    let ox = -(cam.x * PX) % mw; if (ox > 0) ox -= mw;
    ctx.globalAlpha = level.dark ? 0.8 : 0.92;
    for (let x = ox; x < vw; x += mw - 1) ctx.drawImage(mid, x, my, mw, mh);
    ctx.globalAlpha = 1;
  }
  // أشعّة ضوء متحرّكة
  if (!level.dark && opts.q >= 0.8) {
    const t = performance.now() / 1000, col = { 1: '255,226,160', 2: '255,170,120', 4: '170,200,255' }[level.id] || '255,230,180';
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 4; i++) {
      const bx = ((i * 330 + 120 - cam.x * 0.15) % (vw + 400) + vw + 400) % (vw + 400) - 200;
      const a = 0.05 + 0.035 * Math.sin(t * 0.6 + i * 1.7);
      const gr = ctx.createLinearGradient(bx, 0, bx - 220, vh);
      gr.addColorStop(0, `rgba(${col},${a})`); gr.addColorStop(1, `rgba(${col},0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(bx, -10); ctx.lineTo(bx + 60 + i * 14, -10); ctx.lineTo(bx - 180 + i * 10, vh); ctx.lineTo(bx - 300, vh); ctx.fill();
    }
    ctx.restore();
  }
  const fog = ctx.createLinearGradient(0, vh * 0.4, 0, vh);
  const fc = { 1: '255,200,130', 2: '120,40,70', 3: '10,30,50', 4: '20,40,80' }[level.id];
  fog.addColorStop(0, `rgba(${fc},0)`); fog.addColorStop(1, `rgba(${fc},0.35)`);
  ctx.fillStyle = fog; ctx.fillRect(0, 0, vw, vh);
  if (level.dark) { ctx.fillStyle = 'rgba(4,10,18,0.35)'; ctx.fillRect(0, 0, vw, vh); }
}
function drawDrop(x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  const g = ctx.createRadialGradient(0, 4, 2, 0, 4, 26); g.addColorStop(0, 'rgba(120,220,255,0.5)'); g.addColorStop(1, 'rgba(120,220,255,0)'); ctx.fillStyle = g; ctx.fillRect(-26, -22, 52, 52);
  const gr = ctx.createLinearGradient(-8, -12, 8, 14); gr.addColorStop(0, '#bff0ff'); gr.addColorStop(1, '#2a8fc0');
  ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(0, -14); ctx.bezierCurveTo(4, -6, 11, 0, 11, 6); ctx.arc(0, 6, 11, 0, Math.PI); ctx.bezierCurveTo(-11, 0, -4, -6, 0, -14); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.ellipse(-4, 4, 2.5, 4, -0.4, 0, 7); ctx.fill();
  ctx.restore();
}
function drawSprite(img, x, y, w, h, flip, alpha = 1, rot = 0) {
  if (!img) { ctx.fillStyle = '#a44'; ctx.fillRect(x, y, w, h); return; }
  ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x + w / 2, y + h / 2); if (rot) ctx.rotate(rot); if (flip) ctx.scale(-1, 1);
  ctx.drawImage(img, -w / 2, -h / 2, w, h); ctx.restore();
}
function spriteFit(img, targetH) { return img ? [targetH * img.width / img.height, targetH] : [targetH, targetH]; }
function drawEnemy(e) {
  const t = performance.now() / 1000;
  if (!e.alive) { if (e.deadT > 0.5) return; ctx.globalAlpha = 1 - e.deadT * 2; }
  ctx.save();
  const U3 = window.M3D && M3D.ok && opts.hq !== false, S3 = scale * dpr;
  if (e.flash > 0 && !U3) ctx.filter = 'brightness(2.6) saturate(0)';
  const cx = e.x + e.w / 2, by = e.y + e.h;
  switch (e.type) {
    case 'scorpion': case 'minion': {
      const [w, h] = spriteFit(IMG.scorpion, e.type === 'minion' ? 44 : 66);
      const bob = Math.abs(Math.sin(e.t * 12)) * 3;
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(cx, by, w * 0.36, 5, 0, 0, 7); ctx.fill();
      if (U3) { M3D.drawEnemy(ctx, e, S3); break; }
      if (e.type === 'minion') ctx.filter = (e.flash > 0 ? 'brightness(2.6) saturate(0) ' : '') + 'hue-rotate(250deg) saturate(1.4)';
      drawSprite(IMG.scorpion, cx - w / 2, by - h + 4 - bob, w, h, e.dir > 0, ctx.globalAlpha, Math.sin(e.t * 10) * 0.03); break; }
    case 'bat': {
      if (e.st === 'dive_w') { ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = `rgba(255,210,122,${0.35 + Math.sin(e.t * 24) * 0.2})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(cx, e.y + e.h / 2, 34, 14, 0, 0, 7); ctx.stroke(); ctx.globalCompositeOperation = 'source-over'; }
      if (U3) { M3D.drawEnemy(ctx, e, S3); break; }
      const flap = 0.65 + Math.abs(Math.sin(e.t * 12)) * 0.45, [w, h] = spriteFit(IMG.bat, 52);
      ctx.translate(cx, e.y + e.h / 2); ctx.scale(e.dir > 0 ? -1 : 1, flap); if (IMG.bat) ctx.drawImage(IMG.bat, -w / 2, -h / 2, w, h); break; }
    case 'spirit': {
      ctx.globalCompositeOperation = 'lighter';
      const g = ctx.createRadialGradient(cx, e.y + 20, 2, cx, e.y + 20, 50); g.addColorStop(0, 'rgba(255,170,60,0.35)'); g.addColorStop(1, 'rgba(255,170,60,0)'); ctx.fillStyle = g; ctx.fillRect(e.x - 30, e.y - 30, 110, 110);
      ctx.globalCompositeOperation = 'source-over';
      if (U3) { M3D.drawEnemy(ctx, e, S3); break; }
      const [w, h] = spriteFit(IMG.spirit, 78); drawSprite(IMG.spirit, cx - w / 2, e.y - 14, w, h, e.dir > 0, (0.75 + Math.sin(e.t * 8) * 0.15) * ctx.globalAlpha, Math.sin(e.t * 2) * 0.08); break; }
    case 'ghoul': {
      const [w, h] = spriteFit(IMG.ghoul, 104);
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(cx, by, 40, 6, 0, 0, 7); ctx.fill();
      let ox = 0, rot = 0;
      if (e.st === 'wind') { ox = rand(-3, 3); rot = -0.1 * e.dir; }
      if (e.st === 'charge') rot = 0.12 * e.dir;
      if (e.st === 'stun') rot = Math.sin(e.t * 20) * 0.05;
      const bob = e.st === 'idle' ? Math.abs(Math.sin(e.t * 6)) * 3 : 0;
      if (U3) M3D.drawEnemy(ctx, e, S3); else drawSprite(IMG.ghoul, cx - w / 2 + ox, by - h + 6 - bob, w, h, e.dir > 0, ctx.globalAlpha, rot);
      if (e.st === 'wind') { ctx.fillStyle = `rgba(255,60,40,${0.5 + Math.sin(e.t * 40) * 0.4})`; ctx.beginPath(); ctx.arc(cx + e.dir * 18, e.y + 18, 5, 0, 7); ctx.fill(); }
      if (e.st === 'stun') { ctx.fillStyle = '#ffe27a'; for (let i = 0; i < 3; i++) { const a = e.t * 6 + i * 2.1; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * 20, e.y - 8 + Math.sin(a) * 5, 3, 0, 7); ctx.fill(); } }
      break; }
    case 'wisp': {
      ctx.globalCompositeOperation = 'lighter';
      const r = e.charging ? 60 + Math.sin(e.t * 30) * 8 : 44;
      const g = ctx.createRadialGradient(cx, e.y + 22, 2, cx, e.y + 22, r); g.addColorStop(0, 'rgba(255,120,60,0.5)'); g.addColorStop(1, 'rgba(255,60,120,0)'); ctx.fillStyle = g; ctx.fillRect(cx - r, e.y + 22 - r, r * 2, r * 2);
      ctx.globalCompositeOperation = 'source-over';
      if (U3) { M3D.drawEnemy(ctx, e, S3); break; }
      const [w, h] = spriteFit(IMG.wisp, 60); drawSprite(IMG.wisp, cx - w / 2, e.y - 8 + Math.sin(e.t * 5) * 3, w, h, e.dir > 0, ctx.globalAlpha, Math.sin(e.t * 3) * 0.1); break; }
    case 'spider': {
      if (e.st === 'hang') { ctx.strokeStyle = 'rgba(220,230,240,0.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx, e.hy - TILE); ctx.lineTo(cx, e.y + 6); ctx.stroke(); }
      if (U3) { M3D.drawEnemy(ctx, e, S3); break; }
      const [w, h] = spriteFit(IMG.spider, 50);
      const bob = e.st === 'walk' ? Math.abs(Math.sin(e.t * 16)) * 2 : 0;
      if (e.st === 'hang') { ctx.translate(cx, e.y + e.h / 2); ctx.rotate(Math.PI); if (IMG.spider) ctx.drawImage(IMG.spider, -w / 2, -h / 2, w, h); }
      else drawSprite(IMG.spider, cx - w / 2, by - h + 6 - bob, w, h, e.dir > 0, ctx.globalAlpha);
      break; }
    case 'soldier': {
      const [w, h] = spriteFit(IMG.soldier, 100);
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(cx, by, 28, 5, 0, 0, 7); ctx.fill();
      let rot = 0; if (e.st === 'wind') rot = -0.16 * e.dir; if (e.st === 'slash') rot = 0.2 * e.dir;
      const bob = Math.abs(e.vx) > 1 ? Math.abs(Math.sin(e.t * 9)) * 3 : 0;
      if (U3) M3D.drawEnemy(ctx, e, S3); else drawSprite(IMG.soldier, cx - w / 2, by - h + 6 - bob, w, h, e.dir > 0, ctx.globalAlpha, rot);
      if (e.st === 'wind') { ctx.fillStyle = `rgba(255,230,160,${0.5 + Math.sin(e.t * 40) * 0.4})`; ctx.beginPath(); ctx.arc(cx - e.dir * 10, e.y + 6, 5, 0, 7); ctx.fill(); }
      if (e.st === 'slash' && e.box) {
        ctx.globalAlpha = 0.7; ctx.fillStyle = '#fff3d0'; const ox = cx + e.dir * 30, oy = e.y + 40;
        const an = e.dir > 0 ? 0 : Math.PI;
        ctx.beginPath(); ctx.arc(ox, oy, 64, an - 1.2, an + 1.2); ctx.arc(ox - e.dir * 14, oy, 52, an + 1.2, an - 1.2, true); ctx.fill();
      }
      break; }
  }
  ctx.restore(); ctx.globalAlpha = 1;
  if (e.alive && e.hp < e.maxHp && e.maxHp > 2) {
    const w = 40, x = cx - w / 2, y = e.y - 12;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(x, y, w, 4); ctx.fillStyle = '#e8b75a'; ctx.fillRect(x, y, w * e.hp / e.maxHp, 4);
  }
}

function heartPath(c, x, y, s) { c.beginPath(); c.moveTo(x, y + s * 0.3); c.bezierCurveTo(x, y, x - s * 0.5, y, x - s * 0.5, y + s * 0.3); c.bezierCurveTo(x - s * 0.5, y + s * 0.6, x, y + s * 0.8, x, y + s); c.bezierCurveTo(x, y + s * 0.8, x + s * 0.5, y + s * 0.6, x + s * 0.5, y + s * 0.3); c.bezierCurveTo(x + s * 0.5, y, x, y, x, y + s * 0.3); c.fill(); }
function glow(x, y, r, col) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x, y, 1, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore();
}
function drawEnts() {
  const t = performance.now() / 1000;
  for (const e of ents) {
    if (e.x + 260 < cam.x || e.x - 260 > cam.x + view.w) continue;
    if (e.enemy) { drawEnemy(e); continue; }
    if (XD[e.type]) { XD[e.type](e, t); continue; }
    switch (e.type) {
      case 'drop': if (!e.got) drawDrop(e.x + 12, e.y + 12 + Math.sin(t * 3 + e.ph) * 4); break;
      case 'heart': if (!e.got) { ctx.fillStyle = '#e8453c'; heartPath(ctx, e.x + 16, e.y + Math.sin(t * 3) * 4, 26); } break;
      case 'coin': {
        const s = Math.abs(Math.cos(e.t * 6)), r = e.val > 1 ? 8 : 6;
        glow(e.x + 6, e.y + 6, 18, 'rgba(255,200,90,0.35)');
        ctx.fillStyle = e.val > 1 ? '#ffd46a' : '#e8b75a'; ctx.beginPath(); ctx.ellipse(e.x + 6, e.y + 6, Math.max(1.5, r * s), r, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#9a6a1c'; ctx.lineWidth = 1.5; ctx.stroke(); break; }
      case 'bag': {
        glow(e.x + 17, e.y + 17, 60, `rgba(255,210,122,${0.35 + Math.sin(t * 3) * 0.1})`);
        const y = e.y + Math.sin(t * 2) * 3;
        ctx.fillStyle = '#6b4424'; ctx.beginPath(); ctx.moveTo(e.x + 6, y + 34); ctx.quadraticCurveTo(e.x - 2, y + 12, e.x + 12, y + 10); ctx.lineTo(e.x + 22, y + 10); ctx.quadraticCurveTo(e.x + 36, y + 12, e.x + 28, y + 34); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#c7372f'; ctx.fillRect(e.x + 10, y + 8, 14, 4);
        ctx.fillStyle = '#ffd46a'; ctx.beginPath(); ctx.arc(e.x + 17, y + 22, 5, 0, 7); ctx.fill(); break; }
      case 'jar': if (!e.broken) {
        const x = e.x, y = e.y;
        ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(x + 16, y + 40, 16, 4, 0, 0, 7); ctx.fill();
        const g = ctx.createLinearGradient(x, 0, x + 32, 0); g.addColorStop(0, '#8a4f2a'); g.addColorStop(0.4, '#c98450'); g.addColorStop(1, '#6e3a1c');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x + 10, y + 4); ctx.lineTo(x + 22, y + 4); ctx.quadraticCurveTo(x + 36, y + 16, x + 28, y + 38); ctx.lineTo(x + 4, y + 38); ctx.quadraticCurveTo(x - 4, y + 16, x + 10, y + 4); ctx.fill();
        ctx.fillStyle = '#5a2e14'; ctx.fillRect(x + 8, y, 16, 6);
        ctx.strokeStyle = '#e8b75a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + 4, y + 20); ctx.lineTo(x + 28, y + 20); ctx.stroke();
      } break;
      case 'crystal': {
        const k = 0.7 + Math.sin(t * 2 + e.t) * 0.3;
        glow(e.x, e.y, 90, `rgba(90,220,210,${0.35 * k})`);
        ctx.fillStyle = '#7ff0e0'; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(e.x + i * 10, e.y + 22); ctx.lineTo(e.x + i * 10 - 6, e.y + 4); ctx.lineTo(e.x + i * 10, e.y - 18 + Math.abs(i) * 10); ctx.lineTo(e.x + i * 10 + 6, e.y + 4); ctx.fill(); }
        break; }
      case 'mplat': drawPlatform(e.x, e.y, e.w, e.h); break;
      case 'crumble': {
        if (e.st === 'gone') { ctx.globalAlpha = Math.min(0.25, e.t / 6); drawCrumble(e.x, e.oy, e.w, e.h); ctx.globalAlpha = 1; break; }
        const sx = e.st === 'shake' ? rand(-2, 2) : 0;
        ctx.globalAlpha = e.st === 'fall' ? Math.max(0, 1 - e.t) : 1;
        drawCrumble(e.x + sx, e.y, e.w, e.h); ctx.globalAlpha = 1; break; }
      case 'spring': {
        const c = e.boing ? 1 - e.boing * 1.5 : 1;
        ctx.fillStyle = '#5b3a1e'; ctx.fillRect(e.x, e.y + 14, e.w, 8);
        ctx.strokeStyle = '#c9a15a'; ctx.lineWidth = 3; ctx.beginPath();
        for (let i = 0; i <= 4; i++) ctx.lineTo(e.x + (i % 2 ? 8 : 32), e.y + 14 - i * 3 * c - 2);
        ctx.stroke();
        ctx.fillStyle = '#2f7f7a'; ctx.beginPath(); ctx.ellipse(e.x + 20, e.y + 14 - 14 * c, 22, 6, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#e8b75a'; ctx.fillRect(e.x + 4, e.y + 10 - 14 * c, 32, 3);
        break; }
      case 'rest': drawRest(e, t); break;
      case 'gate': drawGate(e, t); break;
      case 'tablet': {
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(e.x + 18, e.y + 40, 22, 5, 0, 0, 7); ctx.fill();
        ctx.fillStyle = level.pal.stone2; ctx.beginPath(); ctx.moveTo(e.x, e.y + 40); ctx.lineTo(e.x + 2, e.y + 6); ctx.quadraticCurveTo(e.x + 18, e.y - 6, e.x + 34, e.y + 6); ctx.lineTo(e.x + 36, e.y + 40); ctx.fill();
        ctx.fillStyle = level.pal.stone; ctx.beginPath(); ctx.moveTo(e.x + 5, e.y + 36); ctx.lineTo(e.x + 6, e.y + 9); ctx.quadraticCurveTo(e.x + 18, e.y, e.x + 30, e.y + 9); ctx.lineTo(e.x + 31, e.y + 36); ctx.fill();
        ctx.strokeStyle = e.near ? '#ffd27a' : 'rgba(60,30,10,0.55)'; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(e.x + 10, e.y + 16 + i * 7); ctx.lineTo(e.x + 26, e.y + 16 + i * 7); ctx.stroke(); }
        if (!e.seen || e.near) { const a = 0.5 + Math.sin(t * 4) * 0.3; ctx.fillStyle = `rgba(255,210,122,${a})`; ctx.beginPath(); ctx.arc(e.x + 18, e.y - 14 + Math.sin(t * 3) * 3, 5, 0, 7); ctx.fill(); }
        break; }
      case 'npc': {
        const n = NPCS[e.id], img = IMG[n.img], ghost = n.img === 'grandpa';
        const [w, h] = spriteFit(img, ghost ? 110 : 96);
        const fy = ghost ? Math.sin(t * 2) * 5 - 8 : 0;
        if (ghost) glow(e.x + e.w / 2, e.y + 40 + fy, 110, 'rgba(120,200,255,0.35)');
        else { ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(e.x + e.w / 2, e.y + e.h, 30, 5, 0, 0, 7); ctx.fill(); }
        drawSprite(img, e.x + e.w / 2 - w / 2, e.y + e.h - h + 4 + fy, w, h, player.x > e.x + e.w / 2, ghost ? 0.8 + Math.sin(t * 3) * 0.1 : 1);
        if (e.near && !state.dialog) {
          const y = e.y - 30 + Math.sin(t * 4) * 3; ctx.fillStyle = 'rgba(20,12,6,0.8)'; ctx.beginPath(); ctx.roundRect(e.x + e.w / 2 - 16, y - 16, 32, 26, 8); ctx.fill();
          ctx.fillStyle = '#ffd27a'; ctx.beginPath(); ctx.moveTo(e.x + e.w / 2, y - 10); ctx.lineTo(e.x + e.w / 2 + 8, y + 2); ctx.lineTo(e.x + e.w / 2 - 8, y + 2); ctx.fill();
        } else if (!save.met[e.id]) { ctx.fillStyle = `rgba(255,210,122,${0.6 + Math.sin(t * 5) * 0.3})`; ctx.font = '700 22px "Reem Kufi", sans-serif'; ctx.textAlign = 'center'; ctx.fillText('…', e.x + e.w / 2, e.y - 14 + fy); }
        break; }
      case 'letter': {
        const y = e.y + Math.sin(t * 2.5 + e.t) * 5;
        glow(e.x + 16, y + 14, 60, `rgba(255,220,150,${0.4 + Math.sin(t * 4) * 0.12})`);
        ctx.save(); ctx.translate(e.x + 16, y + 14); ctx.rotate(Math.sin(t * 1.5) * 0.12);
        ctx.fillStyle = '#efdcb0'; ctx.fillRect(-12, -10, 24, 20);
        ctx.fillStyle = '#c9a66a'; ctx.beginPath(); ctx.arc(-12, 0, 4, 0, 7); ctx.arc(12, 0, 4, 0, 7); ctx.fill();
        ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 1; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.moveTo(-7, -5 + i * 5); ctx.lineTo(7, -5 + i * 5); ctx.stroke(); }
        ctx.fillStyle = '#c7372f'; ctx.beginPath(); ctx.arc(0, 8, 3.5, 0, 7); ctx.fill();
        ctx.restore(); break; }
      case 'gem': {
        const s = 1 + Math.sin(t * 4) * 0.05;
        glow(e.x + 24, e.y + 30, 120, 'rgba(90,200,255,0.6)');
        drawSprite(IMG.gem, e.x + 4 - 20 * (s - 1), e.y - 10 - 40 * (s - 1), 40 * s, 80 * s, false);
        if (Math.random() < 0.3) emit(e.x + 24, e.y + 30, 1, { color: '#9fe6ff', glow: true, g: -40, min: 20, max: 60 });
        break; }
    }
  }
}
function drawPlatform(x, y, w, h) {
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x + 4, y + h, w - 8, 5);
  ctx.fillStyle = level.pal.stone2; ctx.fillRect(x, y, w, h);
  ctx.fillStyle = level.pal.stone; ctx.fillRect(x + 2, y + 2, w - 4, h - 7);
  ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(x + 2, y + 2, w - 4, 3);
  ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1.5;
  for (let i = 1; i < 3; i++) { ctx.beginPath(); ctx.moveTo(x + i * w / 3, y + 3); ctx.lineTo(x + i * w / 3, y + h - 3); ctx.stroke(); }
  ctx.fillStyle = '#e8b75a'; for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(x + w / 6 + i * w / 3, y + h / 2, 3, 0, 7); ctx.fill(); }
}
function drawCrumble(x, y, w, h) {
  ctx.fillStyle = level.pal.body2; ctx.fillRect(x, y, w, h);
  ctx.fillStyle = level.pal.top; ctx.fillRect(x, y, w, 7);
  ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 1.5; ctx.beginPath();
  ctx.moveTo(x + 20, y + 7); ctx.lineTo(x + 30, y + 16); ctx.lineTo(x + 26, y + h); ctx.moveTo(x + 60, y + 7); ctx.lineTo(x + 54, y + 18); ctx.lineTo(x + 66, y + h); ctx.stroke();
}
// خيمة الاستراحة (مقعد الحفظ)
function drawRest(e, t) {
  const x = e.x, base = e.y + e.h, cx = x + 40;
  if (e.on) glow(cx + 26, base - 14, 130, `rgba(255,170,70,${0.45 + Math.sin(t * 9) * 0.06})`);
  ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(cx, base, 50, 6, 0, 0, 7); ctx.fill();
  // الخيمة
  ctx.fillStyle = '#7a3a26'; ctx.beginPath(); ctx.moveTo(x, base); ctx.lineTo(cx, base - 64); ctx.lineTo(x + 80, base); ctx.fill();
  ctx.fillStyle = '#b5553a'; ctx.beginPath(); ctx.moveTo(x + 8, base); ctx.lineTo(cx, base - 60); ctx.lineTo(cx, base); ctx.fill();
  ctx.fillStyle = '#e8b75a'; for (let i = 0; i < 4; i++) ctx.fillRect(x + 10 + i * 16, base - 14 - (i % 2) * 2, 8, 3);
  ctx.fillStyle = '#2a140c'; ctx.beginPath(); ctx.moveTo(cx - 12, base); ctx.lineTo(cx, base - 34); ctx.lineTo(cx + 12, base); ctx.fill();
  ctx.fillStyle = '#4a3220'; ctx.fillRect(cx - 2, base - 76, 4, 16);
  // النار
  const fx = cx + 30;
  ctx.fillStyle = '#4a2c18'; ctx.fillRect(fx - 10, base - 5, 20, 5);
  if (e.on) {
    for (let i = 0; i < 3; i++) { const h = 18 + Math.sin(t * 12 + i * 2) * 5; ctx.fillStyle = ['#ff7a2a', '#ffb347', '#fff0a0'][i]; ctx.beginPath(); ctx.moveTo(fx - 8 + i * 3, base - 4); ctx.quadraticCurveTo(fx, base - 4 - h * (1 - i * 0.25) * 1.4, fx + 8 - i * 3, base - 4); ctx.fill(); }
    if (Math.random() < 0.15) parts.push({ x: fx + rand(-4, 4), y: base - 14, vx: rand(-10, 10), vy: rand(-80, -40), life: 0.9, t: 0, size: 1.6, color: '#ffb347', g: -20, drag: 0.98, glow: true });
  } else { ctx.fillStyle = '#6a4a38'; ctx.beginPath(); ctx.arc(fx, base - 6, 5, 0, 7); ctx.fill(); }
}
function drawGate(e, t) {
  const x = e.x, y = e.y, w = e.w, h = e.h;
  glow(x + w / 2, y + h * 0.55, 130, `rgba(120,220,255,${0.5 + Math.sin(t * 2) * 0.12})`);
  ctx.fillStyle = level.pal.stone2; ctx.fillRect(x, y + 40, 22, h - 40); ctx.fillRect(x + w - 22, y + 40, 22, h - 40);
  ctx.beginPath(); ctx.moveTo(x, y + 50); ctx.arc(x + w / 2, y + 50, w / 2, Math.PI, 0); ctx.lineTo(x + w - 22, y + 50); ctx.arc(x + w / 2, y + 50, w / 2 - 22, 0, Math.PI, true); ctx.fill();
  ctx.fillStyle = level.pal.stone; ctx.fillRect(x + 4, y + 44, 12, h - 44); ctx.fillRect(x + w - 18, y + 44, 12, h - 44);
  const pg = ctx.createLinearGradient(0, y + 40, 0, y + h); pg.addColorStop(0, 'rgba(160,235,255,0.75)'); pg.addColorStop(1, 'rgba(60,150,200,0.35)');
  ctx.fillStyle = pg; ctx.beginPath(); ctx.moveTo(x + 22, y + h); ctx.lineTo(x + 22, y + 50); ctx.arc(x + w / 2, y + 50, w / 2 - 22, Math.PI, 0); ctx.lineTo(x + w - 22, y + h); ctx.fill();
  for (let i = 0; i < 3; i++) { const yy = y + h - ((t * 40 + i * 35) % (h - 50)); ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.fillRect(x + 30 + i * 18, yy, 2, 8); }
  ctx.fillStyle = '#e8b75a'; ctx.beginPath(); ctx.arc(x + w / 2, y + 10, 6, 0, 7); ctx.fill();
}

// وشاح عبسي: شريطٌ مستدقّ بلونين وحافةٍ مطرّزة
function drawScarfRibbon(sc) {
  const n = sc.length, L = [], R = [];
  for (let i = 0; i < n; i++) {
    const a = sc[Math.max(0, i - 1)], b = sc[Math.min(n - 1, i + 1)];
    let dx = b.x - a.x, dy = b.y - a.y; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
    const w = 5.2 * (1 - i / n * 0.55) + (i === n - 1 ? 1.5 : 0);
    L.push([sc[i].x - dy * w, sc[i].y + dx * w]); R.push([sc[i].x + dy * w, sc[i].y - dx * w]);
  }
  ctx.beginPath(); ctx.moveTo(L[0][0], L[0][1]);
  for (let i = 1; i < n; i++) ctx.lineTo(L[i][0], L[i][1]);
  for (let i = n - 1; i >= 0; i--) ctx.lineTo(R[i][0], R[i][1]);
  ctx.closePath();
  ctx.fillStyle = '#b52c25'; ctx.fill(); ctx.lineJoin = 'round'; ctx.lineWidth = 1.6; ctx.strokeStyle = '#4a0f0b'; ctx.stroke();
  ctx.beginPath(); ctx.moveTo(sc[0].x, sc[0].y); for (let i = 1; i < n; i++) ctx.lineTo((sc[i].x + L[i][0]) / 2, (sc[i].y + L[i][1]) / 2);
  ctx.strokeStyle = 'rgba(255,140,120,0.7)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round'; ctx.stroke();
  // أهداب ذهبية عند الطرف
  const e = sc[n - 1], f = sc[n - 2];
  let dx = e.x - f.x, dy = e.y - f.y; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
  ctx.strokeStyle = '#e8b75a'; ctx.lineWidth = 1.4;
  for (let k = -2; k <= 2; k++) { const ox = e.x - dy * k * 2.2, oy = e.y + dx * k * 2.2; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ox + dx * 6, oy + dy * 6); ctx.stroke(); }
}
function drawPlayer() {
  const p = player, t = performance.now() / 1000;
  if (p.dead && p.deadT > 0.9) return;
  const blink = p.inv > 0 && !p.dead && Math.floor(t * 20) % 2 === 0;
  if (p.healT > 0) glow(p.x + p.w / 2, p.y + p.h / 2, 60 + p.healT * 60, `rgba(220,245,255,${0.25 + p.healT * 0.4})`);
  if (!blink) {
    drawScarfRibbon(p.scarf);
    const cx = p.x + p.w / 2, by = p.y + p.h;
    if (window.Zayd3D && Zayd3D.ok && opts.hq !== false) {
      if (p.ground && !p.dead) { ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.beginPath(); ctx.ellipse(cx, by, 18, 4.5, 0, 0, 7); ctx.fill(); }
      const sl = p.trail && p.trail.length && R3D.peek(p);
      if (sl) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (const tr of p.trail) R3D.blit(ctx, sl, tr.x, tr.y, tr.a * 0.32); ctx.restore(); }
      Zayd3D.draw(ctx, p, cx, by + (p.healT > 0 ? 0 : 0), scale * dpr, p.dead ? Math.max(0, 1 - p.deadT * 1.1) : 1);
    } else {
    ctx.save(); ctx.translate(cx, by); ctx.scale(p.face * (2 - p.sq), p.sq);
    if (p.dead) { ctx.globalAlpha = Math.max(0, 1 - p.deadT); ctx.rotate(-p.deadT * 2); }
    const run = p.ground ? Math.sin(p.run) : 0, air = !p.ground, crouch = p.healT > 0 ? 4 : 0;
    ctx.translate(0, crouch);
    if (p.ground) { ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(0, -crouch, 16, 4, 0, 0, 7); ctx.fill(); }
    ctx.strokeStyle = '#7a4a2c'; ctx.lineWidth = 6; ctx.lineCap = 'round';
    const l1 = p.wall ? -0.3 : air ? -0.5 : run * 0.7, l2 = p.wall ? 0.5 : air ? 0.35 : -run * 0.7;
    for (const a of [l1, l2]) { ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(Math.sin(a) * 14, -22 + Math.cos(a) * 20); ctx.stroke(); }
    ctx.fillStyle = '#4a2c18'; for (const a of [l1, l2]) { ctx.beginPath(); ctx.ellipse(Math.sin(a) * 14 + 3, -2 + (Math.cos(a) - 1) * 20, 6, 3, 0, 0, 7); ctx.fill(); }
    const sway = air ? -4 : run * 3;
    const gr = ctx.createLinearGradient(0, -50, 0, -14); gr.addColorStop(0, '#f6ecd6'); gr.addColorStop(1, '#d9c7a2');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(-9, -48); ctx.lineTo(9, -48); ctx.lineTo(13 + sway * 0.4, -16); ctx.quadraticCurveTo(0, -12, -13 + sway, -16); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#6b4424'; ctx.fillRect(-10, -33, 21, 4);
    ctx.strokeStyle = '#5a3a1e'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(8, -48); ctx.lineTo(-8, -28); ctx.stroke();
    ctx.fillStyle = '#7d5230'; ctx.beginPath(); ctx.roundRect(-16, -32, 11, 11, 3); ctx.fill();
    // الذراع والجنبية
    let arm = air ? -1.9 : -run * 0.8;
    const atk = p.slashFx > 0;
    if (atk) arm = p.atkDir === 'u' ? Math.PI : p.atkDir === 'd' ? 0.1 : Math.PI / 2 + (p.slashAlt ? 0.5 : -0.5) * (p.slashFx / 0.14);
    const hx = 1 + Math.sin(arm) * 15, hy = -44 + Math.cos(arm) * 15;
    ctx.strokeStyle = '#8a5634'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(1, -44); ctx.lineTo(hx, hy); ctx.stroke();
    ctx.save(); ctx.translate(hx, hy); ctx.rotate(atk ? -arm + Math.PI / 2 + (p.atkDir === 's' ? 0 : 0) : 0.4);
    if (!atk) ctx.rotate(Math.PI * 0.6);
    ctx.fillStyle = '#6b3a1e'; ctx.fillRect(-2, -3, 8, 6);
    ctx.fillStyle = '#e8b75a'; ctx.fillRect(5, -4, 3, 8);
    ctx.fillStyle = '#e8eef2'; ctx.beginPath(); ctx.moveTo(8, -3); ctx.quadraticCurveTo(20, -5, 26, 4); ctx.quadraticCurveTo(18, 2, 8, 3); ctx.fill();
    ctx.restore();
    ctx.fillStyle = '#c7372f'; ctx.beginPath(); ctx.ellipse(0, -48, 11, 5, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#9a6038'; ctx.beginPath(); ctx.arc(1, -58, 10, 0, 7); ctx.fill();
    ctx.fillStyle = '#231510';
    ctx.beginPath(); ctx.arc(-2, -64, 8, Math.PI * 0.9, Math.PI * 2.1); ctx.fill();
    for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.arc(-8 + i * 3.5, -66 + (i % 2) * 2, 3.6, 0, 7); ctx.fill(); }
    ctx.beginPath(); ctx.arc(-8, -59, 3.5, 0, 7); ctx.fill();
    ctx.fillStyle = '#1a0f0a'; ctx.beginPath(); ctx.arc(6, -58, 1.6, 0, 7); ctx.fill();
    ctx.restore();
    }
  }
  if (p.dashT > 0) { ctx.save(); ctx.globalAlpha = 0.35; ctx.fillStyle = '#fff3d6'; ctx.beginPath(); ctx.ellipse(p.x + p.w / 2 - p.face * 20, p.y + p.h / 2, 34, 14, 0, 0, 7); ctx.fill(); ctx.restore(); }
  // هلال الضربة
  if (p.slashFx > 0) {
    const k = p.slashFx / 0.14, cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    let ang = p.face > 0 ? 0 : Math.PI; if (p.atkDir === 'u') ang = -Math.PI / 2; if (p.atkDir === 'd') ang = Math.PI / 2;
    const R = 66 + save.up.blade * 5, ox = cx + Math.cos(ang) * 14, oy = cy - 4 + Math.sin(ang) * 14;
    const sweep = 1.25, a0 = ang - sweep, a1 = ang + sweep;
    ctx.save(); ctx.globalAlpha = Math.min(1, k * 1.6);
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(ox, oy, R, a0, a1); ctx.arc(ox - Math.cos(ang) * 18, oy - Math.sin(ang) * 18, R * 0.86, a1, a0, true); ctx.closePath(); ctx.fill();
    ctx.globalAlpha *= 0.35; ctx.fillStyle = '#ffe7b0'; ctx.beginPath(); ctx.arc(ox, oy, R + 8, a0 + 0.2, a1 - 0.2); ctx.arc(ox, oy, R - 4, a1 - 0.2, a0 + 0.2, true); ctx.fill();
    ctx.restore();
  }
}

function drawHazards() {
  if (!arena) return;
  for (const h of hazards) {
    if (h.t < 0) continue;
    if (h.kind === 'sting') {
      const cx = h.x + h.w / 2;
      if (h.t < h.warn) {
        const a = 0.25 + Math.sin(h.t * 30) * 0.15;
        ctx.fillStyle = `rgba(255,90,60,${a})`; ctx.fillRect(h.x + 20, h.top, h.w - 40, arena.gy - h.top);
        ctx.fillStyle = `rgba(255,120,80,${a + 0.3})`; ctx.fillRect(h.x + 4, arena.gy - 5, h.w - 8, 5);
      } else if (h.t < h.warn + h.up + 0.2) {
        const k = Math.min(1, (h.t - h.warn) / 0.08), bot = lerp(h.top, arena.gy, k);
        ctx.fillStyle = '#3a1a14'; ctx.fillRect(cx - 7, h.top, 14, bot - h.top - 40);
        ctx.fillStyle = '#c7372f'; ctx.beginPath(); ctx.moveTo(cx - 20, bot - 50); ctx.lineTo(cx + 20, bot - 50); ctx.lineTo(cx, bot); ctx.fill();
        ctx.fillStyle = '#ffb08a'; ctx.beginPath(); ctx.moveTo(cx - 6, bot - 46); ctx.lineTo(cx, bot - 8); ctx.lineTo(cx + 2, bot - 46); ctx.fill();
      }
      continue;
    }
    if (h.t < h.warn) {
      const a = 0.3 + Math.sin(h.t * 30) * 0.2;
      ctx.fillStyle = `rgba(255,120,60,${a})`; ctx.fillRect(h.x, arena.gy - 6, h.w, 6);
      if (Math.random() < 0.5) emit(h.x + rand(0, h.w), arena.gy, 1, { color: '#e2bf7c', angle: -Math.PI / 2, spread: 0.3, min: 40, max: 110, lmax: 0.3 });
    } else if (h.t < h.warn + h.up) {
      const hh = Math.min(1, (h.t - h.warn) * 8) * 120;
      const gr = ctx.createLinearGradient(0, arena.gy - hh, 0, arena.gy); gr.addColorStop(0, '#f3d9a0'); gr.addColorStop(1, '#a8743a');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(h.x, arena.gy);
      for (let i = 0; i <= 4; i++) ctx.lineTo(h.x + i * h.w / 4, arena.gy - hh * (i % 2 ? 1 : 0.55));
      ctx.lineTo(h.x + h.w, arena.gy); ctx.fill();
    }
  }
}
function drawProjectiles() {
  for (const o of projectiles) {
    if (o.wave) {
      const gr = ctx.createLinearGradient(0, o.y, 0, o.y + o.h); gr.addColorStop(0, 'rgba(243,217,160,0.95)'); gr.addColorStop(1, '#a8743a');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(o.x - 10, o.y + o.h);
      ctx.quadraticCurveTo(o.x + o.w / 2 + (o.vx > 0 ? 14 : -14), o.y - 20, o.x + o.w + 10, o.y + o.h); ctx.fill();
      continue;
    }
    const c = o.fire ? ['#fff4c8', '#ff7a2a', 'rgba(255,60,120,0.2)'] : o.acid ? ['#efffd0', '#6fd05a', 'rgba(40,120,40,0.2)'] : o.rock ? ['#e8d0a0', '#8a6a44', 'rgba(60,40,20,0.3)'] : ['#fff0c8', '#e0a94f', 'rgba(160,100,40,0.2)'];
    if (o.fire || o.acid) glow(o.x, o.y, o.r * 3, o.fire ? 'rgba(255,120,60,0.4)' : 'rgba(120,230,100,0.3)');
    const gr = ctx.createRadialGradient(o.x - 4, o.y - 4, 2, o.x, o.y, o.r);
    gr.addColorStop(0, c[0]); gr.addColorStop(0.5, c[1]); gr.addColorStop(1, c[2]);
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, 7); ctx.fill();
  }
}

// جسيمات جوية
const ambient = [];
function ambientUpdate(dt) {
  const type = level.particle;
  while (ambient.length < (type === 'fireflies' ? 40 : 55)) ambient.push({ x: Math.random() * view.w, y: Math.random() * view.h, s: Math.random(), ph: Math.random() * 6 });
  for (const a of ambient) {
    if (type === 'dust') { a.x -= (60 + a.s * 140) * dt; a.y += Math.sin(a.ph += dt * 2) * 0.4; }
    else if (type === 'embers') { a.x -= (20 + a.s * 40) * dt; a.y -= (15 + a.s * 30) * dt; }
    else if (type === 'spores') { a.ph += dt; a.y -= (8 + a.s * 14) * dt; a.x += Math.sin(a.ph) * 10 * dt; }
    else { a.ph += dt; a.x += Math.sin(a.ph * 0.7) * 20 * dt; a.y += Math.cos(a.ph * 0.9) * 14 * dt; }
    if (a.x < -10) a.x = view.w + 10; if (a.x > view.w + 10) a.x = -10; if (a.y < -10) a.y = view.h + 10; if (a.y > view.h + 10) a.y = -10;
  }
}
function ambientDraw() {
  const type = level.particle, now = performance.now();
  ctx.save();
  if (type !== 'dust') ctx.globalCompositeOperation = 'lighter';
  for (const a of ambient) {
    if (type === 'dust') { ctx.fillStyle = `rgba(255,230,180,${0.15 + a.s * 0.25})`; ctx.fillRect(a.x, a.y, 2 + a.s * 10, 1.5); }
    else if (type === 'embers') { ctx.fillStyle = `rgba(255,${120 + a.s * 80},60,${0.3 + Math.sin(a.ph + now / 300) * 0.2})`; ctx.beginPath(); ctx.arc(a.x, a.y, 1 + a.s * 2, 0, 7); ctx.fill(); }
    else if (type === 'spores') { ctx.fillStyle = `rgba(140,240,210,${0.25 + Math.sin(a.ph * 2) * 0.15})`; ctx.beginPath(); ctx.arc(a.x, a.y, 1 + a.s * 2.2, 0, 7); ctx.fill(); }
    else { const k = 0.4 + Math.sin(a.ph * 3) * 0.4; ctx.fillStyle = `rgba(170,230,255,${k * 0.7})`; ctx.beginPath(); ctx.arc(a.x, a.y, 1.5 + a.s * 1.5, 0, 7); ctx.fill(); }
  }
  ctx.restore();
}
// إضاءة الكهف
function drawDarkness(sx, sy) {
  const w = darkCv.width, h = darkCv.height;
  dctx.globalCompositeOperation = 'source-over'; dctx.clearRect(0, 0, w, h);
  dctx.fillStyle = 'rgba(3,6,12,0.9)'; dctx.fillRect(0, 0, w, h);
  dctx.globalCompositeOperation = 'destination-out';
  const light = (x, y, r, k = 1) => {
    const X = x - cam.x + sx, Y = y - cam.y + sy; if (X < -r || X > w + r || Y < -r || Y > h + r) return;
    const g = dctx.createRadialGradient(X, Y, r * 0.15, X, Y, r); g.addColorStop(0, `rgba(0,0,0,${k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
    dctx.fillStyle = g; dctx.fillRect(X - r, Y - r, r * 2, r * 2);
  };
  const p = player, tt = performance.now() / 1000;
  light(p.x + p.w / 2, p.y + p.h / 2, 230 + Math.sin(tt * 3) * 6, 1);
  for (const e of ents) {
    if (e.type === 'crystal') light(e.x, e.y, 170, 0.85);
    else if (e.type === 'rest') light(e.x + 60, e.y + 50, e.on ? 260 : 120, e.on ? 1 : 0.6);
    else if (e.type === 'wisp' && e.alive) light(e.x + e.w / 2, e.y + e.h / 2, 150, 0.8);
    else if (e.type === 'spirit' && e.alive) light(e.x + e.w / 2, e.y + e.h / 2, 110, 0.6);
    else if (e.type === 'letter' || e.type === 'bag') light(e.x + 16, e.y + 16, 90, 0.7);
    else if (e.type === 'npc') light(e.x + 30, e.y + 40, 170, 0.9);
    else if (e.type === 'gate') light(e.x + 56, e.y + 90, 200, 0.9);
    else if (e.type === 'drop' && !e.got) light(e.x + 12, e.y + 12, 50, 0.5);
    else if (e.type === 'coin') light(e.x + 6, e.y + 6, 30, 0.5);
  }
  for (const o of projectiles) if (!o.wave) light(o.x, o.y, 90, 0.8);
  if (boss && !boss.dead && arena) light((arena.x0 + arena.x1) / 2, arena.gy - 200, 520, 0.7);
  ctx.drawImage(darkCv, 0, 0, w, h);
}

function prepass3D() {
  if (!(window.R3D && R3D.ok)) return;
  R3D.begin();
  const S3 = scale * dpr;
  if (window.M3D && M3D.ok && opts.hq !== false) {
    for (const e of ents) if (e.enemy && (e.alive || e.deadT <= 0.5) && e.x + 260 >= cam.x && e.x - 260 <= cam.x + view.w) M3D.drawEnemy(null, e, S3);
    if (boss && !boss.gone && arena) {
      const A = arena;
      if (arena.boss === 'queen') M3D.drawQueen(null, boss, A.gy, S3);
      else if (arena.boss === 'serpent') { if (boss.st === 'lunge' || boss.top < A.gy + 10) M3D.drawSerpent(null, boss, A.gy, player, S3); }
      else if (arena.boss === 'sultan') M3D.drawSultan(null, boss, S3);
    }
  }
  const p = player;
  if (p && window.Zayd3D && Zayd3D.ok && !(p.dead && p.deadT > 0.9)) Zayd3D.draw(null, p, p.x + p.w / 2, p.y + p.h, S3, 1);
  R3D.key = null;
}
function render() {
  if (level && running) prepass3D();
  ctx.setTransform(scale * dpr, 0, 0, scale * dpr, 0, 0);
  ctx.clearRect(0, 0, view.w, view.h);
  if (!level) return;
  drawBg();
  const sx = cam.shake ? rand(-cam.shake, cam.shake) : 0, sy = cam.shake ? rand(-cam.shake, cam.shake) : 0;
  ctx.save();
  ctx.translate(Math.round(-cam.x + sx), Math.round(-cam.y + sy));
  if (boss) boss.draw();
  ctx.fillStyle = level.pal.dark; ctx.fillRect(cam.x - 50, ROWS * TILE - 1, view.w + 100, 600);
  if (tileCanvas) {
    const x0 = Math.max(0, Math.floor(cam.x) - 20), w = Math.min(tileCanvas.width - x0, view.w + 40);
    const y0 = Math.max(0, Math.floor(cam.y) - 20), h = Math.min(tileCanvas.height - y0, view.h + 40);
    if (w > 0 && h > 0) ctx.drawImage(tileCanvas, x0, y0, w, h, x0, y0, w, h);
  }
  drawGrass(frameDt);
  drawHazards();
  drawEnts();
  drawPlayer();
  drawProjectiles();
  drawPShots(); drawSparks();
  drawParts();
  ctx.textAlign = 'center'; ctx.direction = 'rtl';
  for (const f of floaters) {
    ctx.globalAlpha = Math.max(0, 1 - f.a / f.life); ctx.fillStyle = f.c; ctx.font = '700 16px "IBM Plex Sans Arabic", sans-serif';
    ctx.fillText(f.t, f.x, f.y - f.a * 40); ctx.globalAlpha = 1;
  }
  ctx.restore();
  drawNearFG();
  if (level.dark) drawDarkness(Math.round(sx), Math.round(sy));
  ambientDraw();
  ctx.fillStyle = level.grade; ctx.fillRect(0, 0, view.w, view.h);
  const vg = ctx.createRadialGradient(view.w / 2, view.h / 2, view.h * 0.4, view.w / 2, view.h / 2, view.w * 0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)');
  ctx.fillStyle = vg; ctx.fillRect(0, 0, view.w, view.h);
  if (player && player.hp === 1 && !player.dead) { ctx.fillStyle = `rgba(160,0,0,${0.08 + Math.sin(performance.now() / 250) * 0.05})`; ctx.fillRect(0, 0, view.w, view.h); }
}

// ===== HUD =====
const MASK_SVG = '<path d="M12 2.5c4.6 0 8 2.4 8 6.6 0 5.2-3.4 10.6-8 12.4-4.6-1.8-8-7.2-8-12.4 0-4.2 3.4-6.6 8-6.6z"/><path class="eye" d="M8.6 10.2c.9-.9 2.3-.9 2.6.6-.8.9-2.1 1-2.6-.6zM15.4 10.2c-.9-.9-2.3-.9-2.6.6.8.9 2.1 1 2.6-.6z"/>';
function renderHud(pop, brk = -1) {
  const p = player; if (!p) return;
  let html = '';
  for (let i = 0; i < p.maxHp; i++) html += `<svg viewBox="0 0 24 24" class="mask ${i >= p.hp ? 'lost' : ''} ${pop && i === p.hp - 1 ? 'pop' : ''} ${i === brk ? 'brk' : ''}">${MASK_SVG}</svg>`;
  $('#hearts').innerHTML = html;
  $('#dinars').textContent = save.dinars;
  $('#letterCount').textContent = save.letters.size;
}
function renderSoul() {
  const p = player; if (!p) return;
  const k = p.soul / 99;
  $('#soulFill').style.transform = `translateY(${(1 - k) * 100}%)`;
  $('#soulOrb').classList.toggle('ready', p.soul >= 33);
}
function fmtTime(s) { s = Math.floor(s); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
function showBanner(sub, title) {
  const b = $('#banner'); $('#bannerSub').textContent = sub; $('#bannerTitle').textContent = title;
  b.classList.remove('hidden'); b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  clearTimeout(bannerTimer); bannerTimer = setTimeout(() => b.classList.add('hidden'), 3300);
}
let titleTimer = null;
function bossTitle(name, sub) {
  const b = $('#bossTitle'); $('#btSub').textContent = sub; $('#btName').textContent = name;
  b.classList.remove('hidden'); b.classList.remove('run'); void b.offsetWidth; b.classList.add('run');
  clearTimeout(titleTimer); titleTimer = setTimeout(() => b.classList.add('hidden'), 3800);
}
function subtitle(sp, txt) {
  const s = $('#subtitle');
  if (!sp || !opts.subs) { s.classList.add('hidden'); return; }
  $('#subSpeaker').textContent = sp; $('#subText').textContent = txt; s.classList.remove('hidden');
}

// ===== تدفق اللعبة =====
let last = 0, acc = 0, running = false;
function startLevel(i) {
  if (i >= 1) save.abil.dash = true; if (i >= 3) save.abil.spell = true;
  state.mode = 'play'; show(null); resize();
  $('#hud').classList.remove('hidden');
  Dialog.active && Dialog.close();
  loadLevel(i); ambient.length = 0;
  save.checkpoint.level = i; saveGame();
  $('#dashChip').classList.toggle('hidden', !hasDash()); $('#spellChip').classList.toggle('hidden', !hasSpell());
  updateTouchVis(); renderSoul();
  running = true;
}
function pause() {
  if (state.mode !== 'play') return;
  state.mode = 'pause'; show('scrPause'); Snd.suspend(true); updateTouchVis();
}
function resume() { state.mode = 'play'; show(null); Snd.suspend(false); updateTouchVis(); last = performance.now(); }
function levelComplete() {
  if (cutscene) return;
  cutscene = { lock: true, t: 0 };
  Snd.sfx('gate'); flash(0.6);
  setTimeout(() => {
    state.mode = 'clear'; running = false;
    unlockAchievement('explorer');
    save.totalTime += stats.time;
    save.checkpoint = { level: Math.min(3, levelIdx + 1), x: 0, y: 0 }; saveGame();
    $('#clearSub').textContent = `${level.sub} · ${level.name}`;
    $('#clearTitle').textContent = 'اجتزتَ المرحلة';
    $('#stDrops').textContent = `${stats.drops}/${stats.total}`;
    $('#stTime').textContent = fmtTime(stats.time);
    $('#stDeaths').textContent = stats.deaths;
    $('#stLetters').textContent = `${save.letters.size}/8`;
    $('#stDinars').textContent = save.dinars;
    const ratio = stats.drops / Math.max(1, stats.total);
    $('#stRank').textContent = ratio >= 1 && stats.deaths === 0 ? 'التقدير: أسطورة الصحراء' : ratio >= 0.8 ? 'التقدير: فارس الكثبان' : ratio >= 0.5 ? 'التقدير: رحّالة شجاع' : 'التقدير: مسافر صبور';
    $('#hud').classList.add('hidden'); $('#hint').classList.add('hidden'); updateTouchVis();
    show('scrClear'); Snd.playMusic('victory');
  }, 900);
}
function finalVictory() {
  cutscene = { lock: true, t: 0 };
  save.totalTime += stats.time;
  const trueEnd = save.letters.size >= 8;
  setTimeout(() => {
    running = false; $('#hud').classList.add('hidden'); $('#hint').classList.add('hidden'); updateTouchVis(); Snd.wind(false);
    Story.play(trueEnd ? 'trueEnding' : 'ending', () => {
      state.mode = 'end';
      $('#enDrops').textContent = save.totalDrops; $('#enTime').textContent = fmtTime(save.totalTime); $('#enDeaths').textContent = save.totalDeaths;
      $('#enLetters').textContent = `${save.letters.size}/8`;
      $('#endTitle').textContent = trueEnd ? 'النهاية الحقيقية' : 'النهاية';
      $('#endNote').textContent = trueEnd ? 'قرأتَ رسائلَ الجدّ كلَّها، وكشفتَ سرَّ الجوهرة. أحسنت يا حارسَ الرمال.' : `جمعتَ ${save.letters.size} من 8 رسائل. اجمعها كلَّها لتكشفَ النهايةَ الحقيقية.`;
      show('scrEnd'); Snd.playMusic('victory');
    });
  }, 1800);
}
function goMenu() {
  running = false; state.mode = 'menu'; Snd.stopVoice(); subtitle(null); $('#hint').classList.add('hidden');
  if (Dialog.active) Dialog.close();
  $('#hud').classList.add('hidden'); updateTouchVis(); show('scrMenu'); Snd.suspend(false); Snd.playMusic('menu'); Snd.wind(true, 0.03);
  level = null; render();
}
const CH_STORY = ['intro', 'ch2', 'ch3', 'ch4'];
function playChapter(i) { Story.play(CH_STORY[i], () => startLevel(i)); }

function update(dt) {
  pollInput();
  if (state.mode !== 'play') return;
  if (input.pauseP) { pause(); return; }
  if (Dialog.active) {
    if (input.jumpP || input.attackP || input.confirmP || input.upP) Dialog.advance();
    updateParts(dt); updateCam(dt); updateScarf(dt);
    return;
  }
  if (hitStop > 0) { hitStop -= dt; return; }
  stats.time += dt;
  if (arena && !arena.started && !arena.done && player.x > arena.x0 + 90 && !player.dead) startArena();
  updatePlayer(dt);
  updateEnts(dt);
  if (boss) boss.update(dt);
  updateProjectiles(dt);
  updateParts(dt);
  for (let i = floaters.length - 1; i >= 0; i--) { floaters[i].a += dt; if (floaters[i].a > floaters[i].life) floaters.splice(i, 1); }
  ambientUpdate(dt);
  updateCam(dt);
  updatePShots(dt); for (const sp of sparks) sp.t += dt; sparks = sparks.filter(sp => sp.t < sp.life);
  updateTrail(dt);
}
function frameUI() {
  if (!player || state.mode !== 'play') return;
  if (hasDash()) $('#dashChip').classList.toggle('cool', !player.canDash || player.dashCd > 0);
  if (hasSpell()) $('#spellChip').classList.toggle('cool', player.soul < 33);
  if (!$('#touch').classList.contains('hidden')) {
    const sp = Math.round(player.soul);
    if (sp !== touchUI.soul) { touchUI.soul = sp; $('#tHeal').style.setProperty('--soul', Math.min(100, sp / 33 * 100)); $('#tHeal').classList.toggle('dim', sp < 33); $('#tSpell').classList.toggle('dim', sp < 33); }
    const dc = !player.canDash || player.dashCd > 0; if (dc !== touchUI.dash) { touchUI.dash = dc; $('#tDash').classList.toggle('dim', dc); }
  }
}
// ظلال الاندفاع
function updateTrail(dt) {
  const p = player; if (!p) return;
  p.trail = p.trail || []; p.trailT = (p.trailT || 0) - dt;
  if (p.dashT > 0 && p.trailT <= 0) { p.trailT = 0.035; p.trail.push({ x: p.x + p.w / 2, y: p.y + p.h, a: 1 }); }
  for (const g of p.trail) g.a -= dt * 3.2;
  while (p.trail.length && p.trail[0].a <= 0) p.trail.shift();
}
// مُكيّف الأداء: يخفّض دقّة المجسّمات تلقائياً إذا ثقل الجهاز
const perf = { avg: 16, t: 0, k: 1 };
function perfTick(dt) {
  perf.avg = perf.avg * 0.95 + dt * 1000 * 0.05; perf.t += dt;
  if (perf.t < 2) return; perf.t = 0;
  let k = perf.k;
  if (perf.avg > 24 && k > 0.55) k = Math.max(0.55, k - 0.15);
  else if (perf.avg < 15 && k < 1) k = Math.min(1, k + 0.1);
  if (k !== perf.k) { perf.k = k; if (window.R3D && R3D.ok) R3D.setQuality(opts.q * k); }
}
let frameDt = 1 / 60;
let timerAcc = 0; const touchUI = { soul: -1, dash: null };
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000 || 0); last = now; frameDt = dt || 1 / 60;
  if (running) { perfTick(dt); frameUI();
    acc += dt; const STEP = 1 / 120;
    while (acc >= STEP) { update(STEP); acc -= STEP; }
    timerAcc += dt; if (timerAcc > 0.25) { timerAcc = 0; $('#timer').textContent = fmtTime(stats.time); }
  } else pollInput();
  if (level && (running || state.mode === 'pause')) render();
  requestAnimationFrame(frame);
}

// اختبار آلي
window.render_game_to_text = () => JSON.stringify({ mode: state.mode, level: level && level.id, dialog: !!state.dialog, player: player && { x: Math.round(player.x), y: Math.round(player.y), hp: player.hp, soul: player.soul, ground: player.ground, wall: player.wall }, dinars: save.dinars, letters: save.letters.size, boss: boss && { hp: boss.hp, st: boss.st }, enemies: ents.filter(e => e.enemy && e.alive).length });
window.advanceTime = (ms) => { const n = Math.round(ms / (1000 / 120)); for (let i = 0; i < n; i++) update(1 / 120); render(); };

// ===== القدرات والتحدّيات =====
const hasDash = () => !!(level && (level.dash || save.abil.dash));
const hasSpell = () => !!(level && (level.spell || save.abil.spell));
const ABIL = {
  dash: { name: 'ريحُ السَّموم', color: '#9fe6ff', lines: [
    'نلتَ <b>الاندفاع</b>! اضغط <b>Shift</b> أو <b>C</b> — أو زرّ الريح في اللمس — لتندفعَ بسرعةٍ خاطفة، حتى وأنت في الهواء.',
    'يتجدّدُ الاندفاعُ حين تلمسُ الأرضَ أو الجدار أو ترتدُّ بضربةٍ للأسفل. وخلالَه لا يصيبُك العدوّ.',
    'أمامك هُوّةٌ لا يعبرُها القفزُ وحدَه… <b>اقفز، ثم اقفز ثانيةً، ثم اندفع</b>.'] },
  spell: { name: 'نَفثةُ الرمال', color: '#ffd27a', lines: [
    'نلتَ <b>نفثةَ الرمال</b>! اضغط <b>E</b> أو <b>I</b> — أو زرّ الدوّامة — لتُطلقَ دوّامةً تخترقُ الأعداء وتضربُ بثلاثةِ أضعافِ الجنبيّة.',
    'تستهلكُ ثلثَ كرةِ الروح، فاختر بحكمة: شفاءٌ أم هجوم؟',
    'يُقال إنّ أبوابَ إرم مختومةٌ بأختامٍ زرقاء… لا يوقظُها إلا الرمل.'] },
  mask: { name: 'قناعُ الملكة', color: '#e8a0ff', lines: ['صُنع هذا القناعُ من درعِ ملكةِ العقارب. <b>زادت أقنعتُك واحداً</b> إلى الأبد.'] },
};
function makeShrine(abil, cx, gy) { return { type: 'shrine', abil, x: cx - 30, y: gy - 118, w: 60, h: 118, t: 0 }; }
function grantAbility(abil) {
  const p = player, A = ABIL[abil];
  if (abil === 'mask') { save.up.masks++; p.maxHp++; p.hp = p.maxHp; renderHud(true); }
  else save.abil[abil] = true;
  saveGame();
  $('#dashChip').classList.toggle('hidden', !hasDash()); $('#spellChip').classList.toggle('hidden', !hasSpell()); updateTouchVis();
  if (abil === 'spell') { p.soul = Math.max(p.soul, 99); renderSoul(); }
  Snd.sfx('gem'); flash(0.7, A.color); shake(8); hitStop = 0.25;
  emit(p.x + p.w / 2, p.y + p.h / 2, 50, { color: A.color, glow: true, g: -80, min: 60, max: 320 });
  bossTitle(A.name, abil === 'mask' ? 'غنيمةُ النصر' : 'قدرةٌ جديدة');
  setTimeout(() => { if (state.mode === 'play') Dialog.open(A.name, A.lines, null); }, 2500);
}
function freeBox(x, y, w, h) {
  const l = Math.floor(x / TILE), r = Math.floor((x + w - 1) / TILE), t = Math.floor(y / TILE), b = Math.floor((y + h - 1) / TILE);
  for (let ty = t; ty <= b; ty++) for (let tx = l; tx <= r; tx++) if (isSolidCh(tileAt(tx, ty))) return false;
  return true;
}
// تصحيح الزوايا: إن لامس الرأسُ حافةَ سقفٍ بفارقٍ صغير، نُزيحه ليكمل القفزة
function cornerNudge(p) {
  for (let d = 2; d <= 16; d += 2) for (const s of [-1, 1]) {
    if (freeBox(p.x + s * d, p.y - 8, p.w, p.h)) { p.x += s * d; p.y -= 2; return true; }
  }
  return false;
}
let pshots = [], sparks = [];
function hitSpark(x, y) { sparks.push({ x, y, t: 0, a: rand(-0.6, 0.6), life: 0.14 }); }
function drawSparks(dt) {
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const s of sparks) {
    const k = s.t / s.life;
    if (s.ring) { ctx.globalAlpha = (1 - k) * 0.7; ctx.strokeStyle = '#fff4d8'; ctx.lineWidth = 5 * (1 - k) + 1; ctx.beginPath(); ctx.arc(s.x, s.y, (14 + k * 80) * (s.r || 1), 0, 7); ctx.stroke(); continue; }
    if (s.big) { const L2 = 90 + k * 160, W2 = 7 * (1 - k) + 1; ctx.globalAlpha = 1 - k; ctx.fillStyle = '#fffaf0'; ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.a); ctx.beginPath(); ctx.moveTo(-L2, 0); ctx.lineTo(0, -W2); ctx.lineTo(L2, 0); ctx.lineTo(0, W2); ctx.closePath(); ctx.fill(); ctx.restore(); continue; }
    const L = 60 * (0.6 + k), W = 9 * (1 - k);
    ctx.globalAlpha = 1 - k; ctx.fillStyle = '#fff8e8';
    for (const a of [s.a, s.a + 1.57]) { ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(a); ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(0, -W); ctx.lineTo(L, 0); ctx.lineTo(0, W); ctx.closePath(); ctx.fill(); ctx.restore(); }
  }
  ctx.restore();
}
function castSpell(p) {
  if (!hasSpell() || p.dashT > 0 || p.healT > 0 || p.castT > 0 || p.dead) return;
  if (p.soul < 33) { if (!p.noSoulT || performance.now() - p.noSoulT > 900) { p.noSoulT = performance.now(); floatText(p.x + p.w / 2, p.y - 10, 'الروحُ لا تكفي', '#9fb8c8'); Snd.sfx('deny'); } return; }
  p.soul -= 33; renderSoul();
  pshots.push({ x: p.x + p.w / 2 + p.face * 22, y: p.y + p.h / 2 - 4, vx: p.face * 980, life: 0.72, r: 24, hit: new Set(), t: 0 });
  p.castT = 0.22; p.vx = -p.face * 200; p.lockT = 0.1; p.atkDir = 's'; p.slashFx = 0.14; p.atkT = 0;
  if (!p.ground) p.vy = Math.min(p.vy, -80);
  Snd.sfx('fire'); Snd.sfx('dash'); shake(4);
  emit(p.x + p.w / 2 + p.face * 20, p.y + p.h / 2, 16, { color: '#ffd27a', glow: true, g: 0, min: 60, max: 220, lmax: 0.35 });
}
function updatePShots(dt) {
  for (const s of pshots) {
    s.t += dt; s.life -= dt; s.x += s.vx * dt;
    if (Math.random() < 0.9) parts.push({ x: s.x + rand(-10, 10), y: s.y + rand(-14, 14), vx: -s.vx * 0.12, vy: rand(-40, 40), life: 0.35, t: 0, size: rand(2, 4.5), color: Math.random() < 0.5 ? '#ffd27a' : '#9fe6ff', g: 0, drag: 0.9, glow: true });
    const box = { x: s.x - s.r, y: s.y - s.r, w: s.r * 2, h: s.r * 2 };
    if (isSolidCh(tileAt(Math.floor((s.x + Math.sign(s.vx) * 10) / TILE), Math.floor(s.y / TILE)))) { s.life = 0; emit(s.x, s.y, 18, { color: '#ffd27a', glow: true, min: 60, max: 240 }); Snd.sfx('clink'); }
    for (const e of ents) {
      if (s.hit.has(e)) continue;
      if (e.enemy && e.alive && overlap(box, e)) { s.hit.add(e); damageEnemy(e, 3 + save.up.blade * 2, true); }
      else if (e.type === 'jar' && !e.broken && overlap(box, e)) { s.hit.add(e); breakJar(e); }
      else if (e.type === 'seal' && !e.lit && overlap(box, e)) { s.hit.add(e); lightSeal(e); }
    }
    if (boss && !boss.dead && !s.hit.has(boss)) for (const hb of boss.hurt()) if (overlap(box, hb)) { s.hit.add(boss); boss.damage(3 + save.up.blade * 2, box); break; }
    for (const pr of projectiles) if (!pr.wave && pr.r && Math.hypot(pr.x - s.x, pr.y - s.y) < pr.r + s.r) { pr.dead = true; emit(pr.x, pr.y, 8, { color: '#fff3c0', glow: true }); }
  }
  pshots = pshots.filter(s => s.life > 0);
}
function drawPShots() {
  for (const s of pshots) {
    glow(s.x, s.y, 60, 'rgba(255,200,110,0.45)');
    ctx.save(); ctx.translate(s.x, s.y); ctx.scale(Math.sign(s.vx), 1);
    ctx.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const a = s.t * 22 + i * 1.6, r = s.r - i * 4;
      ctx.strokeStyle = i % 2 ? 'rgba(159,230,255,0.9)' : 'rgba(255,214,130,0.95)'; ctx.lineWidth = 5 - i;
      ctx.beginPath(); ctx.ellipse(0, 0, r, r * 0.7, 0, a, a + 3.6); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(255,245,220,0.9)'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, 7); ctx.fill();
    ctx.restore();
  }
}
function lightSeal(e) {
  e.lit = true; e.t = 0; Snd.sfx('gem'); shake(4); flash(0.2, '#9fe6ff');
  emit(e.x + e.w / 2, e.y + e.h / 2, 30, { color: '#ffd27a', glow: true, g: -60, min: 40, max: 200 });
  const all = ents.filter(o => o.type === 'seal'), n = all.filter(o => o.lit).length;
  floatText(e.x + e.w / 2, e.y - 10, `ختم ${n}/${all.length}`, '#ffd27a');
  if (n === all.length) openSealDoors();
}
function openSealDoors() {
  for (const d of ents) if (d.type === 'sdoor' && !d.open) {
    d.open = true; d.t = 0;
    for (let y = d.ty0; y <= d.ty1; y++) for (let x = d.tx; x < d.tx + 2; x++) level.g[y][x] = ' ';
    tileCanvas = prerenderTiles(); Snd.sfx('erupt'); Snd.sfx('rumble'); shake(14);
    floatText(d.x + TILE, d.y + d.h - 120, 'انفتح بابُ إرم', '#ffd27a');
    emit(d.x + TILE, d.y + d.h - 20, 40, { color: level.pal.stone, min: 60, max: 260 });
  }
}
function startAmbush(e) {
  e.st = 'fight'; e.wave = -1; e.t = 0; e.saved = []; e.spawned = [];
  const top = Math.floor(e.gy / TILE) - 9;
  for (let y = Math.max(0, top); y < Math.floor(e.gy / TILE); y++) for (const x of [e.x0, e.x1]) { e.saved.push([x, y, level.g[y][x]]); level.g[y][x] = '#'; }
  tileCanvas = prerenderTiles(); Snd.sfx('bosstitle'); Snd.sfx('rumble'); shake(10);
  bossTitle('كمين!', 'اهزمِ الموجاتِ لتعبُر');
  emit(e.x0 * TILE + 24, e.gy - 100, 30, { color: level.pal.top, min: 40, max: 200 }); emit(e.x1 * TILE + 24, e.gy - 100, 30, { color: level.pal.top, min: 40, max: 200 });
}
function endAmbush(e, win) {
  for (const [x, y, c] of e.saved) level.g[y][x] = c; e.saved = [];
  tileCanvas = prerenderTiles();
  if (win) {
    e.st = 'done'; Snd.sfx('checkpoint'); shake(6);
    const cx = (e.x0 + e.x1) / 2 * TILE + 24;
    floatText(cx, e.gy - 160, 'انتصرتَ على الكمين', '#ffd27a'); dropCoins(cx, e.gy - 60, 25);
    if (e.reward && !save.abil[e.reward]) ents.push(makeShrine(e.reward, cx, e.gy));
  }
}
function resetAmbush(e) { ents = ents.filter(o => !(e.spawned || []).includes(o)); endAmbush(e, false); e.st = 'wait'; }
function spawnWave(e) {
  const list = e.waves[e.wave], L0 = (e.x0 + 1) * TILE, L1 = e.x1 * TILE;
  list.forEach((type, i) => {
    const left = i % 2 === 0, x = left ? L0 + 30 + i * 20 : L1 - 90 - i * 20;
    let m;
    if (type === 'bat') m = makeEnemy('bat', x, e.gy - 260, { bx: x, by: e.gy - 260, range: 2 * TILE, dive: 0 });
    else if (type === 'wisp') m = makeEnemy('wisp', x, e.gy - 240, { hx: x, hy: e.gy - 240, shotT: 1.5 });
    else if (type === 'spirit') m = makeEnemy('spirit', x, e.gy - 220);
    else { const h = type === 'ghoul' ? 84 : type === 'soldier' ? 80 : 38; m = makeEnemy(type, x, e.gy - h, { min: L0, max: L1, vx: left ? 90 : -90 }); }
    m.dir = left ? 1 : -1; ents.push(m); e.spawned.push(m);
    emit(m.x + m.w / 2, m.y + m.h, 18, { color: level.pal.top, angle: -Math.PI / 2, spread: 1.2, min: 60, max: 260 });
  });
  Snd.sfx('erupt'); shake(5);
  floatText((e.x0 + e.x1) / 2 * TILE, e.gy - 220, `الموجة ${e.wave + 1}/${e.waves.length}`, '#ffe7b0');
}
const XU = {
  shrine(e, dt, p) {
    if (!e.taken && overlap(p, e) && !p.dead) { e.taken = true; e.got = true; grantAbility(e.abil); }
  },
  ambush(e, dt, p) {
    const px = p.x + p.w / 2;
    if (e.st === 'wait') { if (!p.dead && p.ground && px > (e.x0 + 3) * TILE && px < (e.x1 - 2) * TILE) startAmbush(e); return; }
    if (e.st !== 'fight') return;
    const alive = e.spawned.some(m => m.alive);
    if (!alive && e.t > 0.9) {
      e.wave++; e.t = 0;
      if (e.wave >= e.waves.length) endAmbush(e, true); else spawnWave(e);
    }
    if (alive) e.t = 0;
  },
  seal(e, dt, p) {
    if (!e.lit && p.atkT > 0 && overlap(attackBox(p), e) && (!e.warn || e.t - e.warn > 1.5)) { e.warn = e.t; Snd.sfx('clink'); floatText(e.x + e.w / 2, e.y - 10, 'الختمُ لا يستجيبُ إلا للرمل', '#9fe6ff'); }
  },
  sdoor(e, dt) {},
};
const XD = {
  shrine(e, t) {
    const A = ABIL[e.abil], cx = e.x + e.w / 2, gy = e.y + e.h;
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 5; i++) { const a = t * 0.6 + i * 1.256; ctx.fillStyle = 'rgba(255,230,170,0.07)'; ctx.beginPath(); ctx.moveTo(cx, gy - 70); ctx.lineTo(cx + Math.cos(a) * 160, gy - 70 + Math.sin(a) * 160 - 60); ctx.lineTo(cx + Math.cos(a + 0.2) * 160, gy - 70 + Math.sin(a + 0.2) * 160 - 60); ctx.fill(); }
    ctx.restore();
    ctx.fillStyle = level.pal.stone2; ctx.fillRect(cx - 24, gy - 40, 48, 40); ctx.fillStyle = level.pal.stone; ctx.fillRect(cx - 30, gy - 46, 60, 10); ctx.fillRect(cx - 28, gy - 6, 56, 6);
    ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 2; ctx.strokeRect(cx - 24, gy - 40, 48, 34);
    const oy = gy - 80 + Math.sin(t * 2.4) * 6;
    glow(cx, oy, 70, A.color + '88');
    ctx.fillStyle = A.color; ctx.beginPath(); ctx.arc(cx, oy, 14, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(cx - 4, oy - 4, 5, 0, 7); ctx.fill();
    ctx.strokeStyle = A.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(cx, oy, 24, 8, t * 1.5, 0, 7); ctx.stroke();
  },
  ambush(e, t) {
    if (e.st !== 'fight') return;
    for (const x of [e.x0, e.x1]) {
      const X = x * TILE, top = e.gy - 9 * TILE;
      const g = ctx.createLinearGradient(X, 0, X + TILE, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(255,200,120,0.35)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fillRect(X - 10, top, TILE + 20, e.gy - top);
      ctx.strokeStyle = 'rgba(255,230,170,0.5)'; ctx.lineWidth = 2;
      for (let i = 0; i < 6; i++) { const y = top + ((t * 160 + i * 70) % (e.gy - top)); ctx.beginPath(); ctx.ellipse(X + 24, y, 30, 6, 0, 0, 7); ctx.stroke(); }
    }
  },
  seal(e, t) {
    const cx = e.x + e.w / 2, cy = e.y + e.h / 2 + Math.sin(t * 2 + e.x) * 3;
    glow(cx, cy, e.lit ? 80 : 50, e.lit ? 'rgba(255,210,120,0.6)' : `rgba(110,200,255,${0.25 + Math.sin(t * 3) * 0.1})`);
    ctx.fillStyle = level.pal.stone2; ctx.beginPath(); ctx.moveTo(cx, cy - 30); ctx.lineTo(cx + 22, cy); ctx.lineTo(cx, cy + 30); ctx.lineTo(cx - 22, cy); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = e.lit ? '#ffd27a' : '#7fdcf5'; ctx.lineWidth = 3; ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, 9, 0, 7); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy - 16); ctx.lineTo(cx, cy + 16); ctx.moveTo(cx - 10, cy); ctx.lineTo(cx + 10, cy); ctx.stroke();
  },
  sdoor(e, t) {
    const k = e.open ? Math.min(1, e.t / 1.2) : 0; if (k >= 1) return;
    const off = k * e.h, x = e.x, y = e.y - off, w = e.w, h = e.h;
    ctx.save(); ctx.beginPath(); ctx.rect(x - 10, e.y - 400, w + 20, e.h + 400); ctx.clip();
    ctx.fillStyle = level.pal.stone2; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = level.pal.stone; for (let yy = y; yy < y + h; yy += 48) ctx.fillRect(x + 4, yy + 4, w - 8, 40);
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 2; for (let yy = y; yy < y + h; yy += 48) ctx.strokeRect(x + 4, yy + 4, w - 8, 40);
    const seals = ents.filter(o => o.type === 'seal');
    seals.forEach((s2, i) => { const sy = y + h - 150 + i * 44, sx = x + w / 2; glow(sx, sy, 30, s2.lit ? 'rgba(255,210,120,0.7)' : 'rgba(110,200,255,0.35)'); ctx.fillStyle = s2.lit ? '#ffd27a' : '#3f7f9a'; ctx.beginPath(); ctx.arc(sx, sy, 10, 0, 7); ctx.fill(); });
    ctx.restore();
  },
};
window.__game = { get pshots() { return pshots; }, grantAbility, startLevel, get player() { return player; }, get boss() { return boss; }, get arena() { return arena; }, get ents() { return ents; }, get level() { return level; }, save, saveGame, loadGame, switchSaveSlot, saveSlotSummary, get activeSlot() { return activeSlot; }, setKey: (k, v) => { keys[k] = v; if (v) latched[k] = true; }, tap: (k) => { latched[k] = true; }, finalVictory, levelComplete, Dialog, IMG, opts, get cam() { return cam; } };

// ===== السوق =====
const SHOP = [
  { id: 'mask1', name: 'قناعُ الصحراء', desc: 'قناعٌ إضافيّ يزيدُ صحّتك.', price: 120, buy: () => save.up.masks++ },
  { id: 'focus', name: 'مسبحةُ السكينة', desc: 'تشفي نفسكَ أسرعَ بكثير.', price: 150, buy: () => save.up.focus = true },
  { id: 'soul', name: 'قلادةُ الروح', desc: 'تجمعُ الروحَ أسرعَ بنصفِ المقدار.', price: 150, buy: () => save.up.soul = true },
  { id: 'blade', name: 'جنبيّةُ الحدّاد', desc: 'ضربةٌ أقوى وأطول مدى.', price: 200, buy: () => save.up.blade++ },
  { id: 'mask2', name: 'قناعُ الأجداد', desc: 'قناعٌ إضافيٌّ آخر.', price: 240, buy: () => save.up.masks++ },
];
let shopReturn = 'scrClear';
function openShop(ret) {
  shopReturn = ret || 'scrClear'; show('scrShop'); state.mode = 'shop'; Snd.playMusic('shop'); renderShop();
  if (!save.met.shopVoice) { save.met.shopVoice = true; Snd.voice('assets/audio/n_merchant.mp3'); }
}
function renderShop() {
  $('#shopDinars').textContent = save.dinars;
  $('#shopList').innerHTML = SHOP.map(it => {
    const owned = save.bought[it.id], poor = save.dinars < it.price;
    return `<button class="item ${owned ? 'owned' : ''} ${poor && !owned ? 'poor' : ''}" data-item="${it.id}" ${owned ? 'disabled' : ''}>
      <span class="iname">${it.name}</span><span class="idesc">${it.desc}</span>
      <span class="iprice">${owned ? 'تمّ الشراء' : it.price + ' دينار'}</span></button>`;
  }).join('');
  $('#shopList').querySelectorAll('.item').forEach(b => b.addEventListener('click', () => {
    const it = SHOP.find(s => s.id === b.dataset.item);
    if (save.bought[it.id]) return;
    if (save.dinars < it.price) { Snd.sfx('deny'); $('#shopSay').textContent = 'الدنانيرُ لا تكفي يا عبسي… اضربِ المزيدَ من الأعداء واكسرِ الجِرار.'; return; }
    save.dinars -= it.price; save.bought[it.id] = true; it.buy(); saveGame(); Snd.sfx('buy');
    $('#shopSay').textContent = `«${it.name}»… اختيارٌ موفّق يا بطل.`; renderShop();
  }));
}

// ===== دفتر الرسائل =====
let journalReturn = 'scrPause';
function openJournal(ret) {
  journalReturn = ret; show('scrJournal');
  $('#journalCount').textContent = `${save.letters.size} / 8`;
  $('#journalList').innerHTML = LETTERS.map((t, i) => save.letters.has(i)
    ? `<article class="jl"><h4>الرسالة ${i + 1}</h4><p>${t}</p></article>`
    : `<article class="jl locked"><h4>الرسالة ${i + 1}</h4><p>لم تجدها بعد… ${['في الكثبان', 'في الكثبان', 'في الوادي', 'في الوادي', 'في البئر', 'في البئر', 'في إرم', 'في إرم'][i]}.</p></article>`).join('');
}

// ===== واجهات القوائم =====
function buildChapters() {
  const list = $('#chapterList');
  const L = [{ n: 'الكثبان الذهبية', s: 'الفصل الأول', img: 'intro1' }, { n: 'وادي الصدى', s: 'الفصل الثاني', img: 'ch2' }, { n: 'بئر برهوت', s: 'الفصل الثالث', img: 'well' }, { n: 'إرَمُ ذاتُ العِماد', s: 'الفصل الرابع', img: 'ch3' }];
  list.innerHTML = L.map((c, i) => `<button class="chap" data-ch="${i}" style="background-image:url(assets/img/${c.img}.jpg)"><div class="cap"><small>${c.s}</small><span>${c.n}</span></div></button>`).join('');
  list.querySelectorAll('.chap').forEach(b => b.addEventListener('click', () => playChapter(+b.dataset.ch)));
}
let settingsReturn = 'scrMenu';
function resetSaveData() {
  Object.assign(save, { dinars: 0, totalDrops: 0, totalTime: 0, totalDeaths: 0, met: {}, bought: {}, achievements: {}, checkpoint: { level: 0, x: 0, y: 0 } });
  save.letters.clear(); Object.assign(save.up, { masks: 0, blade: 0, focus: false, soul: false }); Object.assign(save.abil, { dash: false, spell: false });
}
function ensureSaveSlotsScreen() {
  if ($('#scrSaveSlots')) return;
  const screen = document.createElement('section'); screen.id = 'scrSaveSlots'; screen.className = 'screen panel-screen';
  screen.innerHTML = '<div class="art dim" style="background-image:url(assets/img/title.jpg)"></div><div class="panel wide"><h2>خانات الحفظ</h2><p class="muted" id="saveSlotHint">اختر خانةً للمتابعة أو بدء مغامرة جديدة.</p><div class="chapters" id="saveSlotList"></div><button class="btn ghost" data-act="saveBack">رجوع</button></div>';
  $('#app').appendChild(screen);
}
function openSaveSlots(mode) {
  ensureSaveSlotsScreen(); state.saveSlotMode = mode; settingsReturn = 'scrMenu';
  const list = $('#saveSlotList');
  list.innerHTML = [0, 1, 2].map(slot => {
    const s = saveSlotSummary(slot), label = s.corrupt ? 'بيانات تالفة' : s.empty ? 'فارغة' : `الفصل ${s.level + 1} · ${s.dinars} دينار · ${s.letters}/8 رسائل`;
    return `<button class="chap ${s.corrupt ? 'locked' : ''}" data-slot="${slot}"><div class="cap"><small>الخانة ${slot + 1}</small><span>${label}</span></div></button>`;
  }).join('');
  list.querySelectorAll('[data-slot]').forEach(button => button.addEventListener('click', () => {
    const slot = +button.dataset.slot, summary = saveSlotSummary(slot);
    if (summary.corrupt) { $('#saveSlotHint').textContent = 'هذه الخانة تالفة ولا يمكن تحميلها.'; return; }
    switchSaveSlot(slot);
    if (state.saveSlotMode === 'new' || summary.empty) { resetSaveData(); saveGame(); playChapter(0); return; }
    startLevel(Math.max(0, Math.min(3, save.checkpoint.level || 0)));
  }));
  $('#saveSlotHint').textContent = mode === 'new' ? 'اختر خانةً جديدة. ستُستبدل بياناتها الحالية.' : 'اختر خانةً للمتابعة.';
  show('scrSaveSlots'); state.mode = 'menu';
}
const menuList = $('#scrMenu .menu-list');
if (menuList) {
  const slotButton = document.createElement('button'); slotButton.className = 'btn'; slotButton.dataset.act = 'slots'; slotButton.textContent = 'الحفظ والمتابعة'; menuList.insertBefore(slotButton, menuList.children[1]);
  const achievementButton = document.createElement('button'); achievementButton.className = 'btn'; achievementButton.dataset.act = 'achievements'; achievementButton.textContent = 'الإنجازات'; menuList.insertBefore(achievementButton, menuList.children[2]);
}
function openAchievements() {
  if (!$('#scrAchievements')) {
    const screen = document.createElement('section'); screen.id = 'scrAchievements'; screen.className = 'screen panel-screen';
    screen.innerHTML = '<div class="art dim" style="background-image:url(assets/img/ch3.jpg)"></div><div class="panel wide"><h2>الإنجازات</h2><div class="chapters" id="achievementList"></div><button class="btn ghost" data-act="achievementBack">رجوع</button></div>';
    $('#app').appendChild(screen);
  }
  $('#achievementList').innerHTML = Object.entries(ACHIEVEMENTS).map(([id, a]) => `<article class="chap ${save.achievements[id] ? '' : 'locked'}"><div class="cap"><small>${save.achievements[id] ? 'مفتوح' : 'مقفل'}</small><span>${a.name}</span><p>${a.desc}</p></div></article>`).join('');
  settingsReturn = 'scrMenu'; state.mode = 'menu'; show('scrAchievements');
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act],[data-back]'); if (!b) return;
  if (b.hasAttribute('data-back')) { show(settingsReturn); if (settingsReturn === 'scrPause') state.mode = 'pause'; settingsReturn = 'scrMenu'; return; }
  switch (b.dataset.act) {
    case 'new': openSaveSlots('new'); break;
    case 'slots': openSaveSlots('continue'); break;
    case 'saveBack': show('scrMenu'); break;
    case 'achievements': openAchievements(); break;
    case 'achievementBack': show('scrMenu'); break;
    case 'chapters': buildChapters(); show('scrChapters'); break;
    case 'howto': show('scrHowto'); break;
    case 'settings': settingsReturn = 'scrMenu'; show('scrSettings'); break;
    case 'settingsInGame': settingsReturn = 'scrPause'; show('scrSettings'); break;
    case 'about': show('scrAbout'); break;
    case 'journal': openJournal('scrPause'); break;
    case 'journalMenu': openJournal('scrMenu'); break;
    case 'journalBack': show(journalReturn); break;
    case 'shop': openShop('scrClear'); break;
    case 'shopBack': Snd.stopVoice(); show(shopReturn); state.mode = 'clear'; Snd.playMusic('victory'); break;
    case 'resume': resume(); break;
    case 'restart': Snd.suspend(false); startLevel(levelIdx); break;
    case 'quit': goMenu(); break;
    case 'replay': startLevel(levelIdx); break;
    case 'continue':
      if (levelIdx < 3) playChapter(levelIdx + 1);
      break;
  }
});
$('#btnPause').addEventListener('click', pause);
$('#volMusic').addEventListener('input', e => Snd.setVolume('music', e.target.value / 100));
$('#volSfx').addEventListener('input', e => { Snd.setVolume('sfx', e.target.value / 100); Snd.sfx('coin'); });
$('#volVoice').addEventListener('input', e => Snd.setVolume('voice', e.target.value / 100));
$('#optShake').addEventListener('change', e => opts.shake = e.target.checked);
$('#optSubs').addEventListener('change', e => opts.subs = e.target.checked);
$('#optTouch').addEventListener('change', e => { opts.touch = e.target.value; updateTouchVis(); });
$('#optPad').addEventListener('change', e => { opts.pad = e.target.value; applyPadOpts(); });
$('#optLayout').addEventListener('change', e => { opts.layout = e.target.value; applyPadOpts(); });
$('#optBtn').addEventListener('change', e => { opts.btn = +e.target.value; applyPadOpts(); });
$('#optQ').addEventListener('change', e => { opts.q = +e.target.value; applyPadOpts(); });
applyPadOpts();
$('#optDiff').addEventListener('change', e => opts.diff = e.target.value);

// ===== الإقلاع =====
loadGame();
window.addEventListener('resize', () => { resize(); if (level) render(); });
resize();
const loading = Promise.all([loadImages(), document.fonts ? document.fonts.ready : Promise.resolve()]);
loading.then(() => { $('#loadMsg').textContent = 'جاهز للمغامرة'; });
$('#btnBoot').addEventListener('click', async () => {
  Snd.init();
  await loading;
  state.mode = 'menu'; show('scrMenu'); Snd.playMusic('menu'); Snd.wind(true, 0.03);
});
// عرض المجسّم في القائمة
let showT = 0;
(function showLoop(now) {
  if (state.screen === 'scrMenu' && window.Zayd3D && Zayd3D.ok && now - showT > 33) { showT = now; Zayd3D.portrait($('#zaydShow'), now / 1000); }
  requestAnimationFrame(showLoop);
})(0);
requestAnimationFrame(t => { last = t; frame(t); });
})();

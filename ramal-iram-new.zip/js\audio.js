// محرك الصوت: موسيقى عربية مولّدة (مقامات حجاز/كرد/صبا/راست) + مؤثرات صوتية + رواية صوتية
const Snd = (() => {
  let ctx = null, master, musicBus, sfxBus, reverb, delay, delayFb, noiseBuf;
  const vol = { music: 0.55, sfx: 0.8, voice: 1.0 };
  let track = null, nextTime = 0, step = 0, timer = null, duckLevel = 1;
  let voiceEl = null, windNode = null;

  const MAQAM = {
    hijaz: [0, 1, 4, 5, 7, 8, 10, 12, 13, 16],
    kurd: [0, 1, 3, 5, 7, 8, 10, 12, 13, 15],
    saba: [0, 1.5, 3, 4, 7, 8, 10, 12, 13.5, 15],
    rast: [0, 2, 3.5, 5, 7, 9, 10.5, 12, 14, 15.5],
    bayati: [0, 1.5, 3, 5, 7, 8, 10, 12, 13.5, 15],
  };
  // إيقاعات: D=دُم، T=تَك، t=تك خفيف
  const RHYTHM = {
    maqsum: 'DT.TD.T.',
    baladi: 'DD.TD.T.',
    saidi: 'DT.DD.T.',
    malfuf: 'D..T..T.',
    ayub: 'D.TDT.T.',
    fast: 'DtTtDtTt',
    none: '........',
  };
  const TRACKS = {
    menu: { bpm: 72, root: 146.83, scale: 'hijaz', rhythm: 'malfuf', lead: 'ney', density: 0.35, drone: true, perc: 0.5, seed: 3 },
    level1: { bpm: 104, root: 146.83, scale: 'hijaz', rhythm: 'maqsum', lead: 'oud', density: 0.62, drone: true, perc: 1, seed: 11 },
    level2: { bpm: 88, root: 138.59, scale: 'kurd', rhythm: 'ayub', lead: 'ney', lead2: 'oud', density: 0.5, drone: true, perc: 0.8, seed: 21 },
    level3: { bpm: 96, root: 146.83, scale: 'saba', rhythm: 'saidi', lead: 'oud', lead2: 'ney', density: 0.55, drone: true, perc: 0.9, seed: 33 },
    boss: { bpm: 138, root: 146.83, scale: 'hijaz', rhythm: 'fast', lead: 'oud', lead2: 'qanun', density: 0.75, drone: true, perc: 1.2, seed: 44, dark: true },
    story: { bpm: 60, root: 146.83, scale: 'bayati', rhythm: 'none', lead: 'ney', density: 0.25, drone: true, perc: 0, seed: 7 },
    well: { bpm: 70, root: 130.81, scale: 'kurd', rhythm: 'malfuf', lead: 'ney', lead2: 'qanun', density: 0.3, drone: true, perc: 0.45, seed: 61, dark: true },
    queen: { bpm: 126, root: 138.59, scale: 'kurd', rhythm: 'saidi', lead: 'oud', lead2: 'qanun', density: 0.7, drone: true, perc: 1.2, seed: 71, dark: true },
    serpent: { bpm: 132, root: 130.81, scale: 'saba', rhythm: 'fast', lead: 'oud', lead2: 'ney', density: 0.72, drone: true, perc: 1.2, seed: 81, dark: true },
    boss2: { bpm: 150, root: 146.83, scale: 'hijaz', rhythm: 'fast', lead: 'qanun', lead2: 'oud', density: 0.8, drone: true, perc: 1.35, seed: 91, dark: true },
    shop: { bpm: 100, root: 164.81, scale: 'rast', rhythm: 'baladi', lead: 'oud', lead2: 'qanun', density: 0.5, drone: true, perc: 0.7, seed: 17 },
    victory: { bpm: 96, root: 164.81, scale: 'rast', rhythm: 'baladi', lead: 'qanun', lead2: 'oud', density: 0.6, drone: true, perc: 1, seed: 55 },
  };

  function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

  function init() {
    if (ctx) { ctx.resume(); return; }
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain(); master.gain.value = 0.9;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    master.connect(comp).connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = vol.music;
    sfxBus = ctx.createGain(); sfxBus.gain.value = vol.sfx;
    musicBus.connect(master); sfxBus.connect(master);
    // ريفيرب مولّد
    reverb = ctx.createConvolver();
    const len = ctx.sampleRate * 2.6, ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2); }
    reverb.buffer = ir;
    const rvGain = ctx.createGain(); rvGain.gain.value = 0.32; reverb.connect(rvGain).connect(musicBus);
    delay = ctx.createDelay(1.5); delayFb = ctx.createGain(); delayFb.gain.value = 0.3;
    const dlGain = ctx.createGain(); dlGain.gain.value = 0.22;
    delay.connect(delayFb).connect(delay); delay.connect(dlGain).connect(musicBus);
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const nd = noiseBuf.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  }

  function out(node, wet = 0.5, dly = 0) {
    node.connect(musicBus);
    if (wet > 0) { const g = ctx.createGain(); g.gain.value = wet; node.connect(g).connect(reverb); }
    if (dly > 0) { const g = ctx.createGain(); g.gain.value = dly; node.connect(g).connect(delay); }
  }
  const f = (root, semi, oct = 0) => root * Math.pow(2, semi / 12 + oct);

  // ===== الآلات =====
  function oud(t, freq, dur, v = 0.25) {
    const g = ctx.createGain(), lp = ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.Q.value = 3;
    lp.frequency.setValueAtTime(freq * 9, t); lp.frequency.exponentialRampToValueAtTime(freq * 1.6, t + 0.35);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(0.35, dur * 1.4));
    for (const [type, mul, det] of [['sawtooth', 1, -4], ['triangle', 1, 5], ['square', 2, 0]]) {
      const o = ctx.createOscillator(); o.type = type; o.frequency.value = freq * mul; o.detune.value = det;
      const og = ctx.createGain(); og.gain.value = type === 'square' ? 0.12 : 0.5;
      o.connect(og).connect(lp); o.start(t); o.stop(t + dur * 1.5 + 0.4);
    }
    lp.connect(g); out(g, 0.35, 0.25);
  }
  function qanun(t, freq, dur, v = 0.16) {
    for (let i = 0; i < 2; i++) {
      const tt = t + i * 0.045, o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'triangle'; o.frequency.value = freq * (i ? 2 : 1);
      g.gain.setValueAtTime(0.0001, tt); g.gain.exponentialRampToValueAtTime(v * (i ? 0.5 : 1), tt + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, tt + 0.6);
      o.connect(g); out(g, 0.5, 0.3); o.start(tt); o.stop(tt + 0.7);
    }
  }
  function ney(t, freq, dur, v = 0.13) {
    const o = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain();
    o.type = 'sine'; o2.type = 'triangle'; o.frequency.value = freq; o2.frequency.value = freq * 2;
    lfo.frequency.value = 5.2; lg.gain.value = freq * 0.012; lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency);
    const g2 = ctx.createGain(); g2.gain.value = 0.18; o2.connect(g2).connect(g); o.connect(g);
    // نَفَس
    const n = ctx.createBufferSource(); n.buffer = noiseBuf; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = freq * 2; bp.Q.value = 6;
    const ng = ctx.createGain(); ng.gain.value = 0.35; n.connect(bp).connect(ng).connect(g);
    const d = Math.max(0.3, dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + Math.min(0.18, d * 0.4));
    g.gain.setValueAtTime(v, t + d * 0.75); g.gain.linearRampToValueAtTime(0.0001, t + d + 0.15);
    out(g, 0.7, 0.35);
    [o, o2, lfo, n].forEach(x => { x.start(t); x.stop(t + d + 0.2); });
  }
  function drone(t, freq, dur, dark) {
    const g = ctx.createGain(), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = dark ? 380 : 520;
    for (const m of [0.5, 0.75, 1]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = freq * m; o.detune.value = (Math.random() - 0.5) * 8;
      const og = ctx.createGain(); og.gain.value = m === 0.75 ? 0.25 : 0.4; o.connect(og).connect(lp); o.start(t); o.stop(t + dur + 0.5);
    }
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.05, t + dur * 0.3);
    g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.4);
    lp.connect(g); out(g, 0.6);
  }
  function doum(t, v = 0.7) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(52, t + 0.25);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.45);
    o.connect(g); out(g, 0.15); o.start(t); o.stop(t + 0.5);
  }
  function tak(t, v = 0.35, hi = true) {
    const n = ctx.createBufferSource(); n.buffer = noiseBuf; const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = hi ? 3200 : 1800; bp.Q.value = 1.2;
    const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + (hi ? 0.07 : 0.12));
    const o = ctx.createOscillator(); o.frequency.value = hi ? 820 : 520; const og = ctx.createGain();
    og.gain.setValueAtTime(v * 0.5, t); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);
    n.connect(bp).connect(g); o.connect(og); out(g, 0.2); out(og, 0.1);
    n.start(t, Math.random()); n.stop(t + 0.15); o.start(t); o.stop(t + 0.06);
  }
  function riq(t, v = 0.1) {
    const n = ctx.createBufferSource(); n.buffer = noiseBuf; const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 7000;
    const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
    n.connect(hp).connect(g); out(g, 0.2); n.start(t, Math.random()); n.stop(t + 0.1);
  }
  const INST = { oud, qanun, ney };

  // ===== المؤلف =====
  function compose(cfg) {
    const r = rng(cfg.seed), sc = MAQAM[cfg.scale];
    const makePhrase = () => {
      const ph = []; let idx = 3 + Math.floor(r() * 3);
      for (let i = 0; i < 16; i++) {
        if (r() < cfg.density || i === 0) {
          idx += Math.round((r() - 0.5) * 3.2); idx = Math.max(0, Math.min(sc.length - 1, idx));
          let len = r() < 0.3 ? 2 : 1; if (cfg.lead === 'ney' && r() < 0.5) len = 2 + Math.floor(r() * 3);
          ph.push({ s: i, n: idx, len });
        }
      }
      ph.push({ s: 14, n: 0, len: 2 });
      return ph.filter((p, i, a) => !a.slice(0, i).some(q => q.s === p.s));
    };
    const A = makePhrase(), B = makePhrase(), C = makePhrase();
    const vary = (ph) => ph.map(p => ({ ...p, n: Math.max(0, Math.min(sc.length - 1, p.n + (r() < 0.25 ? (r() < 0.5 ? 1 : -1) : 0))) }));
    return { form: [A, vary(A), B, A, C, vary(B), A, vary(C)], sc, bass: [0, 0, 5, 0, 3, 4, 0, 5] };
  }

  function schedule() {
    if (!track) return;
    const cfg = track.cfg, spb = 60 / cfg.bpm / 2; // ثُمن
    while (nextTime < ctx.currentTime + 0.25) {
      const t = nextTime, bar = Math.floor(step / 16) % track.comp.form.length, s = step % 16;
      const ph = track.comp.form[bar], sc = track.comp.sc;
      for (const n of ph) if (n.s === s) {
        const inst = (cfg.lead2 && bar % 4 >= 2) ? cfg.lead2 : cfg.lead;
        INST[inst](t, f(cfg.root, sc[n.n], 1), n.len * spb, inst === 'ney' ? 0.12 : undefined);
        if (inst === 'oud' && n.len >= 2 && Math.random() < 0.4) oud(t + spb * 0.5, f(cfg.root, sc[n.n], 1), spb, 0.12); // ريشة مزدوجة
      }
      const rh = RHYTHM[cfg.rhythm], ch = rh[s % 8];
      if (cfg.perc > 0) {
        if (ch === 'D') doum(t, 0.55 * cfg.perc);
        else if (ch === 'T') tak(t, 0.28 * cfg.perc);
        else if (ch === 't') tak(t, 0.14 * cfg.perc, false);
        else if (cfg.perc >= 0.8 && Math.random() < 0.35) riq(t, 0.06 * cfg.perc);
      }
      if (cfg.drone && s === 0 && bar % 2 === 0) drone(t, f(cfg.root, sc[track.comp.bass[bar]] || 0, -1), spb * 32, cfg.dark);
      if (cfg.perc > 0 && s === 0) { const bn = f(cfg.root, sc[track.comp.bass[bar]] || 0, -2); oud(t, bn, spb * 2, 0.16); }
      nextTime += spb; step++;
    }
  }

  function playMusic(name) {
    if (!ctx) return;
    if (track && track.name === name) return;
    stopMusic(true);
    const cfg = TRACKS[name]; if (!cfg) return;
    track = { name, cfg, comp: compose(cfg) };
    step = 0; nextTime = ctx.currentTime + 0.1;
    musicBus.gain.cancelScheduledValues(ctx.currentTime);
    musicBus.gain.setValueAtTime(0.0001, ctx.currentTime);
    musicBus.gain.linearRampToValueAtTime(vol.music * duckLevel, ctx.currentTime + 1.2);
    timer = setInterval(schedule, 50); schedule();
  }
  function stopMusic() { if (timer) clearInterval(timer); timer = null; track = null; }
  function setDuck(on) {
    duckLevel = on ? 0.28 : 1; if (!ctx) return;
    musicBus.gain.cancelScheduledValues(ctx.currentTime);
    musicBus.gain.linearRampToValueAtTime(vol.music * duckLevel, ctx.currentTime + 0.4);
  }

  // ===== الرياح =====
  function wind(on, strength = 0.06) {
    if (!ctx) return;
    if (windNode) { const w = windNode; w.g.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 1); setTimeout(() => { try { w.src.stop(); } catch (e) {} }, 1200); windNode = null; }
    if (!on) return;
    const src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 500; bp.Q.value = 0.8;
    const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.13; lg.gain.value = 300; lfo.connect(lg).connect(bp.frequency); lfo.start();
    const g = ctx.createGain(); g.gain.value = 0.0001; g.gain.linearRampToValueAtTime(strength, ctx.currentTime + 2);
    src.connect(bp).connect(g).connect(sfxBus); src.start();
    windNode = { src, g };
  }

  // ===== المؤثرات =====
  function tone(type, f0, f1, dur, v, delayT = 0) {
    const t = ctx.currentTime + delayT, o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(sfxBus); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, fr, v, type = 'bandpass', f1, delayT = 0) {
    const t = ctx.currentTime + delayT, n = ctx.createBufferSource(); n.buffer = noiseBuf;
    const fl = ctx.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(fr, t); if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    n.connect(fl).connect(g).connect(sfxBus); n.start(t, Math.random()); n.stop(t + dur + 0.02);
  }
  const SFX = {
    jump: () => { tone('square', 260, 520, 0.12, 0.08); noise(0.1, 1200, 0.05); },
    djump: () => { tone('triangle', 400, 900, 0.15, 0.12); },
    land: () => noise(0.09, 400, 0.12, 'lowpass'),
    step: () => noise(0.04, 900, 0.025, 'bandpass'),
    drop: () => { const b = 880 + Math.random() * 60; tone('sine', b, b * 1.5, 0.1, 0.15); tone('sine', b * 1.5, b * 2, 0.12, 0.1, 0.06); },
    heart: () => { [523, 659, 784, 1046].forEach((fr, i) => tone('triangle', fr, 0, 0.18, 0.12, i * 0.07)); },
    hurt: () => { tone('sawtooth', 300, 90, 0.3, 0.16); noise(0.2, 800, 0.1); },
    stomp: () => { tone('square', 180, 60, 0.15, 0.16); noise(0.12, 600, 0.15, 'lowpass'); },
    dash: () => { noise(0.28, 400, 0.22, 'bandpass', 3000); tone('sine', 200, 600, 0.2, 0.06); },
    spring: () => { tone('triangle', 200, 900, 0.25, 0.14); },
    checkpoint: () => { [587, 740, 880, 1175].forEach((fr, i) => tone('triangle', fr, 0, 0.35, 0.1, i * 0.09)); },
    gate: () => { [294, 370, 440, 587, 740].forEach((fr, i) => tone('sine', fr, 0, 0.6, 0.12, i * 0.12)); noise(1.2, 300, 0.1, 'lowpass', 2000); },
    crumble: () => noise(0.35, 300, 0.18, 'lowpass', 100),
    bosshit: () => { tone('sawtooth', 120, 40, 0.6, 0.25); noise(0.6, 900, 0.25, 'lowpass', 100); },
    roar: () => { noise(1.4, 200, 0.35, 'lowpass', 900); tone('sawtooth', 70, 45, 1.3, 0.2); },
    throw: () => noise(0.25, 1500, 0.1, 'bandpass', 400),
    rumble: () => noise(0.8, 120, 0.3, 'lowpass', 60),
    erupt: () => { noise(0.5, 2000, 0.2, 'bandpass', 300); },
    click: () => tone('triangle', 660, 880, 0.06, 0.08),
    hover: () => tone('sine', 1200, 0, 0.04, 0.03),
    tablet: () => { [440, 554, 659].forEach((fr, i) => qanunSfx(fr, i * 0.06)); },
    bossdie: () => { noise(2.5, 3000, 0.4, 'lowpass', 60); tone('sawtooth', 200, 30, 2.2, 0.22); },
    slash: () => { noise(0.12, 2600, 0.16, 'bandpass', 900); tone('triangle', 900, 300, 0.08, 0.05); },
    hit: () => { tone('square', 220, 80, 0.1, 0.16); noise(0.08, 1800, 0.18, 'highpass'); tone('sine', 1400, 900, 0.08, 0.06); },
    clink: () => { tone('triangle', 1800, 1500, 0.1, 0.1); noise(0.05, 4000, 0.08, 'highpass'); },
    pogo: () => { tone('triangle', 500, 1100, 0.12, 0.1); },
    coin: () => { const b = 1500 + Math.random() * 300; tone('sine', b, 0, 0.08, 0.07); tone('sine', b * 1.33, 0, 0.1, 0.05, 0.04); },
    healc: () => { tone('sine', 300, 700, 0.9, 0.06); noise(0.9, 800, 0.04, 'bandpass', 2500); },
    heal: () => { [660, 880, 1320].forEach((fr, i) => tone('sine', fr, 0, 0.4, 0.1, i * 0.05)); },
    wjump: () => { noise(0.08, 1200, 0.1); tone('square', 300, 600, 0.1, 0.06); },
    bosstitle: () => { tone('sine', 55, 50, 3, 0.35); tone('sawtooth', 110, 100, 2.5, 0.06); noise(2.5, 200, 0.12, 'lowpass', 80); },
    death: () => { tone('sawtooth', 220, 40, 1.4, 0.2); noise(1.4, 600, 0.2, 'lowpass', 60); },
    bag: () => { [440, 660, 880, 1100].forEach((fr, i) => tone('triangle', fr, 0, 0.3, 0.1, i * 0.06)); },
    buy: () => { [880, 1175, 1568].forEach((fr, i) => tone('triangle', fr, 0, 0.35, 0.1, i * 0.08)); },
    deny: () => { tone('square', 200, 150, 0.2, 0.08); },
    page: () => { noise(0.25, 3000, 0.08, 'bandpass', 1500); [523, 659, 784].forEach((fr, i) => tone('sine', fr, 0, 0.6, 0.06, 0.1 + i * 0.1)); },
    fire: () => { noise(0.3, 900, 0.12, 'bandpass', 300); tone('sawtooth', 200, 90, 0.25, 0.05); },
    charge: () => { noise(0.5, 300, 0.2, 'lowpass', 1200); },
    gem: () => { [587, 740, 880, 1175, 1480, 1760].forEach((fr, i) => tone('sine', fr, 0, 0.8, 0.1, i * 0.1)); },
  };
  function qanunSfx(fr, d) { tone('triangle', fr, 0, 0.5, 0.12, d); tone('triangle', fr * 2, 0, 0.3, 0.05, d + 0.03); }
  function sfx(name) { if (!ctx || !SFX[name]) return; try { SFX[name](); } catch (e) {} }

  // ===== الرواية الصوتية =====
  function voice(src, onEnd) {
    stopVoice();
    if (!src) return;
    voiceEl = new window.Audio(src);
    voiceEl.volume = vol.voice;
    voiceEl.onended = () => { setDuck(false); onEnd && onEnd(); };
    voiceEl.onerror = () => { setDuck(false); };
    setDuck(true);
    voiceEl.play().catch(() => setDuck(false));
    return voiceEl;
  }
  function stopVoice() { if (voiceEl) { voiceEl.onended = null; voiceEl.pause(); voiceEl = null; } setDuck(false); }
  function voiceDuration() { return voiceEl && isFinite(voiceEl.duration) ? voiceEl.duration : 0; }

  function setVolume(kind, v) {
    vol[kind] = v;
    if (!ctx) return;
    if (kind === 'music') musicBus.gain.setTargetAtTime(v * duckLevel, ctx.currentTime, 0.05);
    if (kind === 'sfx') sfxBus.gain.setTargetAtTime(v, ctx.currentTime, 0.05);
    if (kind === 'voice' && voiceEl) voiceEl.volume = v;
  }
  function suspend(on) { if (!ctx) return; on ? ctx.suspend() : ctx.resume(); if (voiceEl) on ? voiceEl.pause() : voiceEl.play().catch(() => {}); }

  return { init, playMusic, stopMusic, sfx, voice, stopVoice, voiceDuration, setVolume, vol, wind, suspend, get ready() { return !!ctx; } };
})();

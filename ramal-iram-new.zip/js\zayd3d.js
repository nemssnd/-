// زيد ثلاثي الأبعاد: مجسّم مبنيّ بالكامل بالشيفرة، بهيكل مفاصل وحركات إجرائية، يُرسَم داخل اللعبة ثنائية الأبعاد
window.Zayd3D = (() => {
  'use strict';
  const api = { ok: false };
  if (!window.R3D || !R3D.ok) return api;
  const T = THREE;
  const VW = 180, VH = 180, CY = 62;
  const rig = R3D.rig(VW, VH, CY); const scene = rig.scene, cam = rig.cam;
  const M = {}; const mat = R3D.mat;
  const surface = (color, extra = {}) => new T.MeshStandardMaterial({ color, roughness: 0.72, metalness: 0, ...extra });
  M.skin = surface(0xa8683e, { roughness: 0.62 }); M.skin2 = surface(0x8e5532, { roughness: 0.7 });
  M.hair = surface(0x2a1a12, { roughness: 0.9 }); M.tunic = surface(0xf3e6c9, { roughness: 0.86 }); M.tunic2 = surface(0xe2cfa8, { roughness: 0.9 });
  M.sirwal = surface(0xd8c4a0, { roughness: 0.88 }); M.belt = surface(0x6b4424, { roughness: 0.78 }); M.sandal = surface(0x4a2c18, { roughness: 0.9 });
  M.scarf = surface(0xc7372f, { roughness: 0.82 }); M.scarf2 = surface(0x9e2620, { roughness: 0.82 });
  M.bag = surface(0x7d5230, { roughness: 0.86 }); M.bagTrim = surface(0x4a2c18, { roughness: 0.82 });
  M.gold = new T.MeshStandardMaterial({ color: 0xe8b75a, emissive: 0x3a2400, metalness: 0.7, roughness: 0.28 });
  M.metal = new T.MeshStandardMaterial({ color: 0xe9f0f4, metalness: 0.86, roughness: 0.2, emissive: 0x202830 });
  M.blade = M.metal;
  M.eyeW = new T.MeshBasicMaterial({ color: 0xfaf4ea }); M.eyeB = new T.MeshBasicMaterial({ color: 0x1a0f0a }); M.mouth = new T.MeshBasicMaterial({ color: 0x5a2618 });
  M.iris = new T.MeshBasicMaterial({ color: 0x5a3418 }); M.blush = new T.MeshBasicMaterial({ color: 0xd9775a, transparent: true, opacity: 0.45 });
  M.embroid = surface(0xc7372f, { roughness: 0.76 }); M.teal = surface(0x2f7f7a, { roughness: 0.72 });
  const add = R3D.add, G = R3D.G, limbGeo = R3D.limb, sph = R3D.sph;
  const root = rig.root;

  // ===== الهيكل =====
  const body = G(); root.add(body);           // للدوران والقفز
  const hips = G(); hips.position.y = 34; body.add(hips);
  const torso = G(); hips.add(torso);

  // الثوب (الجزء العلوي)
  const upper = new T.LatheGeometry([[0.1, 25], [5.6, 24.8], [8.6, 22.5], [9.2, 19], [8.4, 13], [7.1, 6], [7.8, 0], [8.8, -3]].reverse().map(p => new T.Vector2(p[0], p[1])), 20);
  const up = add(torso, upper, M.tunic, 0, 0, 0, 1.05); up.scale.set(1.12, 1.04, 0.84);
  // تطريز الصدر
  const emb = add(torso, new T.BoxGeometry(1.4, 12, 0.8), M.embroid, 0, 15.5, 6.9, 0); emb.rotation.x = -0.08;
  for (let i = 0; i < 3; i++) add(torso, sph(0.8, 6, 5), M.gold, 0, 19 - i * 3.6, 7.3, 0);
  // الحزام
  const belt = add(torso, new T.TorusGeometry(8.1, 1.4, 6, 20), M.belt, 0, 1.5, 0, 1.08); belt.rotation.x = Math.PI / 2; belt.scale.set(1.12, 0.82, 1);
  add(torso, new T.BoxGeometry(3.4, 3, 1.2), M.gold, 0, 1.5, 7.1, 0);
  add(torso, new T.BoxGeometry(1.3, 22, 0.7), M.tunic2, -6.2, 12, 7.1, 0).rotation.z = -0.08;
  add(torso, new T.BoxGeometry(1.3, 22, 0.7), M.tunic2, 6.2, 12, 7.1, 0).rotation.z = 0.08;
  for (const x of [-1, 1]) {
    const pouch = G(); pouch.position.set(x * 9.2, -1, 7.2); torso.add(pouch);
    add(pouch, new T.BoxGeometry(5.5, 7, 4.5), M.bagTrim, 0, -1, 0, 1.04);
    add(pouch, new T.BoxGeometry(4.8, 1.1, 4.8), M.gold, 0, 2.5, 0, 0);
  }
  const tassels = []; for (const tx of [-2.4, 2.4]) { const tg = G(); tg.position.set(tx, 0.4, 7.4); torso.add(tg); add(tg, limbGeo(7, 0.7, 0.7, 5), M.embroid, 0, 0, 0, 0); add(tg, sph(1.1, 6, 5), M.gold, 0, -7.4, 0, 0); tassels.push(tg); }
  // حمّالة الحقيبة
  const strap = add(torso, new T.BoxGeometry(1.8, 28, 1.2), M.belt, 0, 12, 7.2, 0); strap.rotation.z = 0.62;
  const strapB = add(torso, new T.BoxGeometry(1.8, 28, 1.2), M.belt, 0, 12, -6.9, 0); strapB.rotation.z = -0.62;
  // التنّورة (أسفل الثوب) مستقلة لتتمايل
  const skirtG = G(); hips.add(skirtG);
  const skirt = add(skirtG, new T.LatheGeometry([[8.2, -2], [9.2, -8], [10.6, -15], [11.6, -19], [11.2, -19.6]].reverse().map(p => new T.Vector2(p[0], p[1])), 18, 0, Math.PI * 2), M.tunic2, 0, 0, 0, 1.04);
  skirt.scale.set(1.08, 1, 0.86); skirt.material = M.tunic2;
  const hem = add(skirtG, new T.TorusGeometry(11.3, 0.7, 5, 22), M.embroid, 0, -18.6, 0, 0); hem.rotation.x = Math.PI / 2; hem.scale.set(1.08, 0.86, 1);
  // الحقيبة الجلدية على الورك
  const bag = G(); bag.position.set(9.6, -3, 1); hips.add(bag);
  add(bag, new T.BoxGeometry(3.2, 7.5, 7.5), M.bag, 0, 0, 0, 1.1);
  add(bag, new T.BoxGeometry(3.4, 3.2, 7.7), M.belt, 0, 2.6, 0, 0);
  add(bag, sph(0.9, 6, 5), M.gold, 1.8, 1.4, 0, 0);

  // الوشاح حول الرقبة
  const neckScarf = add(torso, new T.TorusGeometry(6.2, 2.9, 8, 18), M.scarf, 0, 23.6, 0, 1.06); neckScarf.rotation.x = Math.PI / 2 - 0.12;
  const knot = add(torso, sph(2.8, 10, 8), M.scarf2, -1.5, 22.4, -6.4, 1.08);
  const tail1 = add(torso, limbGeo(9, 2.4, 1.6, 7), M.scarf, -1.5, 22, -7, 1.08); tail1.rotation.x = 0.9;

  // الرأس
  const neck = G(); neck.position.y = 24.5; torso.add(neck);
  add(neck, limbGeo(4, 2.8, 2.8, 8), M.skin2, 0, 3, 0, 0);
  const head = G(); head.position.y = 3; neck.add(head);
  const faceGeo = new T.LatheGeometry([[6.4, 0], [8.8, 2], [10.2, 6], [10.5, 11], [9.7, 16], [8.1, 19.5], [5.2, 21]].map(p => new T.Vector2(p[0], p[1])), 22);
  const skull = add(head, faceGeo, M.skin, 0, -1, 0.4, 1.05); skull.scale.set(1.02, 1.02, 0.98);
  add(head, new T.SphereGeometry(4.2, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5), M.hair, 0, 16.2, -0.7, 1.04).scale.set(1.45, 0.7, 1.05);
  add(head, sph(1.9, 8, 6), M.blush, -5.6, 5.8, 8.2, 0).scale.set(1, 0.6, 0.3); add(head, sph(1.9, 8, 6), M.blush, 5.6, 5.8, 8.2, 0).scale.set(1, 0.6, 0.3);
  add(head, sph(2.3, 8, 6), M.skin, 10, 8.4, -0.5, 1.1); add(head, sph(2.3, 8, 6), M.skin, -10, 8.4, -0.5, 1.1); // الأذنان
  add(head, sph(1.5, 8, 6), M.skin2, 0, 7.2, 10.2, 0); // الأنف
  const eyes = G(); head.add(eyes);
  const mkEye = (x) => { const e = G(); e.position.set(x, 9.8, 9.0); eyes.add(e); const w = new T.Mesh(sph(2.4, 12, 10), M.eyeW); w.scale.set(0.95, 1.2, 0.45); e.add(w); const ir = new T.Mesh(sph(1.6, 10, 8), M.iris); ir.position.set(0.2, -0.2, 0.7); ir.scale.set(1, 1.1, 0.5); e.add(ir); const b = new T.Mesh(sph(1.0, 8, 6), M.eyeB); b.position.set(0.25, -0.2, 1.2); e.add(b); const s = new T.Mesh(sph(0.45, 5, 4), M.eyeW); s.position.set(0.8, 0.6, 1.6); e.add(s); const lid = new T.Mesh(new T.BoxGeometry(5, 0.8, 1), M.hair); lid.position.set(0, 2.7, 0.6); lid.rotation.z = x > 0 ? -0.1 : 0.1; e.add(lid); return e; };
  const eyeL = mkEye(-3.5), eyeR = mkEye(3.5);
  const browL = add(head, new T.BoxGeometry(3.4, 0.9, 0.8), M.hair, -3.8, 13.6, 9.2, 0); browL.rotation.z = 0.12;
  const browR = add(head, new T.BoxGeometry(3.4, 0.9, 0.8), M.hair, 3.8, 13.6, 9.2, 0); browR.rotation.z = -0.12;
  const mouth = add(head, new T.TorusGeometry(1.6, 0.35, 4, 10, Math.PI), M.mouth, 0, 4.4, 9.8, 0); mouth.rotation.z = Math.PI;
  // الشعر المجعّد
  const hair = G(); head.add(hair);
  const hairPts = [[0, 17, 0, 4.4], [-4.5, 16.2, 2.4, 3.8], [4.5, 16.2, 2.4, 3.8], [0, 16, 5, 3.6], [-6.8, 14.6, -1.5, 3.8], [6.8, 14.6, -1.5, 3.8], [-3, 16.4, -4, 4], [3, 16.4, -4, 4], [0, 14.5, -7, 4.2], [-7.5, 11.2, -4.6, 3.4], [7.5, 11.2, -4.6, 3.4], [-4.8, 11, -7.8, 3.6], [4.8, 11, -7.8, 3.6], [0, 9.5, -9, 3.6], [-8.6, 10.5, 0.5, 2.6], [8.6, 10.5, 0.5, 2.6], [-2.4, 15.2, 6.4, 2.8], [2.6, 15.4, 6.2, 2.6]];
  for (const [x, y, z, r] of hairPts) add(hair, sph(r * 1.08, 10, 8), M.hair, x * 1.1, y * 1.06 + 0.6, z * 1.1, 1.08);
  // عصابة الرأس الزرقاء مع طرفين يتطايران
  const band = add(head, new T.TorusGeometry(11.2, 1.25, 6, 26), M.teal, 0, 15.2, -0.8, 1.12); band.rotation.x = Math.PI / 2 + 0.34; band.scale.set(1.02, 1.02, 0.9);
  const bandTails = [];
  for (const sx of [-1, 1]) { const tg = G(); tg.position.set(sx * 1.6, 11.4, -11.4); head.add(tg); const m = add(tg, new T.BoxGeometry(2.2, 9, 0.8), M.teal, 0, -4.5, 0, 1.1); tg.rotation.z = sx * 0.25; bandTails.push(tg); }
  add(head, sph(1.8, 8, 6), M.gold, 0, 12.6, -11.6, 1.1);

  // الذراعان
  const handGeo = new T.LatheGeometry([[1.3, -5], [2.4, -3], [3, 0], [2.6, 3], [1.7, 5]].map(p => new T.Vector2(p[0], p[1])), 12);
  const mkArm = (side) => {
    const sh = G(); sh.position.set(side * 9.4, 20.5, 0); torso.add(sh);
    add(sh, sph(3.4, 10, 8), M.tunic, 0, 0, 0, 1.07);
    add(sh, limbGeo(11, 3.1, 3.6, 10), M.tunic, 0, 0, 0, 1.06); // كمّ واسع
    const cuff = add(sh, new T.TorusGeometry(3.4, 0.7, 5, 14), M.embroid, 0, -10.6, 0, 0); cuff.rotation.x = Math.PI / 2;
    const el = G(); el.position.y = -11; sh.add(el);
    add(el, sph(2.3, 8, 6), M.skin, 0, 0, 0, 0);
    add(el, limbGeo(9.5, 2.3, 1.9, 8), M.skin, 0, 0, 0, 1.08);
    const hand = G(); hand.position.y = -10; el.add(hand);
    add(hand, handGeo, M.skin, 0, 0, 0.3, 1.08).scale.set(1.05, 1.15, 0.9);
    add(hand, new T.TorusGeometry(2.5, 0.35, 5, 12), M.gold, 0, 0.4, 0.8, 0).rotation.x = Math.PI / 2;
    return { sh, el, hand };
  };
  const armW = mkArm(-1), armF = mkArm(1); // armW يحمل الجنبية (الأقرب إلى الكاميرا)
  // الجنبية
  const jan = G(); armW.hand.add(jan); jan.position.set(0, -0.5, 1.2);
  add(jan, limbGeo(5, 1.2, 1.2, 8), M.belt, 0, 2.5, 0, 1.12);
  add(jan, new T.BoxGeometry(6, 1.3, 1.6), M.gold, 0, -2.6, 0, 1.1);
  add(jan, sph(1.4, 8, 6), M.gold, 0, 3.4, 0, 0);
  add(jan, new T.TorusGeometry(3.2, 0.65, 6, 18), M.metal, 0, 0.2, 0, 0).rotation.x = Math.PI / 2;
  const bladeShape = new T.Shape(); bladeShape.moveTo(-1.5, 0); bladeShape.quadraticCurveTo(-2.2, -9, 3.5, -17); bladeShape.quadraticCurveTo(1.6, -9, 1.5, 0); bladeShape.lineTo(-1.5, 0);
  const bladeGeo = new T.ExtrudeGeometry(bladeShape, { depth: 0.7, bevelEnabled: true, bevelThickness: 0.3, bevelSize: 0.3, bevelSegments: 1, curveSegments: 10 }); bladeGeo.translate(0, -3, -0.35);
  const blade = add(jan, bladeGeo, M.blade, 0, 0, 0, 1.06); blade.rotation.y = Math.PI / 2; blade.scale.set(1.12, 1.08, 1.08);
  const guard = add(jan, new T.TorusGeometry(3.2, 0.75, 6, 18), M.gold, 0, -1.2, 0, 0); guard.rotation.x = Math.PI / 2;
  const bladeGlow = new T.Mesh(bladeGeo, new T.MeshBasicMaterial({ color: 0xfff4d8, transparent: true, opacity: 0 })); blade.add(bladeGlow);

  // الساقان
  const mkLeg = (side) => {
    const hp = G(); hp.position.set(side * 4.2, 0, 0); hips.add(hp);
    add(hp, limbGeo(15, 4.0, 3.2, 10), M.sirwal, 0, 0, 0, 1.05);
    const kn = G(); kn.position.y = -15; hp.add(kn);
    add(kn, sph(2.9, 8, 6), M.sirwal, 0, 0, 0, 0);
    add(kn, limbGeo(14, 2.9, 2.3, 8), M.sirwal, 0, 0, 0, 1.06);
    add(kn, limbGeo(2, 2.4, 2.4, 8), M.skin, 0, -12.5, 0, 0);
    const an = G(); an.position.y = -14.5; kn.add(an);
    add(an, new T.BoxGeometry(4.6, 2.2, 8.2), M.sandal, 0, -2.2, 2, 1.1);
    add(an, sph(2.2, 8, 6), M.skin, 0, -0.4, 1.8, 0);
    add(an, new T.BoxGeometry(5.2, 0.9, 1.1), M.belt, 0, -1.5, 5.2, 0).rotation.x = -0.12;
    add(an, new T.BoxGeometry(5.2, 0.9, 1.1), M.gold, 0, -3.1, 4.5, 0).rotation.x = -0.12;
    add(an, new T.BoxGeometry(4.8, 0.8, 1), M.belt, 0, 0, 3.4, 0);
    return { hp, kn, an };
  };
  const legW = mkLeg(-1), legF = mkLeg(1);

  // ===== الحركة =====
  const J = [body, hips, torso, skirtG, neck, head, armW.sh, armW.el, armW.hand, armF.sh, armF.el, armF.hand, legW.hp, legW.kn, legW.an, legF.hp, legF.kn, legF.an, jan];
  const cur = J.map(() => ({ x: 0, y: 0, z: 0 })); const tgt = J.map(() => ({ x: 0, y: 0, z: 0 }));
  const idx = new Map(J.map((o, i) => [o, i]));
  const set = (o, x = 0, y = 0, z = 0) => { const t = tgt[idx.get(o)]; t.x = x; t.y = y; t.z = z; };
  let bodyY = 0, bodyYT = 0, turn = 0.95, flipT = 0, lastJumps = 0, blinkT = 2, lastT = performance.now(), lastFace = 1, wasHurt = false, hurtT = 0, landT = 0, wasGround = true;
  const ease = (k) => 1 - Math.pow(1 - k, 3);

  function pose(p, dt, time) {
    for (const t of tgt) { t.x = t.y = t.z = 0; }
    bodyYT = 0;
    const speed = Math.abs(p.vx), running = p.ground && speed > 40, ph = p.run;
    const air = !p.ground, rising = p.vy < -60;
    const atk = p.slashFx > 0, atkSpan = p.atkKind === 'heavy' ? 0.22 : p.atkKind === 'dash' ? 0.16 : 0.14;
    const ak = atk ? ease(Math.max(0, Math.min(1, 1 - p.slashFx / atkSpan))) : 0;
    // الحالة الأساسية
    if (p.dead) {
      set(body, -1.35 * Math.min(1, p.deadT * 2.5), 0, 0); bodyYT = -6;
      set(armW.sh, -2.4, 0, 0.4); set(armF.sh, -2.2, 0, -0.4); set(legW.hp, -0.3); set(legF.hp, 0.2); set(legW.kn, 0.6); set(head, 0.3);
    } else if (p.victoryT > 0) {
      const k = Math.sin(time * 5) * 0.04;
      bodyYT = -2 + Math.sin(time * 3) * 1.2; set(torso, -0.12 + k); set(head, -0.2, Math.sin(time * 1.5) * 0.12);
      set(armW.sh, -2.35, 0, -0.25); set(armW.el, -0.55); set(armF.sh, -2.55, 0, 0.3); set(armF.el, -0.45);
      set(legW.hp, -0.12); set(legF.hp, 0.12); set(jan, -0.25); set(skirtG, 0.18);
    } else if (p.healT > 0) {
      bodyYT = -9; const k = Math.sin(time * 18) * 0.03;
      set(legW.hp, -1.5); set(legW.kn, 2.3); set(legW.an, -0.7); set(legF.hp, 0.25); set(legF.kn, 2.4); set(legF.an, 0.5);
      set(torso, 0.35 + k); set(head, 0.35); set(armW.sh, -0.9, 0, -0.35); set(armW.el, -1.2); set(armF.sh, -0.9, 0, 0.35); set(armF.el, -1.2); set(jan, 0, 0, 0);
      set(skirtG, -0.35);
    } else if (p.dashT > 0) {
      set(body, 0.5); bodyYT = 3; set(torso, 0.25); set(head, -0.35);
      set(armW.sh, 1.4, 0, 0.3); set(armW.el, -0.3); set(armF.sh, 1.3, 0, -0.3); set(armF.el, -0.3);
      set(legW.hp, -0.9); set(legW.kn, 1.3); set(legF.hp, 0.9); set(legF.kn, 0.9); set(skirtG, 0.5);
    } else if (p.wall) {
      set(torso, -0.15); set(head, -0.15, 0, 0); bodyYT = 0;
      set(armF.sh, 0.4, 0, 1.6); set(armF.el, -0.5); set(armW.sh, 0.2, 0, -0.5); set(armW.el, -0.9);
      set(legW.hp, -1.0); set(legW.kn, 1.5); set(legF.hp, 0.3); set(legF.kn, 0.7); set(skirtG, -0.2);
    } else if (air) {
      if (rising) {
        set(torso, -0.08); set(head, -0.15);
        set(legW.hp, -1.3); set(legW.kn, 1.7); set(legF.hp, -0.1); set(legF.kn, 0.9); set(legF.an, 0.5);
        set(armW.sh, -2.6, 0, -0.2); set(armW.el, -0.4); set(armF.sh, 0.8, 0, 0.3); set(armF.el, -0.6); set(skirtG, -0.3);
      } else {
        const f = Math.min(1, p.vy / 700);
        set(torso, 0.1); set(head, 0.2 * f);
        set(legW.hp, -0.6); set(legW.kn, 0.8); set(legF.hp, 0.25); set(legF.kn, 0.4 + f * 0.3);
        set(armW.sh, -1.2, 0, -0.7 - f * 0.4); set(armW.el, -0.4); set(armF.sh, -1.0, 0, 0.7 + f * 0.4); set(armF.el, -0.4); set(skirtG, 0.25 * f);
      }
    } else if (running) {
      const s = Math.sin(ph), c = Math.cos(ph), sp = Math.min(1, speed / 330);
      bodyYT = Math.abs(Math.sin(ph)) * 2.6 * sp - 1;
      set(torso, 0.22 * sp, s * 0.18, 0); set(head, -0.15 * sp, -s * 0.12); set(hips, 0, -s * 0.15);
      set(legW.hp, -s * 1.0 * sp); set(legF.hp, s * 1.0 * sp);
      set(legW.kn, 0.25 + Math.max(0, c) * 1.5 * sp); set(legF.kn, 0.25 + Math.max(0, -c) * 1.5 * sp);
      set(legW.an, -s * 0.3); set(legF.an, s * 0.3);
      set(armW.sh, s * 0.95 * sp, 0, -0.12); set(armW.el, -0.9); set(armF.sh, -s * 0.95 * sp, 0, 0.12); set(armF.el, -0.9);
      set(skirtG, 0.15 * sp, 0, s * 0.06);
    } else {
      // وقوف: تنفّس ونظرة
      const br = Math.sin(time * 2.2);
      bodyYT = br * 0.4; set(torso, 0.02 + br * 0.015); set(head, -0.05 + br * 0.02, Math.sin(time * 0.6) * 0.25);
      set(armW.sh, 0.12, 0, -0.18 - br * 0.02); set(armW.el, -0.35); set(armF.sh, 0.05, 0, 0.16 + br * 0.02); set(armF.el, -0.25);
      set(legW.hp, -0.12, 0, -0.04); set(legW.kn, 0.2); set(legF.hp, 0.12, 0, 0.05); set(legF.kn, 0.08);
      set(jan, 0.2);
    }
    // الضربات (تتراكب فوق أي حالة)
    if (atk) {
      if (p.atkDir === 'u') {
        set(armW.sh, lerp(-0.4, -3.2, ak), 0, -0.2); set(armW.el, -0.1); set(torso, -0.25); set(head, -0.5); set(jan, 0, 0, 0);
      } else if (p.atkDir === 'd') {
        set(armW.sh, lerp(-2.8, -0.3, ak), 0, -0.1); set(armW.el, -0.1); set(torso, 0.55); set(head, 0.5);
        set(legW.hp, -1.4); set(legW.kn, 1.9); set(legF.hp, -1.2); set(legF.kn, 1.8);
      } else if (p.atkKind === 'heavy') {
        const wind = Math.min(1, ak / 0.42), drive = Math.max(0, (ak - 0.32) / 0.68);
        set(armW.sh, lerp(1.1, -2.8, drive), 0, lerp(-1.4, 0.8, drive)); set(armW.el, lerp(1.15, -0.2, drive));
        set(armF.sh, lerp(1.5, 0.55, drive), 0, -0.5); set(armF.el, -0.4);
        set(torso, lerp(-0.48, 0.42, drive), 0, 0); set(head, lerp(-0.35, 0.25, drive)); set(legW.hp, -0.35 * wind); set(legF.hp, 0.18 * wind); set(jan, 0, 0, 0);
      } else if (p.atkKind === 'dash') {
        set(body, 0.7); set(torso, 0.35); set(head, -0.45); set(armW.sh, -1.5, 0, 0.7); set(armW.el, -0.2); set(armF.sh, -1.1, 0, -0.65); set(armF.el, -0.3); set(legW.hp, -0.65); set(legF.hp, 0.7);
      } else {
        const stage = p.combo || 1, alt = p.slashAlt ? 1 : -1;
        const sweep = stage === 1 ? -0.8 : stage === 2 ? 0.95 : stage === 3 ? -1.25 : 1.45;
        set(armW.sh, lerp(-2.4, -1.05, ak), 0, lerp(sweep, -sweep * 0.65, ak) - 0.2); set(armW.el, stage === 4 ? -0.45 : -0.15);
        set(torso, stage === 4 ? lerp(-0.28, 0.62, ak) : lerp(0.18, 0.42 * alt, ak), lerp(-0.5 * alt, 0.45 * alt, ak)); set(head, stage === 4 ? -0.18 : 0, -0.25 * alt);
        set(armF.sh, stage === 4 ? 1.05 : 0.7, 0, 0.5 * alt);
      }
    }
    // الأذى
    if (p.inv > 1.05 && !p.dead) { set(torso, -0.45); set(head, -0.4); set(armW.sh, -1.2, 0, -1.2); set(armF.sh, -1.2, 0, 1.2); }
    // وجه
    blinkT -= dt; const blink = blinkT < 0.12; if (blinkT < 0) blinkT = 2 + Math.random() * 3;
    const hurtFace = p.inv > 1.0 || p.dead, lowHp = p.hp === 1 && !p.dead, counter = p.counterT > 0;
    eyeL.scale.y = eyeR.scale.y = blink || p.healT > 0 ? 0.12 : hurtFace ? 0.5 : lowHp ? 0.78 : 1;
    browL.rotation.z = hurtFace ? -0.35 : counter ? 0.28 : atk ? -0.3 : lowHp ? -0.18 : 0.12; browR.rotation.z = -browL.rotation.z;
    mouth.scale.set(atk || hurtFace ? 1.2 : counter ? 1.05 : 0.9, atk || hurtFace ? -1.2 : counter ? -0.75 : lowHp ? 1.05 : 0.8, 1);
    bladeGlow.material.opacity = atk ? (1 - ak) * 0.9 : 0;
  }

  function apply(dt, snap) {
    const k = snap ? 1 : Math.min(1, dt * 22);
    for (let i = 0; i < J.length; i++) {
      const c = cur[i], t = tgt[i];
      c.x += (t.x - c.x) * k; c.y += (t.y - c.y) * k; c.z += (t.z - c.z) * k;
      J[i].rotation.set(c.x, c.y, c.z);
    }
  }
  const lerp = (a, b, t) => a + (b - a) * t;

  function draw(ctx, p, x, feetY, scale, alpha = 1) {
    const now = performance.now(), dt = Math.min(0.05, (now - lastT) / 1000); lastT = now; const time = now / 1000;
    pose(p, dt, time);
    // القفزة المزدوجة: شقلبة
    if (p.jumps === 2 && lastJumps !== 2) flipT = 0.001;
    lastJumps = p.jumps;
    if (p.ground && !wasGround) landT = 0.12; wasGround = p.ground;
    apply(dt, false);
    if (flipT > 0) { flipT += dt; const k = Math.min(1, flipT / 0.34); body.rotation.x = ease(k) * Math.PI * 2; if (k >= 1 || p.ground) flipT = 0; }
    bodyY += (bodyYT - bodyY) * Math.min(1, dt * 18); body.position.y = bodyY + (flipT > 0 ? 14 : 0);
    if (flipT > 0) { hips.position.y = 34 - 14; } else hips.position.y = 34;
    // الاتجاه (استدارة ناعمة، مع مرآة للجهة اليسرى)
    const face = p.face >= 0 ? 1 : -1;
    const wantTurn = (p.dashT > 0 ? 1.35 : p.wall ? 1.1 : p.healT > 0 ? 0.5 : Math.abs(p.vx) > 40 || p.slashFx > 0 ? 1.05 : 0.7);
    if (face !== lastFace) { turn = -turn; lastFace = face; }
    turn += (wantTurn - turn) * Math.min(1, dt * 14);
    root.scale.x = face; root.rotation.y = turn * face;
    // انضغاط/تمدّد
    const sq = p.sq || 1, K = 1.12; root.scale.y = sq * K; root.scale.z = K; root.scale.x = face * (2 - sq) * K;
    // الوشاح والأهداب تتطاير مع السرعة
    const wind = Math.min(1, Math.abs(p.vx) / 330 + Math.max(0, -p.vy) / 900);
    tail1.rotation.x = 0.9 + wind * 0.9 + Math.sin(time * 9) * 0.12 * (0.3 + wind);
    for (const tg of tassels) tg.rotation.x = wind * 0.9 + Math.sin(time * 7 + tg.position.x) * 0.1;
    bandTails.forEach((tg, i) => { tg.rotation.x = -0.3 - wind * 1.1 - Math.sin(time * 10 + i) * 0.15 * (0.3 + wind); });
    R3D.key = p; R3D.draw(ctx, rig, x, feetY, scale, { alpha });
  }

  // صورة ثابتة للقوائم
  function portrait(canvas, t = performance.now() / 1000) {
    const fake = { vx: 0, vy: 0, ground: true, run: 0, face: 1, slashFx: 0, inv: 0, dashT: 0, wall: 0, healT: 0, jumps: 0, sq: 1, dead: false };
    pose(fake, 0.016, t); apply(0, true); body.position.y = 0; root.scale.set(1, 1, 1); root.rotation.y = 0.55 + Math.sin(t * 0.8) * 0.35;
    cam.zoom = 1.85; cam.position.y = 40; cam.lookAt(0, 40, 0); cam.updateProjectionMatrix();
    R3D.toCanvas(rig, canvas);
    cam.zoom = 1; cam.position.y = CY; cam.lookAt(0, CY, 0); cam.updateProjectionMatrix();
  }

  api.ok = true; api.draw = draw; api.portrait = portrait; api.CY = CY;
  return api;
})();

// الوحوش والزعماء بمجسّمات ثلاثية الأبعاد، كلّها مبنية بالشيفرة وحركاتها إجرائية
window.M3D = (() => {
  'use strict';
  const api = { ok: false };
  if (!window.R3D || !R3D.ok) return api;
  const T = THREE, { add, G, limb, sph, cone, mat, glowMat } = R3D;
  const S = Math.sin, C = Math.cos, PI = Math.PI;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const surface = (color, extra = {}) => new T.MeshStandardMaterial({ color, roughness: 0.68, metalness: 0.04, ...extra });

  // ===== عقرب (يُستخدم أيضاً للصغار والملكة) =====
  function makeScorpion(o) {
    const rig = R3D.rig(o.VW, o.VH, o.CY); const r = rig.root;
    const m1 = surface(o.c1, { roughness: 0.52 }), m2 = surface(o.c2, { roughness: 0.62 }), m3 = surface(o.c3, { emissive: o.e3 || 0x000000, roughness: 0.46 }), eye = glowMat(o.eye);
    const body = G(); body.position.y = 11; r.add(body);
    const th = add(body, sph(12, 16, 12), m1); th.scale.set(1.82, 0.72, 1.12);
    const plates = [];
    for (let i = 0; i < 4; i++) {
      const p = add(body, sph(10 - i, 14, 10), i % 2 ? m2 : m1, -14 - i * 8, 1 + i * 0.5, 0); p.scale.set(0.9, 0.62, 1); plates.push(p);
      const ridge = add(body, new T.TorusGeometry(8.5 - i * 0.8, 0.9, 5, 14), i % 2 ? m1 : m2, -14 - i * 8, 1 + i * 0.5, 0, 0); ridge.rotation.z = PI / 2; ridge.scale.set(0.9, 0.7, 1);
    }
    const head = add(body, sph(8, 14, 10), m2, 19, 1, 0); head.scale.set(1.3, 0.72, 1.2);
    for (const z of [-3, 3]) add(head, sph(1.6, 6, 5), eye, 5, 4, z, 0);
    if (o.crown) {
      const royal = mat(0xe8b75a, { emissive: 0x4a3000 });
      add(body, new T.TorusGeometry(15, 2.2, 7, 20), royal, -2, 8, 0, 0).rotation.z = PI / 2;
      for (const z of [-1, 1]) { const pauldron = add(body, sph(11, 12, 10), royal, 10, 9, z * 11, 1.05); pauldron.scale.set(1.25, 0.55, 1.15); }
      for (let i = -2; i <= 2; i++) { const c = add(body, cone(1.8, 7, 6), royal, 12 + Math.abs(i) * -1, 4.5, i * 3, 1.1); c.rotation.x = i * 0.25; }
    }
    // الكلّابات
    const claws = [];
    for (const z of [-9, 9]) {
      const a = G(); a.position.set(20, 0, z); body.add(a);
      const up = add(a, limb(12, 2.4, 2.8, 8), m1); up.rotation.z = -1.9;
      const fa = G(); fa.position.set(11, 4, 0); a.add(fa);
      add(fa, limb(10, 2.6, 3.4, 8), m2).rotation.z = -1.3;
      const cl = G(); cl.position.set(10, 6, 0); fa.add(cl);
      const big = add(cl, sph(5, 10, 8), m1); big.scale.set(1.85, 1.05, 1.05);
      const f1 = G(); f1.position.set(5, 1.5, 0); cl.add(f1); const j1 = add(f1, cone(2.2, 9, 6), m3); j1.rotation.z = -1.35;
      const f2 = G(); f2.position.set(5, -1.5, 0); cl.add(f2); const j2 = add(f2, cone(1.8, 8, 6), m3); j2.rotation.z = -1.8;
      claws.push({ a, fa, f1, f2 });
    }
    // الأرجل
    const legs = [];
    for (let i = 0; i < 3; i++) for (const s of [-1, 1]) {
      const l = G(); l.position.set(8 - i * 9, -1, s * 8); body.add(l);
      const th2 = G(); l.add(th2); add(th2, limb(10, 2.1, 1.7, 6), m2).rotation.x = s * 2.0;
      const kn = G(); kn.position.set(0, 4, s * 7.5); th2.add(kn); add(kn, limb(13, 1.5, 0.9, 6), m1).rotation.x = s * -0.35;
      legs.push({ l, th2, kn, i, s });
    }
    // الذيل
    const tail = []; let prev = body; let px = -44, py = 3;
    for (let i = 0; i < 6; i++) {
      const g = G(); g.position.set(i === 0 ? px : -8.5, i === 0 ? py : 0, 0); prev.add(g);
      const seg = add(g, sph(6.5 - i * 0.55, 12, 9), i % 2 ? m1 : m2); seg.scale.set(1.32, 1.02, 1.02);
      tail.push(g); prev = g;
    }
    const sting = G(); sting.position.set(-8, 0, 0); prev.add(sting);
    add(sting, sph(4.2, 10, 8), m3).scale.set(1.2, 1, 1);
    const st = add(sting, cone(2, 9, 6), m3); st.position.x = -2; st.rotation.z = 2.2;
    const tip = add(sting, sph(1.2, 6, 5), glowMat(o.tip), -8, -4, 0, 0);
    add(sting, cone(2.8, 8, 6), m3, -10, -4, 0, 0).rotation.z = -PI / 2;
    r.rotation.x = 0.28; r.rotation.y = -0.35;
    const k = o.scale || 1; r.scale.setScalar(k);
    function pose(t, walk, st2) {
      st2 = st2 || {};
      const ws = walk ? t * 14 : 0;
      for (const L of legs) { const ph = ws + L.i * 2.1 + (L.s > 0 ? PI : 0); L.l.rotation.y = walk ? S(ph) * 0.35 : 0; L.th2.rotation.z = walk ? Math.max(0, C(ph)) * 0.3 : 0; }
      body.position.y = 11 + (walk ? Math.abs(S(ws)) * 1.2 : S(t * 2) * 0.4) + (st2.lift || 0);
      body.rotation.z = st2.rear || 0;
      const curl = st2.strike ? 0.1 : 0.68 + S(t * 2.3) * 0.06;
      tail.forEach((g, i) => { g.rotation.z = -(i === 0 ? 1.25 : curl) - (st2.strike ? (i > 2 ? -0.35 : 0.35) : 0); });
      claws.forEach((c, i) => {
        const snap = st2.snap ? Math.abs(S(t * 18 + i)) * 0.6 : Math.abs(S(t * 3 + i * 1.3)) * 0.25;
        c.f1.rotation.z = snap; c.f2.rotation.z = -snap;
        c.a.rotation.z = (st2.reach || 0) + S(t * 2 + i) * 0.05; c.a.rotation.y = (i ? -1 : 1) * (st2.spread || 0.25);
      });
    }
    return { rig, pose };
  }

  // ===== خفّاش =====
  function makeBat() {
    const rig = R3D.rig(130, 100, 0); const r = rig.root;
    const fur = surface(0x5a3a6a, { roughness: 0.82 }), dark = surface(0x3a2448, { roughness: 0.9 }), mem = surface(0x7a4f86, { side: T.DoubleSide, transparent: true, opacity: 0.88, roughness: 0.76 }), eye = glowMat(0xff5a3a);
    const body = add(r, sph(8, 14, 10), fur); body.scale.set(1.12, 1.28, 1.02);
    const head = add(r, sph(6.5, 14, 10), fur, 0, 11, 2); head.scale.set(1.08, 1.08, 1.05);
    for (const x of [-1, 1]) { const e = add(head, cone(2.6, 8, 6), dark, x * 3.4, 4, 0); e.rotation.z = -x * 0.35; add(head, sph(1.3, 6, 5), eye, x * 2.3, 1, 5.6, 0); add(head, cone(0.6, 2.4, 4), glowMat(0xffffff), x * 1.4, -3, 5.4, 0).rotation.x = PI; }
    for (const x of [-1, 1]) add(head, cone(0.8, 4.5, 5), mat(0xf0e4d0), x * 2.4, -4, 5.8, 0).rotation.x = PI;
    add(r, new T.TorusGeometry(7.2, 1.1, 6, 14), dark, 0, 4, 0, 0).rotation.x = PI / 2;
    const wings = [];
    for (const x of [-1, 1]) {
      const w = G(); w.position.set(x * 6, 4, 0); r.add(w); w.scale.set(1.08, 1.12, 1);
      const sh = new T.Shape(); sh.moveTo(0, 0); sh.lineTo(x * 16, 10); sh.lineTo(x * 34, 6); sh.lineTo(x * 44, -4); sh.quadraticCurveTo(x * 36, -2, x * 32, -10); sh.quadraticCurveTo(x * 24, -4, x * 20, -12); sh.quadraticCurveTo(x * 12, -4, x * 6, -10); sh.lineTo(0, -4);
      const m = add(w, new T.ShapeGeometry(sh), mem, 0, 0, 0, 0);
      add(w, limb(34, 1, 0.6, 5), dark, 0, 0, 0.3, 0).rotation.z = x * 1.35;
      wings.push({ w, x });
    }
    for (const x of [-1, 1]) add(r, limb(5, 1, 0.6, 5), dark, x * 3, -8, 0, 0);
    r.rotation.x = 0.15;
    function pose(t, dir, dive) {
      const f = S(t * 16); wings.forEach(W => { W.w.rotation.z = W.x * (dive ? -0.9 : f * 0.75); W.w.rotation.y = W.x * 0.35; });
      r.rotation.y = dir * 0.5; r.rotation.z = dive ? -dir * 0.5 : S(t * 3) * 0.08; r.position.y = dive ? 0 : f * 2;
    }
    return { rig, pose };
  }

  // ===== روح الرمال =====
  function makeSpirit() {
    const rig = R3D.rig(160, 180, 0); const r = rig.root; r.scale.setScalar(1.3);
    const bodyM = mat(0xf0b35a, { emissive: 0x6a3a08, transparent: true, opacity: 0.88 });
    const coreM = glowMat(0xffe7a0, 0.7), eye = glowMat(0xfff4d0);
    const pts = [[0, -34], [3, -26], [6, -16], [11, -4], [14, 8], [12.5, 18], [8, 24], [0, 26]].map(p => new T.Vector2(p[0], p[1]));
    const b = add(r, new T.LatheGeometry(pts, 18), bodyM, 0, 0, 0, 1.05);
    const core = add(r, sph(7, 12, 10), coreM, 0, 8, 2, 0);
    const face = G(); face.position.set(0, 12, 11); r.add(face);
    for (const x of [-1, 1]) { const e = add(face, sph(2.2, 8, 6), eye, x * 4, 0, 0, 0); e.scale.set(0.8, 1.3, 0.4); }
    const mouth = add(face, sph(2, 8, 6), glowMat(0x3a1a08), 0, -6, 0, 0); mouth.scale.set(1.2, 0.7, 0.4);
    const arms = [];
    for (const x of [-1, 1]) { const a = G(); a.position.set(x * 12, 8, 0); r.add(a); const c = add(a, cone(3, 16, 8), bodyM); c.rotation.z = x * 2.2; arms.push({ a, x }); }
    const rings = []; for (let i = 0; i < 3; i++) { const t = add(r, new T.TorusGeometry(9 - i * 2.5, 0.8, 5, 18), glowMat(0xffd27a, 0.55), 0, -8 - i * 8, 0, 0); t.rotation.x = PI / 2 - 0.3; rings.push(t); }
    function pose(t, dir) {
      b.rotation.y = t * 0.6; b.scale.set(1 + S(t * 4) * 0.04, 1 + C(t * 3) * 0.05, 1);
      rings.forEach((g, i) => { g.rotation.z = t * (2 + i); g.position.x = S(t * 3 + i) * 2; });
      arms.forEach(A => { A.a.rotation.z = S(t * 3 + A.x) * 0.3; });
      core.scale.setScalar(1 + S(t * 6) * 0.1); r.rotation.y = dir * 0.35; face.position.x = dir * 2;
    }
    return { rig, pose, mouth };
  }

  // ===== الغول =====
  function makeGhoul() {
    const rig = R3D.rig(190, 160, 40); const r = rig.root;
    const skin = surface(0x6d7a5e, { roughness: 0.76 }), skin2 = surface(0x4f5a44, { roughness: 0.82 }), cloth = surface(0x5a3a28, { roughness: 0.9 }), bone = surface(0xe8dcc0, { roughness: 0.72 }), eye = glowMat(0xff4a2a), nail = surface(0x2a2018, { roughness: 0.84 });
    const hips = G(); hips.position.y = 30; r.add(hips);
    const torso = G(); hips.add(torso); torso.rotation.z = -0.35;
    const chest = add(torso, sph(20, 18, 14), skin, 4, 20, 0); chest.scale.set(1.05, 1, 0.85);
    add(torso, sph(14, 14, 10), skin2, -6, 30, 0).scale.set(1.2, 0.9, 0.9); // الحدبة
    const neck = G(); neck.position.set(18, 30, 0); torso.add(neck);
    const head = add(neck, sph(10, 16, 12), skin, 6, 0, 0); head.scale.set(1.15, 0.95, 1);
    const jaw = add(neck, sph(7, 12, 8), skin2, 10, -6, 0); jaw.scale.set(1.3, 0.6, 0.9);
    for (const z of [-4.5, 4.5]) { add(neck, sph(2.3, 8, 6), eye, 14, 3, z, 0); const h = add(neck, cone(2.6, 12, 6), bone, 2, 8, z * 1.3); h.rotation.z = -0.9; h.rotation.x = z > 0 ? -0.4 : 0.4; }
    for (const z of [-2.5, 2.5]) add(neck, cone(1, 4, 4), bone, 15, -6, z, 0).rotation.z = PI;
    add(hips, sph(14, 14, 10), cloth, 0, -2, 0).scale.set(1.1, 0.8, 0.9);
    const arms = [];
    for (const z of [-15, 15]) {
      const sh = G(); sh.position.set(14, 26, z); torso.add(sh);
      add(sh, sph(6, 10, 8), skin);
      add(sh, limb(22, 5, 4, 8), skin);
      const el = G(); el.position.y = -22; sh.add(el); add(el, limb(20, 4, 3.2, 8), skin2);
      const hd = G(); hd.position.y = -20; el.add(hd); add(hd, sph(4.5, 8, 6), skin);
      for (let i = -1; i <= 1; i++) { const c = add(hd, cone(1.1, 7, 4), nail, 2, -3, i * 2.2); c.rotation.z = PI - 0.4; }
      arms.push({ sh, el });
    }
    const legs = [];
    for (const z of [-8, 8]) {
      const hp = G(); hp.position.set(0, -2, z); hips.add(hp); add(hp, limb(15, 5.5, 4.5, 8), skin2);
      const kn = G(); kn.position.y = -15; hp.add(kn); add(kn, limb(13, 4.2, 3.5, 8), skin); add(kn, sph(5, 8, 6), skin2, 3, -14, 0).scale.set(1.5, 0.6, 1);
      legs.push({ hp, kn });
    }
    r.rotation.y = -0.4;
    function pose(t, st, vx) {
      const walk = Math.abs(vx) > 1, ph = t * (st === 'charge' ? 16 : 7);
      let lean = -0.35, armX = 0, armZ = 0.2;
      if (st === 'wind') { lean = -0.05; armZ = -2.4 + S(t * 30) * 0.1; }
      else if (st === 'charge') { lean = -0.8; armZ = 1.2; }
      else if (st === 'stun') { lean = -0.15 + S(t * 12) * 0.05; armZ = 0.6; }
      torso.rotation.z = lean; neck.rotation.z = st === 'wind' ? 0.5 : st === 'stun' ? -0.4 : 0.15;
      jaw.position.y = st === 'wind' || st === 'charge' ? -9 : -6;
      arms.forEach((a, i) => { a.sh.rotation.z = armZ + (walk ? S(ph + i * PI) * 0.4 : S(t * 2 + i) * 0.1); a.el.rotation.z = st === 'charge' ? 0.2 : 0.7; a.sh.rotation.x = (i ? 1 : -1) * 0.15; });
      legs.forEach((l, i) => { l.hp.rotation.z = walk ? S(ph + i * PI) * 0.6 : 0; l.kn.rotation.z = walk ? -Math.max(0, S(ph + i * PI + 1)) * 0.8 : 0; });
      hips.position.y = 30 + (walk ? Math.abs(S(ph)) * 2.5 : 0);
    }
    return { rig, pose };
  }

  // ===== جنّيّة النار =====
  function makeWisp() {
    const rig = R3D.rig(130, 150, 0); const r = rig.root;
    const f1 = glowMat(0xff5a2a, 0.85), f2 = glowMat(0xffa23a, 0.9), f3 = glowMat(0xfff0a0), eye = glowMat(0x2a0a2a), pink = glowMat(0xff4fa0, 0.6);
    const core = add(r, sph(11, 14, 12), f2, 0, 0, 0, 0);
    const inner = add(r, sph(7, 12, 10), f3, 0, -1, 3, 0);
    const flames = [];
    for (let i = 0; i < 9; i++) { const a = i / 9 * PI * 2; const f = add(r, cone(4.5 - (i % 3), 18 + (i % 3) * 6, 7), i % 2 ? f1 : pink, C(a) * 7, 2, S(a) * 5, 0); f.rotation.z = -C(a) * 0.5; flames.push({ f, a, i }); }
    const top = add(r, cone(6, 26, 8), f1, 0, 6, 0, 0);
    const face = G(); face.position.set(0, 1, 10); r.add(face);
    for (const x of [-1, 1]) { const e = add(face, sph(1.9, 8, 6), eye, x * 3.6, 1, 0, 0); e.scale.set(1, 1.3, 0.4); }
    const mouth = add(face, sph(1.8, 8, 6), eye, 0, -4, 0, 0); mouth.scale.set(1.6, 0.6, 0.4);
    const hands = []; for (const x of [-1, 1]) { const h = add(r, sph(3, 8, 6), f2, x * 15, -2, 0, 0); hands.push({ h, x }); }
    function pose(t, dir, charging) {
      const k = charging ? 1.3 + S(t * 30) * 0.1 : 1;
      flames.forEach(F => { F.f.scale.set(1, (0.8 + Math.abs(S(t * 9 + F.i * 1.7)) * 0.5) * k, 1); });
      top.scale.set(1, 0.8 + Math.abs(S(t * 7)) * 0.5, 1); top.rotation.z = S(t * 5) * 0.2;
      core.scale.setScalar(k); inner.scale.setScalar(0.9 + S(t * 11) * 0.1);
      hands.forEach(H => { H.h.position.y = -2 + S(t * 4 + H.x) * 3; H.h.position.x = H.x * (charging ? 11 : 15); });
      mouth.scale.y = charging ? 1.2 : 0.6; face.position.x = dir * 2.5; r.rotation.y = dir * 0.3;
    }
    return { rig, pose };
  }

  // ===== العنكبوت =====
  function makeSpider() {
    const rig = R3D.rig(130, 100, 20); const r = rig.root;
    const m1 = surface(0x3e2a52, { roughness: 0.7 }), m2 = surface(0x5e4478, { roughness: 0.62 }), mark = surface(0xc7372f, { emissive: 0x3a0808, roughness: 0.52 }), eye = glowMat(0xff3a3a);
    const body = G(); body.position.y = 14; r.add(body);
    const ab = add(body, sph(12, 16, 12), m1, -10, 3, 0); ab.scale.set(1.2, 1, 1);
    for (let i = 0; i < 2; i++) { const band = add(ab, new T.TorusGeometry(8.5 - i * 1.2, 0.75, 5, 14), m2, -4 - i * 6, 1, 0, 0); band.rotation.z = PI / 2; band.scale.set(1.2, 0.75, 1); }
    add(ab, sph(4, 8, 6), mark, -2, 9, 0, 0).scale.set(1.3, 0.4, 1);
    const ce = add(body, sph(8, 14, 10), m2, 6, 0, 0); ce.scale.set(1.1, 0.8, 1);
    for (let i = 0; i < 4; i++) add(body, sph(i < 2 ? 1.6 : 1.1, 6, 5), eye, 13, 2 + (i % 2) * 2.5, (i < 2 ? -1 : 1) * (1.5 + (i % 2)), 0);
    for (const z of [-2, 2]) add(body, cone(1, 5, 4), mat(0xe8dcc0), 14, -3, z, 0).rotation.z = PI - 0.5;
    const legs = [];
    for (let i = 0; i < 4; i++) for (const s of [-1, 1]) {
      const l = G(); l.position.set(10 - i * 5, 0, s * 5); body.add(l);
      const up = G(); l.add(up); add(up, limb(13, 2.1, 1.5, 6), m2).rotation.x = s * 2.1;
      const kn = G(); kn.position.set(0, 6, s * 11); up.add(kn); add(kn, limb(16, 1.2, 0.6, 6), m1).rotation.x = s * -0.25;
      l.rotation.y = (i - 1.5) * 0.35 * s; legs.push({ l, up, i, s });
    }
    r.rotation.x = 0.3; r.rotation.y = -0.3;
    function pose(t, st) {
      const walk = st === 'walk', ph = t * 18;
      legs.forEach(L => { const p = ph + L.i * 1.6 + (L.s > 0 ? PI : 0); L.up.rotation.z = walk ? S(p) * 0.3 : st === 'hang' ? -0.4 + S(t * 3 + L.i) * 0.1 : 0; });
      body.position.y = 14 + (walk ? Math.abs(S(ph)) : 0);
    }
    return { rig, pose };
  }

  // ===== جنديّ إرم =====
  function makeSoldier() {
    const rig = R3D.rig(190, 170, 45); const r = rig.root;
    const bronze = surface(0xb08a4a, { emissive: 0x1a1000, metalness: 0.42, roughness: 0.34 }), bronze2 = surface(0x7a5a2a, { metalness: 0.28, roughness: 0.46 }), wrap = surface(0xd9c9a0, { roughness: 0.88 }), wrap2 = surface(0xb8a67a, { roughness: 0.9 }), dark = surface(0x1a1410, { roughness: 0.82 }), eye = glowMat(0x7fe0ff), cloth = surface(0x7a2a2a, { roughness: 0.82 }), steel = new T.MeshStandardMaterial({ color: 0xe0e8ee, emissive: 0x202830, metalness: 0.9, roughness: 0.18 });
    const hips = G(); hips.position.y = 36; r.add(hips);
    const torso = G(); hips.add(torso);
    add(torso, sph(11, 14, 10), wrap, 0, 16, 0).scale.set(1, 1.3, 0.8);
    const arm1 = add(torso, new T.BoxGeometry(18, 16, 13), bronze, 0, 18, 0, 1.06); arm1.rotation.z = 0.02;
    add(torso, new T.TorusGeometry(9, 1.2, 5, 16), bronze2, 0, 7, 0, 0).rotation.x = PI / 2;
    const skirt = add(hips, new T.CylinderGeometry(8, 12, 14, 12), cloth, 0, -4, 0, 1.05);
    const head = G(); head.position.y = 32; torso.add(head);
    add(head, sph(7.5, 14, 10), dark, 0, 4, 0);
    const helm = add(head, new T.SphereGeometry(8.6, 16, 10, 0, PI * 2, 0, PI * 0.58), bronze, 0, 4.5, 0, 1.05);
    add(head, cone(1.6, 9, 6), bronze2, 0, 12, 0, 1.1);
    add(head, new T.BoxGeometry(2, 9, 2), bronze, 7.6, 2, 0, 1.1);
    for (const z of [-2.6, 2.6]) add(head, sph(1.3, 6, 5), eye, 6.8, 4, z, 0);
    const mkArm = (z, front) => {
      const sh = G(); sh.position.set(0, 24, z); torso.add(sh);
      add(sh, sph(5, 10, 8), bronze2); add(sh, limb(12, 3.2, 2.8, 8), wrap);
      const el = G(); el.position.y = -12; sh.add(el); add(el, limb(11, 2.8, 2.4, 8), wrap2);
      const hd = G(); hd.position.y = -11; el.add(hd); add(hd, sph(3, 8, 6), wrap);
      return { sh, el, hd };
    };
    const aF = mkArm(9, true), aB = mkArm(-9, false);
    // سيف معقوف
    const sw = G(); aF.hd.add(sw); sw.rotation.z = PI / 2;
    add(sw, new T.BoxGeometry(2, 6, 2), bronze2, 0, 1, 0, 1.1);
    add(sw, new T.BoxGeometry(8, 1.6, 3), bronze, 0, -2.5, 0, 1.1);
    const shp = new T.Shape(); shp.moveTo(-1.5, 0); shp.quadraticCurveTo(-3, -18, 6, -30); shp.quadraticCurveTo(2, -16, 1.8, 0); shp.lineTo(-1.5, 0);
    const bg = new T.ExtrudeGeometry(shp, { depth: 0.8, bevelEnabled: false, curveSegments: 10 }); bg.translate(0, -3, -0.4);
    const blade = add(sw, bg, steel, 0, 0, 0, 1.05); blade.rotation.y = PI / 2;
    // درع دائري
    const shield = add(aB.el, new T.CylinderGeometry(10, 10, 2, 18), bronze, 0, -8, -3, 1.06); shield.rotation.x = PI / 2;
    add(shield, sph(3, 8, 6), bronze2, 0, 1.5, 0, 0);
    const legs = [];
    for (const z of [-5, 5]) {
      const hp = G(); hp.position.set(0, -4, z); hips.add(hp); add(hp, limb(15, 3.4, 3, 8), wrap2);
      const kn = G(); kn.position.y = -15; hp.add(kn); add(kn, limb(15, 3, 2.6, 8), wrap); add(kn, new T.BoxGeometry(8, 3, 5), bronze2, 2, -15, 0, 1.08);
      legs.push({ hp, kn });
    }
    r.rotation.y = -0.45;
    function pose(t, st, vx, stT) {
      const walk = Math.abs(vx) > 1, ph = t * 9;
      legs.forEach((l, i) => { l.hp.rotation.z = walk ? S(ph + i * PI) * 0.55 : 0; l.kn.rotation.z = walk ? -Math.max(0, S(ph + i * PI + 1)) * 0.8 : 0; });
      hips.position.y = 36 + (walk ? Math.abs(S(ph)) * 1.5 : 0);
      let sz = walk ? S(ph + PI) * 0.4 : 0.15, ez = 0.5, tz = 0;
      if (st === 'wind') { sz = -2.6 - S(t * 30) * 0.05; ez = 0.9; tz = 0.2; }
      else if (st === 'slash') { const k = Math.min(1, stT / 0.12); sz = -2.6 + k * 4.0; ez = 0.1; tz = -0.35; }
      else if (st === 'rec') { sz = 1.2; ez = 0.3; tz = -0.25; }
      aF.sh.rotation.z = sz; aF.el.rotation.z = ez; torso.rotation.z = tz;
      aB.sh.rotation.z = walk ? S(ph) * 0.3 : -0.3; aB.el.rotation.z = -1.2; aB.sh.rotation.x = 0.4;
    }
    return { rig, pose };
  }

  // ===== ثعبانة برهوت =====
  function makeSerpent() {
    const rig = R3D.rig(640, 640, 250); const r = rig.root;
    const sc = surface(0xb08a3a, { emissive: 0x100800, roughness: 0.5 }), sc2 = surface(0x6a4a1e, { roughness: 0.58 }), belly = surface(0xe8d49a, { roughness: 0.74 }), hoodIn = surface(0x2f7f7a, { roughness: 0.58 }), eye = glowMat(0x9aff5a), fang = surface(0xf4efe0, { roughness: 0.46 }), mouthM = glowMat(0x5a0a14);
    const N = 16, segs = [];
    for (let i = 0; i < N; i++) {
      const rr = 30 - i * 0.9; const g = G(); r.add(g);
      const s = add(g, sph(rr, 16, 12), i % 2 ? sc : sc2, 0, 0, 0, 1.04);
      const b = add(g, sph(rr * 0.8, 12, 10), belly, 0, 0, rr * 0.35, 0); b.scale.set(0.9, 0.9, 0.7);
      const scaleBand = add(g, new T.TorusGeometry(Math.max(12, rr * 0.72), 1.1, 5, 14), i % 2 ? sc2 : sc, 0, 0, 0, 0); scaleBand.rotation.x = PI / 2;
      segs.push(g);
    }
    const head = G(); r.add(head);
    const hood = add(head, sph(46, 18, 14), sc2, -14, -22, -22); hood.scale.set(1.05, 1.25, 0.3);
    const hin = add(head, sph(40, 16, 12), hoodIn, -14, -22, -12, 0); hin.scale.set(0.95, 1.12, 0.12);
    for (let i = 0; i < 3; i++) add(hin, sph(6, 8, 6), mat(0xe8b75a, { emissive: 0x3a2000 }), 0, 16 - i * 16, 30, 0).scale.set(1, 1, 0.3);
    const skull = add(head, sph(27, 18, 14), sc, 12, 4, 8); skull.scale.set(1.62, 0.86, 1.02);
    add(head, sph(20, 14, 10), sc2, 30, 10, 8, 0).scale.set(1.2, 0.35, 0.8);
    const jawG = G(); jawG.position.set(0, -4, 0); head.add(jawG);
    const jaw = add(jawG, sph(21, 14, 10), belly, 20, -6, 8); jaw.scale.set(1.7, 0.5, 0.95);
    add(head, sph(14, 12, 8), mouthM, 24, -5, 8, 0).scale.set(1.6, 0.35, 0.7);
    for (const z of [-11, 11]) { const e = add(head, sph(5.5, 10, 8), eye, 26, 13, 8 + z * 1.4, 0); e.scale.set(1.3, 0.8, 0.8); add(head, cone(2.6, 14, 6), fang, 42, -4, 8 + z * 0.6, 0).rotation.z = PI + 0.15; add(head, cone(4, 16, 6), sc2, 4, 22, 8 + z * 1.3, 1.08).rotation.z = 1.2; }
    r.rotation.y = -0.3;
    // وضع قائم: القاعدة عند y=0 والرأس على ارتفاع h
    function upright(t, h, dir, open) {
      r.scale.x = dir;
      for (let i = 0; i < N; i++) {
        const s = i / (N - 1), y = s * (h - 30) - 60;
        segs[i].position.set(S(s * 4 + t * 2.4) * 28 * (1 - s * 0.6) - s * 20, y, -s * 6);
        segs[i].visible = true;
      }
      const last = segs[N - 1].position;
      head.position.set(last.x + 14, last.y + 26, 0); head.rotation.z = S(t * 2) * 0.08 - 0.1;
      jawG.rotation.z = -(open ? 0.45 : 0.05 + Math.abs(S(t * 2)) * 0.05);
    }
    function lunge(t, dir) {
      r.scale.x = dir;
      for (let i = 0; i < N; i++) { segs[i].position.set(-i * 30 - 30, S(t * 10 - i * 0.6) * 10, 0); }
      head.position.set(0, 0, 0); head.rotation.z = -0.05; jawG.rotation.z = -0.5;
    }
    return { rig, upright, lunge };
  }

  // ===== سلطان الرمال (شدّاد) =====
  function makeSultan() {
    const rig = R3D.rig(420, 460, 200); const r = rig.root;
    const sand = surface(0xd9b36a, { transparent: true, opacity: 0.95, roughness: 0.62 }), sand2 = surface(0xb08a4a, { roughness: 0.58 }), sandD = surface(0x8a6a3a, { roughness: 0.68 }), gold = new T.MeshStandardMaterial({ color: 0xe8b75a, emissive: 0x4a3000, metalness: 0.72, roughness: 0.28 }), robe = surface(0x6a2a4a, { roughness: 0.78 }), gem = glowMat(0x55c3e0), eyeM = glowMat(0xffb040);
    // إعصار الجسد السفلي
    const tor = [];
    for (let i = 0; i < 7; i++) { const t = add(r, new T.TorusGeometry(26 + i * 7, 9 - i * 0.4, 8, 22), i % 2 ? sand : sand2, 0, 150 - i * 21, 0, 0); t.rotation.x = PI / 2 - 0.2; t.scale.set(1, 1, 1); tor.push(t); }
    const funnel = add(r, new T.CylinderGeometry(70, 16, 150, 18, 1, true), mat(0xc9a05a, { transparent: true, opacity: 0.22, side: T.DoubleSide, depthWrite: false }), 0, 75, 0, 0);
    const up = G(); up.position.y = 170; r.add(up);
    const vest = mat(0x3e1a34), trim = gold;
    const chest = add(up, sph(60, 20, 16), vest, 0, 50, 0); chest.scale.set(1.15, 1, 0.75);
      for (const x of [-1, 1]) { const pauldron = add(up, new T.SphereGeometry(25, 12, 8), gold, x * 63, 87, 0, 1.04); pauldron.scale.set(1.35, 0.55, 0.8); }
    const belly = add(up, sph(34, 16, 12), sand2, 0, 50, 22); belly.scale.set(0.8, 1.25, 0.8);
    for (const x of [-1, 1]) { const tr = add(up, new T.BoxGeometry(5, 90, 5), trim, x * 26, 52, 40, 0); tr.rotation.z = x * 0.18; }
    add(up, sph(40, 16, 12), robe, 0, 20, 12).scale.set(1.3, 0.9, 0.7);
    add(up, new T.TorusGeometry(52, 6, 8, 24), gold, 0, 16, 0, 1.03).rotation.x = PI / 2;
    const crackM = glowMat(0xffa040); const cracks = [];
    for (const [x, y, rz, l] of [[-22, 60, 0.6, 30], [-12, 44, -0.4, 22], [20, 64, -0.7, 28], [28, 44, 0.3, 18], [0, 76, 1.4, 20]]) { const c = add(up, new T.BoxGeometry(l, 2.2, 2), crackM, x, y, 44, 0); c.rotation.z = rz; cracks.push(c); }
    for (const x of [-1, 1]) for (let i = 0; i < 3; i++) { const sp = add(up, cone(5, 22, 6), gold, x * (70 + i * 6), 96 - i * 3, -6 + i * 8, 1.08); sp.rotation.z = -x * (0.5 + i * 0.25); }
    add(up, sph(20, 12, 10), robe, 0, 30, 36).scale.set(1.1, 0.5, 0.4);
    const arms = [];
    for (const x of [-1, 1]) {
      const sh = G(); sh.position.set(x * 66, 80, 0); up.add(sh);
      add(sh, sph(24, 14, 10), gold, 0, 4, 0).scale.set(1.2, 0.8, 1);
      add(sh, limb(56, 17, 14, 12), vest);
      const el = G(); el.position.y = -56; sh.add(el);
      add(el, limb(50, 14, 11, 12), sand); add(el, new T.TorusGeometry(13, 4, 6, 14), gold, 0, -38, 0, 0).rotation.x = PI / 2;
      const hd = add(el, sph(16, 12, 10), sand2, 0, -54, 0); hd.scale.set(1, 1.2, 0.9);
      arms.push({ sh, el, x });
    }
    const head = G(); head.position.y = 118; up.add(head);
    const faceM = mat(0xa8804a); const face = add(head, sph(34, 18, 14), faceM, 0, 18, 6); face.scale.set(1, 1.1, 0.9);
      add(head, new T.TorusGeometry(28, 2.2, 6, 18), gold, 0, 36, 4, 0).rotation.x = PI / 2;
    add(head, sph(8, 10, 8), sandD, 0, 12, 38).scale.set(0.8, 1.2, 0.8);
    const mouthS = add(head, sph(9, 10, 8), glowMat(0x2a0a04), 0, -2, 34, 0); mouthS.scale.set(1.6, 0.5, 0.4);
    const beard = add(head, cone(26, 60, 12), sandD, 0, -6, 26); beard.rotation.x = PI + 0.25;
    const eyes = []; for (const x of [-1, 1]) { const e = add(head, sph(6.5, 10, 8), eyeM, x * 13, 24, 36, 0); e.scale.set(1.4, 0.75, 0.4); eyes.push(e); add(head, new T.BoxGeometry(20, 5, 6), sandD, x * 13, 33, 35, 1.1).rotation.z = -x * 0.35; }
    const crown = G(); crown.position.y = 50; head.add(crown);
    add(crown, new T.CylinderGeometry(30, 34, 18, 16, 1, true), gold, 0, 0, 0, 1.04);
    for (let i = 0; i < 7; i++) { const a = i / 7 * PI * 2; add(crown, cone(5, 20, 6), gold, S(a) * 30, 8, C(a) * 30, 1.08); }
    const gm = add(crown, new T.OctahedronGeometry(7), gem, 0, 2, 33, 1.1);
    r.rotation.y = -0.25;
    function pose(t, st, phase, freed, tired, k) {
      tor.forEach((g, i) => { g.rotation.z = t * (2.4 + i * 0.5); g.position.x = S(t * 2 + i) * 6; });
      funnel.rotation.y = t * 3;
      up.position.y = 170 + S(t * 2.2) * 4 - (tired ? 50 : 0);
      up.rotation.z = tired ? 0.25 : S(t * 1.3) * 0.04;
      head.rotation.z = tired ? 0.35 : 0; head.rotation.x = tired ? 0.3 : 0;
      let a1 = 0.3, a2 = 0.6;
      if (st === 'volley') { a1 = -2.2 + S(t * 8) * 0.3; a2 = 0.3; }
      else if (st === 'spikes' || st === 'hands') { a1 = -1.2; a2 = -0.9; }
      else if (st === 'wave') { a1 = 0.9; a2 = 0.2; }
      else if (st === 'summon' || st === 'phase') { a1 = -2.6; a2 = 0.2; }
      else if (tired) { a1 = 0.1; a2 = 0.2; }
      arms.forEach(A => { A.sh.rotation.z = A.x * (st === 'volley' ? (A.x > 0 ? a1 : 0.4) : -a1 * 0.5 + 0.35) ; A.sh.rotation.x = st === 'volley' && A.x > 0 ? 0 : 0; A.el.rotation.z = A.x * a2 * 0.5; });
      if (st === 'volley') { arms[1].sh.rotation.z = a1 * -1; }
      const eyeC = freed ? 0x9fe6ff : phase === 2 ? 0xff3a1a : tired ? 0x7fdcf5 : 0xffb040;
      eyes.forEach(e => e.material.color.setHex(eyeC)); cracks.forEach((c, i) => { c.visible = phase === 2 || freed; c.material.color.setHex(freed ? 0x9fe6ff : 0xff7a30); c.scale.y = 1 + Math.abs(S(t * 6 + i)) * 0.8; });
      sand.opacity = freed ? Math.max(0, 0.9 - k) : 0.95;
      sand.color.setHex(freed ? 0x9fcbe0 : phase === 2 ? 0xd98a5a : 0xd9b36a);
    }
    return { rig, pose };
  }

  // ===== الإنشاء =====
  const R = {
    scorpion: makeScorpion({ VW: 210, VH: 140, CY: 44, scale: 1.3, c1: 0xc9843e, c2: 0x9a5a28, c3: 0x3a1a10, e3: 0x100000, eye: 0x1a0a05, tip: 0xff5a3a }),
    minion: makeScorpion({ VW: 120, VH: 80, CY: 24, c1: 0x8a4fa8, c2: 0x5e3478, c3: 0x2a1030, eye: 0xffd27a, tip: 0xff5aa0, scale: 0.7 }),
    queen: makeScorpion({ VW: 470, VH: 300, CY: 100, c1: 0x6a3a8a, c2: 0x3e2256, c3: 0xe8b75a, e3: 0x3a2000, eye: 0xff4a4a, tip: 0xff4fa0, crown: true, scale: 3.25 }),
    bat: makeBat(), spirit: makeSpirit(), ghoul: makeGhoul(), wisp: makeWisp(), spider: makeSpider(), soldier: makeSoldier(),
    serpent: makeSerpent(), sultan: makeSultan(),
  };

  function drawEnemy(ctx, e, scale) {
    R3D.key = e;
    const t = e.t, cx = e.x + e.w / 2, by = e.y + e.h, dir = e.dir > 0 ? 1 : -1;
    const alpha = 1;
    if (alpha <= 0) return;
    const o = { alpha, flash: e.flash > 0 };
    const death = !e.alive ? Math.min(1, e.deadT / 0.5) : 0;
    const reaction = rig => { rig.root.rotation.z = death ? -death * 1.15 : e.flash > 0 ? S(t * 70) * 0.055 : 0; rig.root.position.y = death * 14; return { ...o, alpha: 1 - death }; };
    switch (e.type) {
      case 'scorpion': case 'minion': { const m = R[e.type]; m.pose(t, Math.abs(e.vx) > 5, { snap: e.st === 'attack' || Math.abs(e.vx) > 100, strike: e.st === 'attack', rear: e.st === 'attack_w' ? 0.22 : 0 }); m.rig.root.scale.x = dir * (e.type === 'minion' ? 0.7 : 1.3); m.rig.root.rotation.z = death ? -death * 1.2 : e.flash > 0 ? S(t * 70) * 0.06 : 0; m.rig.root.position.y = death * 14; R3D.draw(ctx, m.rig, cx, by + 2, scale, { ...o, alpha: 1 - death }); break; }
      case 'bat': { const m = R.bat; m.pose(t, dir, e.st === 'swoop' || e.st === 'dive_w'); R3D.draw(ctx, m.rig, cx, e.y + e.h / 2, scale, { ...reaction(m.rig), alpha: (e.st === 'dive_w' ? 0.82 : 1) * (1 - death) }); break; }
      case 'spirit': { const m = R.spirit; m.pose(t, dir); m.rig.root.position.y = S(t * 2.5) * 3 + death * 14; R3D.draw(ctx, m.rig, cx, e.y + e.h / 2, scale, { ...reaction(m.rig), alpha: alpha * 0.95 * (1 - death) }); break; }
      case 'ghoul': { const m = R.ghoul; m.pose(t, e.st, e.vx); m.rig.root.scale.x = dir; R3D.draw(ctx, m.rig, cx, by + 2, scale, reaction(m.rig)); break; }
      case 'wisp': { const m = R.wisp; m.pose(t, dir, e.charging); m.rig.root.position.y = S(t * 5) * 3 + death * 14; R3D.draw(ctx, m.rig, cx, e.y + e.h / 2, scale, reaction(m.rig)); break; }
      case 'spider': { const m = R.spider; m.pose(t, e.st); const hang = e.st === 'hang' || e.st === 'drop'; const ro = reaction(m.rig); m.rig.root.rotation.z = hang ? PI : death ? -death * 1.15 : 0; m.rig.root.scale.x = dir; R3D.draw(ctx, m.rig, cx, hang ? e.y + 2 : by + 2, scale, ro); break; }
      case 'soldier': { const m = R.soldier; m.pose(t, e.st, e.vx, e.stT); m.rig.root.scale.x = dir; R3D.draw(ctx, m.rig, cx, by + 2, scale, reaction(m.rig)); break; }
      default: return false;
    }
    return true;
  }
  function drawQueen(ctx, b, gy, scale) {
    R3D.key = b;
    const m = R.queen, t = performance.now() / 1000;
    const deadK = b.deadAt ? Math.min(1, (performance.now() - b.deadAt) / 1600) : 0;
    const walk = b.st === 'charge', rear = b.st === 'charge_w' || b.st === 'leap_w' ? 0.18 : b.st === 'stun' ? -0.06 : 0;
    m.pose(t, walk || b.st === 'idle', { rear, strike: b.st === 'sting', snap: b.st === 'charge_w' || b.st === 'summon_w', lift: b.st === 'leap' ? 2 : 0, reach: b.st === 'charge' ? 0.4 : 0 });
    m.rig.root.scale.x = (b.dir > 0 ? 1 : -1) * 2.9;
    m.rig.root.rotation.z = deadK * 1.1; m.rig.root.position.y = deadK * 26;
    R3D.draw(ctx, m.rig, b.x + b.w / 2, b.y + b.h + 4, scale, { flash: b.flash > 0, alpha: 1 - deadK });
  }
  function drawSerpent(ctx, b, gy, player, scale) {
    R3D.key = b;
    const m = R.serpent, t = performance.now() / 1000;
    const deadK = b.deadAt ? Math.min(1, (performance.now() - b.deadAt) / 1600) : 0;
    if (b.st === 'lunge') { m.lunge(t, b.dir > 0 ? 1 : -1); R3D.draw(ctx, m.rig, b.lx, b.ly + 0, scale, { flash: b.flash > 0, alpha: b.dead ? 0.6 : 1 }); m.rig.cam.position.y = m.rig.CY; return; }
    const h = gy - b.top; if (h < 10) return;
    const dir = player.x + player.w / 2 > b.x ? 1 : -1;
    m.upright(t, h + 40, dir, b.st === 'up' && b.fired < (b.mode === 'volley' ? 5 : 2));
    m.rig.root.rotation.z = deadK * 0.7; m.rig.root.position.y = deadK * 20;
    R3D.draw(ctx, m.rig, b.x, gy, scale, { flash: b.flash > 0, alpha: 1 - deadK });
  }
  function drawSultan(ctx, b, scale) {
    R3D.key = b;
    const m = R.sultan, t = performance.now() / 1000;
    const deadK = b.deadAt ? Math.min(1, (performance.now() - b.deadAt) / 1600) : 0;
    const cx = b.x + b.w / 2, tired = b.st === 'tired';
    m.pose(t, b.st, b.phase, b.freed, tired || b.sink > 0.5, b.freed ? b.t / 12 : 0);
    m.rig.root.scale.x = b.dir > 0 ? -1 : 1;
    const a = b.freed ? Math.max(0, 1 - b.t / 12) : 1;
    m.rig.root.rotation.z = deadK * 0.35; m.rig.root.position.y = deadK * 24;
    R3D.draw(ctx, m.rig, cx, b.y + 340, scale, { flash: b.flash > 0, alpha: a * (1 - deadK) });
  }
  Object.assign(api, { ok: true, drawEnemy, drawQueen, drawSerpent, drawSultan, R });
  return api;
})();
